from datetime import timedelta, timezone
import smtplib
from email.message import EmailMessage
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..config import get_settings
from ..database import get_db
from ..models import User, InvestorProfile, Preferences, UserSession, AuditEvent, PasswordReset, WatchItem, Transaction, utcnow
from ..schemas import RegisterIn, LoginIn, UserOut, MeUpdate, ProfileIn, ProfileOut, PreferencesIn, PreferencesOut, DeleteAccountIn, ResetRequestIn, ResetConfirmIn
from ..security import hash_password, verify_password, create_session, set_auth_cookies, clear_auth_cookies, hash_token, generate_refresh, REFRESH_DAYS, current_user, get_session_from_access

router = APIRouter(prefix="/api", tags=["auth-profile"])


def audit(db, user_id, action):
    db.add(AuditEvent(user_id=user_id, action=action))


@router.post("/auth/register", response_model=UserOut, status_code=201)
def register(payload: RegisterIn, response: Response, request: Request, db: Session = Depends(get_db)):
    email = str(payload.email).lower()
    if db.scalar(select(User.id).where(User.email == email)):
        raise HTTPException(409, "Este e-mail já possui uma conta")
    user = User(email=email, full_name=payload.full_name.strip(), password_hash=hash_password(payload.password))
    user.profile = InvestorProfile()
    user.preferences = Preferences()
    db.add(user)
    db.flush()
    session, refresh = create_session(db, user, request.headers.get("user-agent", ""))
    audit(db, user.id, "register")
    db.commit()
    set_auth_cookies(response, user, session, refresh)
    return user


@router.post("/auth/login", response_model=UserOut)
def login(payload: LoginIn, response: Response, request: Request, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == str(payload.email).lower()))
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(401, "E-mail ou senha inválidos")
    session, refresh = create_session(db, user, request.headers.get("user-agent", ""))
    audit(db, user.id, "login")
    db.commit()
    set_auth_cookies(response, user, session, refresh)
    return user


@router.post("/auth/refresh", response_model=UserOut)
def refresh_session(request: Request, response: Response, db: Session = Depends(get_db)):
    raw = request.cookies.get("invest_refresh", "")
    if "." not in raw:
        raise HTTPException(401, "Faça login novamente")
    sid, token = raw.split(".", 1)
    session = db.get(UserSession, sid)
    if not session or session.revoked_at or session.expires_at.replace(tzinfo=timezone.utc) <= utcnow() or session.refresh_hash != hash_token(token):
        raise HTTPException(401, "Sessão expirada ou revogada")
    user = db.get(User, session.user_id)
    if not user:
        raise HTTPException(401, "Conta indisponível")
    new_token = generate_refresh()
    session.refresh_hash = hash_token(new_token)
    db.commit()
    set_auth_cookies(response, user, session, new_token)
    return user


@router.post("/auth/logout")
def logout(request: Request, response: Response, db: Session = Depends(get_db)):
    raw = request.cookies.get("invest_refresh", "")
    if "." in raw:
        sid, _ = raw.split(".", 1)
        session = db.get(UserSession, sid)
        if session:
            session.revoked_at = utcnow()
            audit(db, session.user_id, "logout")
            db.commit()
    clear_auth_cookies(response)
    return {"ok": True}


@router.get("/me", response_model=UserOut)
def get_me(user: User = Depends(current_user)):
    return user


@router.patch("/me", response_model=UserOut)
def update_me(payload: MeUpdate, db: Session = Depends(get_db), user: User = Depends(current_user)):
    user.full_name = payload.full_name.strip()
    audit(db, user.id, "profile-name-updated")
    db.commit()
    return user


@router.get("/me/investor-profile", response_model=ProfileOut)
def get_profile(user: User = Depends(current_user)):
    return user.profile


@router.put("/me/investor-profile", response_model=ProfileOut)
def put_profile(payload: ProfileIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    for key, value in payload.model_dump().items():
        setattr(user.profile, key, value)
    audit(db, user.id, "investor-profile-updated")
    db.commit()
    db.refresh(user.profile)
    return user.profile


@router.get("/me/preferences", response_model=PreferencesOut)
def get_preferences(user: User = Depends(current_user)):
    return user.preferences


@router.put("/me/preferences", response_model=PreferencesOut)
def put_preferences(payload: PreferencesIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    for key, value in payload.model_dump().items():
        setattr(user.preferences, key, value)
    db.commit()
    db.refresh(user.preferences)
    return user.preferences


@router.get("/me/sessions")
def list_sessions(request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)):
    active = get_session_from_access(request, db)
    sessions = db.scalars(select(UserSession).where(UserSession.user_id == user.id, UserSession.revoked_at.is_(None)).order_by(UserSession.created_at.desc())).all()
    return [{"id": s.id, "created_at": s.created_at, "user_agent": s.user_agent, "current": s.id == active.id} for s in sessions if s.expires_at.replace(tzinfo=timezone.utc) > utcnow()]


@router.delete("/me/sessions/{session_id}")
def revoke_session(session_id: str, request: Request, response: Response, db: Session = Depends(get_db), user: User = Depends(current_user)):
    session = db.get(UserSession, session_id)
    if not session or session.user_id != user.id:
        raise HTTPException(404, "Sessão não encontrada")
    is_current = get_session_from_access(request, db).id == session.id
    session.revoked_at = utcnow()
    if is_current:
        clear_auth_cookies(response)
    audit(db, user.id, "session-revoked")
    db.commit()
    return {"ok": True}


@router.get("/me/export")
def export_account(db: Session = Depends(get_db), user: User = Depends(current_user)):
    """Exportação JSON dos dados pessoais no MVP, sem hashes de senha ou tokens."""
    watches = db.scalars(select(WatchItem).where(WatchItem.user_id == user.id)).all()
    transactions = db.scalars(select(Transaction).where(Transaction.user_id == user.id)).all()
    return {
        "exported_at": utcnow().isoformat(),
        "account": {"id": user.id, "email": user.email, "full_name": user.full_name, "created_at": user.created_at.isoformat()},
        "investor_profile": {k: getattr(user.profile, k) for k in ("experience", "goal", "horizon", "liquidity", "risk_tolerance", "interests", "onboarding_completed")},
        "preferences": {k: getattr(user.preferences, k) for k in ("theme", "level", "notifications_enabled", "digest")},
        "watchlist": [{"asset_code": w.asset_code, "created_at": w.created_at.isoformat()} for w in watches],
        "transactions": [{"asset_code": t.asset_code, "type": t.type, "quantity": str(t.quantity), "unit_price_brl": str(t.unit_price_brl), "fee_brl": str(t.fee_brl), "traded_at": t.traded_at.isoformat()} for t in transactions],
        "disclaimer": "A exportação não inclui dados externos de cotação e não substitui extratos oficiais da corretora."
    }


@router.delete("/me")
def delete_account(payload: DeleteAccountIn, response: Response, db: Session = Depends(get_db), user: User = Depends(current_user)):
    if not verify_password(payload.password, user.password_hash):
        raise HTTPException(403, "Senha incorreta")
    db.delete(user)
    db.commit()
    clear_auth_cookies(response)
    return {"ok": True}


@router.post("/auth/password-reset/request")
def request_password_reset(payload: ResetRequestIn, db: Session = Depends(get_db)):
    settings = get_settings()
    if not (settings.smtp_host and settings.smtp_from and settings.smtp_username and settings.smtp_password):
        raise HTTPException(503, "Recuperação por e-mail indisponível: configure SMTP_HOST, SMTP_FROM, SMTP_USERNAME e SMTP_PASSWORD")
    user = db.scalar(select(User).where(User.email == str(payload.email).lower()))
    if user:
        token = generate_refresh()
        reset = PasswordReset(user_id=user.id, token_hash=hash_token(token), expires_at=utcnow() + timedelta(minutes=30))
        db.add(reset)
        db.commit()
        msg = EmailMessage()
        msg["Subject"] = "Redefinir senha do INVEST AI"
        msg["From"] = settings.smtp_from
        msg["To"] = user.email
        msg.set_content(f"Seu código de redefinição válido por 30 minutos:\n\n{token}\n\nSe não solicitou, ignore esta mensagem.")
        try:
            with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=10) as smtp:
                smtp.starttls()
                smtp.login(settings.smtp_username, settings.smtp_password)
                smtp.send_message(msg)
        except Exception:
            raise HTTPException(503, "Falha ao enviar e-mail. Tente mais tarde") from None
    return {"message": "Se houver uma conta com esse e-mail, enviaremos as instruções"}


@router.post("/auth/password-reset/confirm")
def confirm_password_reset(payload: ResetConfirmIn, db: Session = Depends(get_db)):
    reset = db.scalar(select(PasswordReset).where(PasswordReset.token_hash == hash_token(payload.token)))
    if not reset or reset.used_at or reset.expires_at.replace(tzinfo=timezone.utc) <= utcnow():
        raise HTTPException(400, "Código inválido ou expirado")
    user = db.get(User, reset.user_id)
    if not user:
        raise HTTPException(400, "Código inválido ou expirado")
    user.password_hash = hash_password(payload.new_password)
    reset.used_at = utcnow()
    for session in db.scalars(select(UserSession).where(UserSession.user_id == user.id, UserSession.revoked_at.is_(None))):
        session.revoked_at = utcnow()
    audit(db, user.id, "password-reset")
    db.commit()
    return {"ok": True, "message": "Senha alterada. Entre novamente."}
