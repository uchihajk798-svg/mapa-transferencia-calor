'use client';
import GuestWeb from './guest';
import { supabaseConfigured } from '@/lib/supabase';

export default function InvestAIWeb(){
  return <GuestWeb openLogin={()=>{}} serverReady={supabaseConfigured()}/>;
}
