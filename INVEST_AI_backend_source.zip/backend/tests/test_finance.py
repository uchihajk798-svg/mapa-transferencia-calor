from datetime import datetime, timezone


def tx(asset='bitcoin', typ='BUY', qty='2', price='100', fee='2', date='2026-01-01T12:00:00Z'):
    return {"asset_code":asset,"type":typ,"quantity":qty,"unit_price_brl":price,"fee_brl":fee,"traded_at":date}


def test_watchlist_and_portfolio(registered):
    c=registered
    res=c.post('/api/watchlist',json={"asset_code":"bitcoin"})
    assert res.status_code==201,res.text
    assert c.post('/api/watchlist',json={"asset_code":"bitcoin"}).status_code==409
    assert c.post('/api/watchlist',json={"asset_code":"INVALID"}).status_code==422
    assert len(c.get('/api/watchlist').json())==1
    assert c.post('/api/portfolio/transactions',json=tx()).status_code==201
    positions=c.get('/api/portfolio').json()['positions']
    assert positions[0]['quantity']=='2.0000000000'
    assert positions[0]['cost_basis_brl']=='202.00'
    assert positions[0]['average_price_brl']=='101.00'
    assert c.post('/api/portfolio/transactions',json=tx(typ='SELL',qty='3')).status_code==422
    assert c.post('/api/portfolio/transactions',json=tx(typ='SELL',qty='1',price='150',fee='1',date='2026-02-01T12:00:00Z')).status_code==201
    p=c.get('/api/portfolio').json()
    assert p['positions'][0]['quantity']=='1.0000000000'
    assert p['positions'][0]['cost_basis_brl']=='101.00'
    assert p['positions'][0]['realized_result_brl']=='48.00'
    assert p['valuation'] is None
    assert len(p['transactions'])==2
    assert c.delete('/api/watchlist/'+res.json()['id']).status_code==200


def test_cannot_break_historical_balance(registered):
    c=registered
    a=c.post('/api/portfolio/transactions',json=tx(qty='2',date='2026-01-02T00:00:00Z'))
    assert a.status_code==201
    b=c.post('/api/portfolio/transactions',json=tx(typ='SELL',qty='1',date='2026-01-03T00:00:00Z'))
    assert b.status_code==201
    assert c.delete('/api/portfolio/transactions/'+a.json()['id']).status_code==422
    assert len(c.get('/api/portfolio').json()['transactions'])==2
    assert c.post('/api/portfolio/transactions',json=tx(typ='SELL',qty='1',date='2026-01-01T00:00:00Z')).status_code==422


def test_isolation_two_accounts(client):
    client.post('/api/auth/register',json={"full_name":"Primeiro Usuário","email":"first@example.com","password":"senha-123456789"})
    first=client.post('/api/watchlist',json={"asset_code":"bitcoin"}).json()['id']
    first_tx=client.post('/api/portfolio/transactions',json=tx()).json()['id']
    client.post('/api/auth/logout')
    client.post('/api/auth/register',json={"full_name":"Segundo Usuário","email":"second@example.com","password":"senha-123456789"})
    assert client.get('/api/watchlist').json()==[]
    assert client.get('/api/portfolio').json()['transactions']==[]
    assert client.delete('/api/watchlist/'+first).status_code==404
    assert client.delete('/api/portfolio/transactions/'+first_tx).status_code==404
