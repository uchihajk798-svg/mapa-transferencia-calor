from app.config import Settings, get_settings


def sample():
    return {"version": 1, "entries": [
        {"id": "buy1", "ticker": "BTC", "category": "Criptomoeda", "kind": "BUY", "quantity": 2, "unitPrice": 100, "fee": 0, "createdAt": "2026-01-01T12:00:00Z"},
        {"id": "sell1", "ticker": "BTC", "category": "Criptomoeda", "kind": "SELL", "quantity": 1, "unitPrice": 120, "fee": 0, "createdAt": "2026-01-02T12:00:00Z"}], "watch": ["BTC"], "name": "Pessoa"}


def test_cloud_requires_login(client):
    assert client.get("/api/me/cloud-backup").status_code == 401
    assert client.put("/api/me/cloud-backup", json={"expected_revision": 0, "data": sample()}).status_code == 401


def test_cloud_create_restore_and_prevent_overwrite(registered):
    a = registered.get("/api/me/cloud-backup")
    assert a.status_code == 200 and a.json()["revision"] == 0 and a.json()["data"] is None
    b = registered.put("/api/me/cloud-backup", json={"expected_revision": 0, "data": sample()})
    assert b.status_code == 200 and b.json()["revision"] == 1
    c = registered.get("/api/me/cloud-backup")
    assert c.json()["data"]["entries"][1]["kind"] == "SELL"
    assert registered.put("/api/me/cloud-backup", json={"expected_revision": 0, "data": sample()}).status_code == 409
    assert registered.put("/api/me/cloud-backup", json={"expected_revision": 1, "data": sample()}).json()["revision"] == 2


def test_cloud_validation(registered):
    broken = sample()
    broken["entries"][1]["quantity"] = 3
    assert registered.put("/api/me/cloud-backup", json={"expected_revision": 0, "data": broken}).status_code == 422
    broken = sample()
    broken["entries"][0]["unitPrice"] = -20
    assert registered.put("/api/me/cloud-backup", json={"expected_revision": 0, "data": broken}).status_code == 422
    broken = sample()
    broken["entries"][0]["ticker"] = "BTC;DROP TABLE"
    assert registered.put("/api/me/cloud-backup", json={"expected_revision": 0, "data": broken}).status_code == 422


def test_browser_bearer_signup_and_private_backup(client):
    signup = client.post("/api/mobile/auth/register", json={"full_name":"Teste Nuvem", "email":"nuvem@example.com", "password":"uma-senha-bem-forte"})
    assert signup.status_code == 201, signup.text
    token = signup.json()["access_token"]
    assert token
    assert client.get("/api/me/cloud-backup").status_code == 401
    headers={"Authorization":f"Bearer {token}"}
    assert client.put("/api/me/cloud-backup", headers=headers, json={"expected_revision":0,"data":sample()}).status_code == 200
    assert client.get("/api/me/cloud-backup",headers=headers).json()["revision"] == 1
    options=client.options("/api/me/cloud-backup",headers={"Origin":"http://localhost:3000","Access-Control-Request-Method":"PUT","Access-Control-Request-Headers":"Authorization,Content-Type"})
    assert options.status_code == 200
    assert "authorization" in options.headers.get("access-control-allow-headers", "").lower()


def test_production_refuses_ephemeral_database():
    get_settings.cache_clear()
    try:
        import os
        assert Settings(app_env="development", database_url="sqlite:///tmp/test.db").database_url.startswith("sqlite")
        # Validation is done in get_settings, tested here by monkeypatching env.
        os.environ["APP_ENV"] = "production"
        os.environ["DATABASE_URL"] = "sqlite:///tmp/unstable.db"
        import pytest
        with pytest.raises(RuntimeError, match="DATABASE_URL"):
            get_settings()
    finally:
        os.environ.pop("APP_ENV", None)
        os.environ.pop("DATABASE_URL", None)
        get_settings.cache_clear()