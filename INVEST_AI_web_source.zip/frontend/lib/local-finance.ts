/** Módulo local: sem cotações inventadas, sem acesso à corretora. */
export type Category = 'Criptomoeda' | 'Ação' | 'FII' | 'ETF' | 'Renda fixa' | 'Outro';
export type Entry = {id:string; ticker:string; category:Category; kind:'BUY'|'SELL'; quantity:number; unitPrice:number; fee:number; createdAt:string};
export type LocalStore = {name:string;theme:'dark'|'light';level:'beginner'|'pro'; entries:Entry[];watch:string[]; goal?:string;horizon?:string;risk?:string; alerts?:boolean;alertThreshold?:number};
export type Position = {ticker:string;category:Category;quantity:number;cost:number;buyValue:number;fees:number};
export type MarketQuote = {ticker:string;name:string;price:number;change:number|null;updatedAt:string;source:string};
export const CATEGORIES:Category[] = ['Criptomoeda','Ação','FII','ETF','Renda fixa','Outro'];
export const DEFAULT_STORE:LocalStore={name:'',theme:'dark',level:'beginner',entries:[],watch:[],goal:'aprender',horizon:'indefinido',risk:'nao_sei',alerts:true,alertThreshold:5};
const CODE=/^[A-Z0-9][A-Z0-9._-]{0,24}$/;
const validNumber=(v:unknown,max=1e12):v is number=>typeof v==='number'&&Number.isFinite(v)&&v>=0&&v<=max;
function validEntry(x:unknown):x is Entry {
 if(!x||typeof x!=='object')return false;
 const e=x as Record<string,unknown>;
 return typeof e.id==='string'&&e.id.length>0&&e.id.length<=120&&typeof e.ticker==='string'&&CODE.test(e.ticker)&&
  CATEGORIES.includes(e.category as Category)&&(e.kind==='BUY'||e.kind==='SELL')&&validNumber(e.quantity)&&e.quantity>0&&
  validNumber(e.unitPrice)&&validNumber(e.fee)&&typeof e.createdAt==='string'&&Number.isFinite(Date.parse(e.createdAt))&&
  Date.parse(e.createdAt)<Date.now()+86400000;
}
export function calcPositions(entries:Entry[]):Position[]{
 const holdings=new Map<string,Position>();
 // ECMAScript stable sort preserves user-entered order when the day is the same.
 for(const e of [...entries].sort((a,b)=>a.createdAt.localeCompare(b.createdAt))){
  if(!validEntry(e))throw new Error('Movimentação com valores inválidos.');
  const key=e.category+':'+e.ticker;
  const prev=holdings.get(key)||{ticker:e.ticker,category:e.category,quantity:0,cost:0,buyValue:0,fees:0};
  if(e.kind==='BUY'){
   prev.quantity+=e.quantity;prev.cost+=e.quantity*e.unitPrice+e.fee;prev.buyValue+=e.quantity*e.unitPrice;prev.fees+=e.fee;
  }else{
   if(e.quantity>prev.quantity+1e-9)throw new Error(`Venda maior que o saldo disponível de ${e.ticker}.`);
   const removed=prev.quantity>0?prev.cost*e.quantity/prev.quantity:0;
   prev.quantity=Math.max(0,prev.quantity-e.quantity);prev.cost=Math.max(0,prev.cost-removed);prev.fees+=e.fee;
   if(prev.quantity<=1e-9)prev.cost=0;
  }
  if(!Number.isFinite(prev.cost)||!Number.isFinite(prev.quantity))throw new Error('Movimentação acima dos limites numéricos.');
  holdings.set(key,prev);
 }
 return [...holdings.values()].filter(p=>p.quantity>1e-9);
}
export function sanitizeBackup(raw:unknown):LocalStore {
 if(!raw||typeof raw!=='object')throw new Error('Arquivo de backup inválido.');
 const x=raw as Record<string,unknown>;
 if(x.version!==1||!Array.isArray(x.entries)||!Array.isArray(x.watch)||x.entries.length>5000||x.watch.length>100)throw new Error('Formato do backup não suportado.');
 if(!x.entries.every(validEntry))throw new Error('O backup tem movimentações inválidas.');
 const keys=new Set(x.entries.map((e:Entry)=>e.id));
 if(keys.size!==x.entries.length)throw new Error('Backup possui movimentações duplicadas.');
 calcPositions(x.entries);
 if(!x.watch.every(a=>typeof a==='string'&&CODE.test(a)))throw new Error('Lista de ativos inválida.');
 return {
  ...DEFAULT_STORE,
  name:typeof x.name==='string'?x.name.trim().slice(0,70):'',
  theme:x.theme==='light'?'light':'dark',
  level:x.level==='pro'?'pro':'beginner',
  entries:x.entries.map((e:Entry)=>({...e})),
  watch:[...new Set(x.watch as string[])],
  goal:typeof x.goal==='string'?x.goal.slice(0,40):DEFAULT_STORE.goal,
  horizon:typeof x.horizon==='string'?x.horizon.slice(0,40):DEFAULT_STORE.horizon,
  risk:typeof x.risk==='string'?x.risk.slice(0,40):DEFAULT_STORE.risk,
  alerts:typeof x.alerts==='boolean'?x.alerts:true,
  alertThreshold:validNumber(x.alertThreshold,50)&&x.alertThreshold>=1?x.alertThreshold:5,
 };
}
export function isQuoteRecent(q:MarketQuote,at=Date.now()):boolean {
 const time=Date.parse(q.updatedAt);
 return Number.isFinite(time)&&time<=at+60000&&at-time<=30*60*1000&&Number.isFinite(q.price)&&q.price>0;
}
export type MarketSignal = {ticker:string;name:string;movement:number;label:string;reason:string;risk:string;source:string;updatedAt:string};
export function buildMarketSignals(quotes:MarketQuote[],at=Date.now()):MarketSignal[]{
 return quotes.filter(q=>isQuoteRecent(q,at)&&q.change!==null&&Number.isFinite(q.change)&&Math.abs(q.change)>=3)
  .sort((a,b)=>Math.abs(b.change!)-Math.abs(a.change!))
  .map(q=>({ticker:q.ticker,name:q.name,movement:q.change!,label:Math.abs(q.change!)>=10?'Oscilação muito forte':'Movimento relevante',
   reason:`Variação observada de ${q.change!>0?'+':''}${q.change!.toFixed(2)}% nas últimas 24h, conforme a fonte.`,
   risk:'Criptoativos podem sofrer perdas rápidas. Uma alta não implica que continuará subindo e uma queda não garante recuperação.',
   source:q.source,updatedAt:q.updatedAt}));
}
export function buildLocalAlerts(quotes:MarketQuote[],watch:string[],threshold:number,at=Date.now()):MarketSignal[]{
 if(!Number.isFinite(threshold)||threshold<1||threshold>50)return [];
 const included=new Set(watch);
 return buildMarketSignals(quotes,at).filter(s=>included.has(s.ticker)&&Math.abs(s.movement)>=threshold);
}
export function categoryConcentration(positions:Position[]) {
 const totals=new Map<Category,number>();
 for(const p of positions)totals.set(p.category,(totals.get(p.category)||0)+p.cost);
 const total=[...totals.values()].reduce((a,b)=>a+b,0);
 return [...totals.entries()].sort((a,b)=>b[1]-a[1]).map(([category,cost])=>({category,cost,percentage:total>0?100*cost/total:0}));
}
