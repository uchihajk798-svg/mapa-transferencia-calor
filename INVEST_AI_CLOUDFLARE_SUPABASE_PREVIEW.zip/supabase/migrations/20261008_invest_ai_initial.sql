-- INVEST AI / Supabase Free
-- Execute no Supabase SQL Editor como proprietário do projeto.
-- Cada usuário só pode consultar seus próprios dados.
CREATE TABLE IF NOT EXISTS public.invest_ai_backups (
    user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    revision bigint NOT NULL DEFAULT 1 CHECK (revision > 0),
    data jsonb NOT NULL CHECK (jsonb_typeof(data) = 'object'),
    updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.invest_ai_backups ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.invest_ai_backups FROM anon;
GRANT SELECT ON public.invest_ai_backups TO authenticated;
-- Writes are done only by validated RPC, not directly by the client.
REVOKE INSERT, UPDATE, DELETE ON public.invest_ai_backups FROM authenticated;

DROP POLICY IF EXISTS "INVEST AI own backup read" ON public.invest_ai_backups;
CREATE POLICY "INVEST AI own backup read" ON public.invest_ai_backups
    FOR SELECT TO authenticated USING ((SELECT auth.uid()) = user_id);

-- Invoker is required to be logged in; the function owner may bypass RLS
-- but all writes target auth.uid() only. Atomic optimistic concurrency.
CREATE OR REPLACE FUNCTION public.invest_ai_save_backup(p_expected_revision bigint, p_data jsonb)
RETURNS bigint
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
    v_user uuid := auth.uid();
    v_revision bigint;
BEGIN
    IF v_user IS NULL THEN
      RAISE EXCEPTION 'Sessão inválida' USING ERRCODE = '28000';
    END IF;
    IF p_expected_revision IS NULL OR p_expected_revision < 0 THEN
      RAISE EXCEPTION 'Versão esperada inválida';
    END IF;
    IF p_data IS NULL OR pg_catalog.jsonb_typeof(p_data) <> 'object'
       OR p_data->>'version' <> '1' OR pg_catalog.octet_length(p_data::text) > 600000 THEN
      RAISE EXCEPTION 'Arquivo de backup inválido ou muito grande';
    END IF;
    INSERT INTO public.invest_ai_backups(user_id, revision, data)
      VALUES(v_user, 1, p_data)
    ON CONFLICT (user_id) DO UPDATE
      SET revision = public.invest_ai_backups.revision + 1,
          data = EXCLUDED.data,
          updated_at = now()
      WHERE public.invest_ai_backups.revision = p_expected_revision
    RETURNING revision INTO v_revision;
    IF v_revision IS NULL THEN
      RAISE EXCEPTION 'Conflito de versão: recarregue o backup remoto antes de salvar';
    END IF;
    RETURN v_revision;
END;
$$;
REVOKE ALL ON FUNCTION public.invest_ai_save_backup(bigint, jsonb) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.invest_ai_save_backup(bigint, jsonb) TO authenticated;

-- Only server-validated requests can claim an AI credit through an atomic function.
CREATE TABLE IF NOT EXISTS public.invest_ai_ai_usage (
   user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
   usage_day date NOT NULL,
   request_count integer NOT NULL CHECK (request_count BETWEEN 0 AND 12),
   PRIMARY KEY (user_id, usage_day)
);
ALTER TABLE public.invest_ai_ai_usage ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.invest_ai_ai_usage FROM anon, authenticated;

CREATE OR REPLACE FUNCTION public.invest_ai_claim_ai_quota()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
    v_user uuid := auth.uid();
    v_count integer;
BEGIN
    IF v_user IS NULL THEN
        RAISE EXCEPTION 'Sessão inválida' USING ERRCODE = '28000';
    END IF;
    INSERT INTO public.invest_ai_ai_usage(user_id, usage_day, request_count)
        VALUES (v_user, (now() AT TIME ZONE 'UTC')::date, 1)
    ON CONFLICT(user_id, usage_day) DO UPDATE
        SET request_count = public.invest_ai_ai_usage.request_count + 1
        WHERE public.invest_ai_ai_usage.request_count < 12
    RETURNING request_count INTO v_count;
    IF v_count IS NULL THEN
        RAISE EXCEPTION 'Limite gratuito de 12 perguntas atingido hoje';
    END IF;
    RETURN v_count;
END;
$$;
REVOKE ALL ON FUNCTION public.invest_ai_claim_ai_quota() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.invest_ai_claim_ai_quota() TO authenticated;
