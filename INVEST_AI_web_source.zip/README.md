# INVEST AI WEB 0.4 — Site com modo local funcional

Website Next.js exportável como site estático. Acesso inicial sem conta: carteira manual com preço médio móvel, validação de saldo em vendas, histórico, watchlist, simulador editável e educação financeira. Cotações criptográficas são obtidas do endpoint público CoinGecko e podem falhar por limite do provedor/CORS.

Não há autenticação online funcional até que a API FastAPI seja publicada em HTTPS com PostgreSQL, Redis, segredos de produção e configurações de CORS. Em modo local, dados ficam no localStorage e podem ser perdidos. Não usar como registro único de patrimônio.

## Desenvolvimento

```sh
cd frontend
npm install
npm run lint
npm run build
```

A compilação estática produz `frontend/out`. No Render Static Site usar build command `unzip -q -o INVEST_AI_web_source.zip && cd frontend && npm install --no-audit && npm run build` e publish `frontend/out`. Para autenticação, fornecer `NEXT_PUBLIC_API_URL` no build e publicar o backend antes.

## Segurança e escopo

Cotações, quando exibidas, vêm do provedor com data e fonte; nunca simuladas. Sites oficiais de notícias abrem em guias separadas; não há IA automática, alertas ou recomendação personalizada. Carteira é manual e não realiza ordens. Este site não dá garantias de lucro.
