"""Autenticação para cliente nativo sem cookies. Tokens ficam no Keychain/Keystore.

Não substituir por AsyncStorage ou incluir tokens em URLs/logs. API exige HTTPS em produção.
"""
from datetime import timezone
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy import select, update
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import User, InvestorProfile, Preferences, UserSession, utcnow
from ..schemas import RegisterIn, LoginIn, UserOut
from ..security import (
    hash_password, verify_password, create_session, hash_token, generate_refresh,
    issue_access, ACCESS_SECONDS, REFRESH_DAYS, current_user, get_session_from_access,
)
from .auth import audit

router = APIRouter(prefix="/api/mobile/auth", tags=["mobile-auth"])


class RefreshIn(BaseModel):
    refresh_token: str


class SessionTokens(BaseModel):
    user: UserOut
    access_token: str
    refresh_token: str
    access_expires_in: int = ACCESS_SECONDS


def tokens(user: User, session: UserSession, refresh: str):
    return SessionTokens(user=UserOut.model_validate(user), access_token=issue_access(user.id, session.id),
                         refresh_token=f"{session.id}.{refresh}")


@router.post("/register", status_code=201, response_model=SessionTokens)
def mobile_register(payload: RegisterIn, request: Request, db: Session = Depends(get_db)):
    email = str(payload.email).lower()
    if db.scalar(select(User.id).where(User.email == email)):
        raise HTTPException(409, "Este e-mail já possui uma conta")
    user = User(email=email, full_name=payload.full_name.strip(), password_hash=hash_password(payload.password))
    user.profile = InvestorProfile()
    user.preferences = Preferences()
    db.add(user)
    db.flush()
    session, refresh = create_session(db, user, f"Mobile: {request.headers.get('user-agent', '')}")
    audit(db, user.id, "mobile-register")
    db.commit()
    return tokens(user, session, refresh)


@router.post("/login", response_model=SessionTokens)
def mobile_login(payload: LoginIn, request: Request, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == str(payload.email).lower()))
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(401, "E-mail ou senha inválidos")
    session, refresh = create_session(db, user, f"Mobile: {request.headers.get('user-agent', '')}")
    audit(db, user.id, "mobile-login")
    db.commit()
    return tokens(user, session, refresh)


@router.post("/refresh", response_model=SessionTokens)
def mobile_refresh(payload: RefreshIn, db: Session = Depends(get_db)):
    if "." not in payload.refresh_token or len(payload.refresh_token) > 256:
        raise HTTPException(401, "Faça login novamente")
    sid, old_token = payload.refresh_token.split(".", 1)
    session = db.get(UserSession, sid)
    if not session or session.revoked_at or session.expires_at.replace(tzinfo=timezone.utc) <= utcnow():
        raise HTTPException(401, "Sessão expirada")
    new_token = generate_refresh()
    # Atualização condicional garante rotação de uso único, também sob requisições concorrentes.
    result = db.execute(update(UserSession).where(
        UserSession.id == sid,
        UserSession.refresh_hash == hash_token(old_token),
        UserSession.revoked_at.is_(None),
    ).values(refresh_hash=hash_token(new_token)))
    if result.rowcount != 1:
        db.rollback()
        raise HTTPException(401, "Token de atualização inválido ou já utilizado")
    user = db.get(User, session.user_id)
    if not user:
        db.rollback()
        raise HTTPException(401, "Conta indisponível")
    db.commit()
    return tokens(user, session, new_token)


@router.post("/logout")
def mobile_logout(request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)):
    # Authorization Bearer já foi validado pela dependência current_user.
    session = get_session_from_access(request, db)
    session.revoked_at = utcnow()
    audit(db, user.id, "mobile-logout")
    db.commit()
    return {"ok": True}
