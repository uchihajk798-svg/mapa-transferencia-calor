"""Cálculo de posição pelo custo médio móvel; não estima tributos nem cotações."""
from collections import defaultdict
from decimal import Decimal
from datetime import timezone
from fastapi import HTTPException


def positions_from_transactions(transactions):
    state = defaultdict(lambda: {"qty": Decimal("0"), "cost": Decimal("0"), "realized": Decimal("0")})
    for t in sorted(transactions, key=lambda x: (x.traded_at.replace(tzinfo=timezone.utc) if x.traded_at.tzinfo is None else x.traded_at.astimezone(timezone.utc), x.created_at.replace(tzinfo=timezone.utc) if x.created_at.tzinfo is None else x.created_at.astimezone(timezone.utc), x.id)):
        s = state[t.asset_code]
        qty = Decimal(str(t.quantity))
        price = Decimal(str(t.unit_price_brl))
        fee = Decimal(str(t.fee_brl))
        if t.type == "BUY":
            s["cost"] += qty * price + fee
            s["qty"] += qty
        elif t.type == "SELL":
            if qty > s["qty"]:
                raise HTTPException(422, "Venda maior que o saldo registrado")
            avg = s["cost"] / s["qty"] if s["qty"] else Decimal("0")
            s["cost"] -= avg * qty
            s["qty"] -= qty
            s["realized"] += (qty * price - fee) - avg * qty
            if s["qty"] == 0:
                s["cost"] = Decimal("0")
        else:
            raise HTTPException(422, "Tipo de movimentação inválido")
    return [{"asset_code": key, "quantity": str(round(values["qty"], 10)), "cost_basis_brl": str(round(values["cost"], 2)), "average_price_brl": str(round(values["cost"] / values["qty"], 2)) if values["qty"] else "0.00", "realized_result_brl": str(round(values["realized"], 2))} for key, values in sorted(state.items()) if values["qty"] or values["realized"]]
