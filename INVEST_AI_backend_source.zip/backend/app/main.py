from collections import defaultdict, deque
from datetime import datetime, timezone
import time
from threading import Lock
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text
from sqlalchemy.orm import Session
from fastapi import Depends
from .database import get_db
from .config import get_settings
from .api.auth import router as auth_router
from .api.finance import router as finance_router
from .api.market import router as market_router
from .api.mobile import router as mobile_router

settings = get_settings()
app = FastAPI(title="INVEST AI API", version="0.1.0", description="Etapa 1 + carteira manual e fontes públicas limitadas. Sem execução de ordens.")
app.add_middleware(CORSMiddleware, allow_origins=settings.origins, allow_credentials=True, allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"], allow_headers=["Content-Type"])
app.include_router(auth_router)
app.include_router(finance_router)
app.include_router(market_router)
app.include_router(mobile_router)

# Em produção, use Redis para limitação distribuída entre réplicas.
rate_window = defaultdict(deque)
rate_lock = Lock()
redis_client = None
if settings.redis_url:
    try:
        from redis import Redis
        redis_client = Redis.from_url(settings.redis_url, socket_connect_timeout=2)
    except ImportError:
        if settings.app_env == "production":
            raise RuntimeError("Instale redis para controle de taxa distribuído")


@app.middleware("http")
async def security_middleware(request: Request, call_next):
    # Proteção básica contra CSRF via origem + cookies SameSite=Lax (não é CSRF token completo).
    if request.method in ("POST", "PUT", "PATCH", "DELETE"):
        origin = request.headers.get("origin")
        if origin and origin.rstrip("/") not in settings.origins:
            return JSONResponse({"detail": "Origem não autorizada"}, status_code=403)
    if (request.url.path.startswith("/api/auth/") or request.url.path.startswith("/api/mobile/auth/")) and request.method == "POST":
        ip = request.client.host if request.client else "unknown"
        key = f"auth:{ip}:{request.url.path}"
        try:
            if redis_client:
                count = redis_client.incr(key)
                if count == 1:
                    redis_client.expire(key, 60)
                blocked = count > 15
            else:
                now = time.monotonic()
                with rate_lock:
                    values = rate_window[key]
                    while values and now - values[0] > 60:
                        values.popleft()
                    values.append(now)
                    blocked = len(values) > 15
            if blocked:
                return JSONResponse({"detail": "Muitas tentativas. Aguarde um minuto."}, status_code=429)
        except Exception:
            if settings.app_env == "production":
                return JSONResponse({"detail": "Controle de acesso temporariamente indisponível"}, status_code=503)
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Cache-Control"] = "no-store" if request.url.path.startswith("/api/me") else "no-cache"
    return response


@app.get("/api/health")
def health(db: Session = Depends(get_db)):
    try:
        db.execute(text("SELECT 1"))
    except Exception:
        return JSONResponse({"status": "database_unavailable"}, status_code=503)
    if redis_client and settings.app_env == "production":
        try:
            redis_client.ping()
        except Exception:
            return JSONResponse({"status": "cache_unavailable"}, status_code=503)
    return {"status": "ok", "time": datetime.now(timezone.utc).isoformat(), "version": "0.1.0"}
