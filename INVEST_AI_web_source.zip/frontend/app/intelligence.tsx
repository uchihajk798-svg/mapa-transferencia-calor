'use client';
import {useState} from 'react';
import {ArrowRight, ExternalLink, Globe2, Info, RefreshCcw, Send, ShieldAlert, Sparkles, WandSparkles} from 'lucide-react';
import {explainQuestion} from '@/lib/intelligence';
import type {MacroValue,NewsItem} from '@/lib/intelligence';
import type {LocalStore,MarketQuote,Position} from '@/lib/local-finance';
import './intelligence.css';

export function GlobalPanel({news,macro,loading,error,onReload}:{news:NewsItem[];macro:MacroValue[];loading:boolean;error:string;onReload:()=>void}){
 const[filter,setFilter]=useState('Todos');
 const topics=['Todos',...new Set(news.map(n=>n.topic))];
 const visible=filter==='Todos'?news:news.filter(n=>n.topic===filter);
 return <>
  <div className="gtitle"><div><span className="geye"><Globe2 size={15}/> INVEST AI GLOBAL INTELLIGENCE</span><h1>O mundo mexe com seus investimentos</h1><p>Radar de notícias econômicas com fonte, data e possíveis canais de impacto.</p></div><button className="gsecondary" onClick={onReload} disabled={loading}><RefreshCcw size={16}/>{loading?'Consultando…':'Atualizar fontes'}</button></div>
  <div className="gcard"><div className="gsection"><h2>Indicadores do Brasil</h2><p>Dados públicos oficiais consultados diretamente no Banco Central. Data de referência do dado, não promessa de retorno.</p></div><div className="gmacrogrid">{macro.map(m=><a key={m.code} className="gmacro" href={m.source} rel="noopener noreferrer" target="_blank"><small>{m.name} <ExternalLink size={12}/></small><strong>{m.value.toLocaleString('pt-BR',{maximumFractionDigits:2})}%</strong><span>{m.unit} · ref. {m.date}</span></a>)}{!macro.length&&<div className="ginlineinfo"><Info size={16}/> Indicadores oficiais indisponíveis ou bloqueados pelo navegador agora; nenhum valor será estimado.</div>}</div></div>
  <div className="gcard"><div className="gsection"><span className="geye">RADAR MUNDIAL</span><h2>Notícias e decisões de governos</h2><p>Dados agregados pelo GDELT, com identificação do veículo original. As notícias ainda não passaram por verificação editorial independente.</p></div>
   {error&&<div className="ginlinewarn"><ShieldAlert size={16}/>{error}</div>}
   <div className="gfilterbar">{topics.map(t=><button key={t} className={filter===t?'gprimary':'gsecondary'} onClick={()=>setFilter(t)}>{t}</button>)}</div>
   {loading&&!news.length&&<p className="gmuted">Buscando publicações recentes e fontes...</p>}
   {!loading&&!news.length&&<div className="gempty"><Globe2 size={28}/><h3>Nenhuma notícia confirmada pela consulta</h3><p>Tente atualizar mais tarde. O serviço público pode limitar requisições ou ficar indisponível.</p><button className="gsecondary" onClick={onReload}>Tentar novamente</button></div>}
   {visible.map(n=><article key={n.url} className="gnews"><div className="gnewsmeta"><span>{n.topic}</span><span>Relevância temática {n.score}/100</span></div><h3>{n.title}</h3><div className="gnewssource">{n.domain} · {new Date(n.publishedAt).toLocaleString('pt-BR')}{n.country?' · '+n.country:''}</div><div className="gnewsimpact"><strong>Possível impacto — hipótese, não conclusão</strong>{n.implications.map((i,k)=><p key={k}>• {i}</p>)}</div><a href={n.url} rel="noopener noreferrer" target="_blank">Ler publicação original <ExternalLink size={14}/></a></article>)}
   <div className="ginlineinfo"><Info size={16}/> O índice de relevância é calculado por regras de termos no título, não mede veracidade, urgência, chance de lucro nem recomendações. Consulte mais de uma fonte antes de agir.</div>
  </div>
 </>;
}

type ChatMessage={role:'user'|'assistant';content:string;mode?:'local'|'gemini';sources?:{label:string;url:string}[]};
const SUGGESTIONS=['Analise a minha carteira e concentração','Como juros altos afetam os investimentos?','O que aconteceu na economia mundial?','É hora de comprar ou vender Bitcoin?'];
export function AdvisorPanel({store,positions,quotes,news,macro,onOpenGlobal,token,onLogin}:{store:LocalStore;positions:Position[];quotes:MarketQuote[];news:NewsItem[];macro:MacroValue[];onOpenGlobal:()=>void;token:string;onLogin:()=>void}){
 const[input,setInput]=useState('');const[messages,setMessages]=useState<ChatMessage[]>([]);
 const[mode,setMode]=useState<'local'|'gemini'>('local');const[busy,setBusy]=useState(false);const[error,setError]=useState('');
 const ask=async(value:string)=>{const q=value.trim().slice(0,600);if(q.length<3||busy)return;setError('');
  if(mode==='gemini'&&!token){setError('Entre na conta online para usar a IA gratuita. Enquanto isso, escolha o modo explicativo.');return}
  setMessages(s=>[...s.slice(-18),{role:'user',content:q}]);setInput('');
  if(mode==='local'){
    const ans=explainQuestion(q,{store,positions,quotes,news,macro});
    setMessages(s=>[...s.slice(-18),{role:'assistant',content:ans.text,sources:ans.sources,mode:'local'}]);return;
  }
  setBusy(true);
  try{
    const base=process.env.NEXT_PUBLIC_API_URL;
    if(!base?.startsWith('https://'))throw new Error('API HTTPS ainda não configurada.');
    const response=await fetch(`${base}/api/ai/explain`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({question:q})});
    const body=await response.json();
    if(!response.ok)throw new Error(typeof body.detail==='string'?body.detail:`Servidor indisponível (${response.status})`);
    if(typeof body.answer!=='string')throw new Error('Resposta de IA inválida.');
    setMessages(s=>[...s.slice(-18),{role:'assistant',content:body.answer,mode:'gemini'}]);
  }catch(e){setError(e instanceof Error?e.message:'Falha na IA gratuita.')}finally{setBusy(false)}
 };
 return <>
  <div className="gtitle"><div><span className="geye"><Sparkles size={15}/> ANALISTA INVEST AI</span><h1>Entenda antes de investir</h1><p>Pergunte em português. O assistente usa seus registros locais, cotações e notícias disponíveis para explicar riscos e cenários.</p></div></div>
  <div className="ginlineinfo gia-mode"><Info size={18}/><div><strong>Você escolhe o tipo de resposta.</strong> O modo explicativo funciona sem conta e usa regras verificáveis. O Gemini gratuito requer conta e chave gratuita configurada pelo administrador. Perguntas do modo generativo são enviadas ao Google; sua carteira local nunca é enviada automaticamente.</div></div>
  <div className="grow"><button type="button" className={mode==='local'?'gprimary':'gsecondary'} onClick={()=>setMode('local')}>Explicação local · grátis</button><button type="button" className={mode==='gemini'?'gprimary':'gsecondary'} onClick={()=>setMode('gemini')}>IA Gemini Flash-Lite · gratuita*</button>{mode==='gemini'&&!token&&<button type="button" className="gsecondary" onClick={onLogin}>Entrar na conta</button>}</div>
  <div className="gcards"><div className="gcard"><span className="gkicker">CARTEIRA DISPONÍVEL PARA ANÁLISE</span><h3>{positions.length} posições</h3><p>Calculadas apenas dos lançamentos salvos neste navegador.</p></div><div className="gcard"><span className="gkicker">FONTES DISPONÍVEIS</span><h3>{quotes.length} cotações · {news.length} notícias</h3><p>Notícias do GDELT e dados econômicos do BCB, quando acessíveis.</p><button className="gtextbtn" onClick={onOpenGlobal}>Abrir radar global <ArrowRight size={15}/></button></div></div>
  <div className="gcard gia-panel"><div className="gia-head"><WandSparkles size={23}/><div><strong>Assistente financeiro educativo</strong><small>Análise contextual baseada nos dados que existem, sem previsão de retorno</small></div></div>
   {!messages.length&&<><p className="gmuted">Escolha uma pergunta para começar ou escreva a sua. Nenhuma operação de compra ou venda será executada.</p><div className="gia-suggestions">{SUGGESTIONS.map(q=><button className="gsecondary" key={q} onClick={()=>ask(q)}>{q} <ArrowRight size={14}/></button>)}</div></>}
   {messages.map((m,i)=><div key={i} className={`gia-message ${m.role==='user'?'gia-user':'gia-bot'}`}><div className="gia-message-label">{m.role==='user'?'Você':m.mode==='gemini'?'INVEST AI · Gemini gratuito':'INVEST AI · explicação automatizada'}</div>{m.content.split('\n').map((line,j)=><p key={j}>{line.replace(/\*\*/g,'')}</p>)}{m.sources?.length?<div className="gia-sources">Fontes: {m.sources.map(s=><a key={s.url} href={s.url} target="_blank" rel="noopener noreferrer">{s.label} <ExternalLink size={12}/></a>)}</div>:null}</div>)}
   {error&&<div className="ginlinewarn"><ShieldAlert size={16}/>{error}</div>}
   <form className="gia-form" onSubmit={e=>{e.preventDefault();void ask(input)}}><label htmlFor="gia-question" className="gia-sr">Pergunta ao assistente financeiro</label><textarea id="gia-question" value={input} maxLength={600} rows={2} onChange={e=>setInput(e.target.value)} placeholder="Ex.: Minha carteira está arriscada? O que é Selic?"/><button className="gprimary" type="submit" disabled={!input.trim()||busy}><Send size={17}/> {busy?'Consultando…':'Enviar'}</button></form>
   <p className="gmuted gmini">*O provedor Google tem limite gratuito, e o INVEST AI limita a 12 perguntas por conta/dia. Se a quota acabar, não haverá cobrança automática por este app. Não compartilhe senhas nem dados sensíveis. Informações educativas, não aconselhamento financeiro.</p>
  </div>
 </>;
}
