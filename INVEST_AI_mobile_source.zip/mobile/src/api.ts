import * as SecureStore from 'expo-secure-store';
import type { Tokens, User } from './types';

const API_URL = (process.env.EXPO_PUBLIC_API_URL || '').replace(/\/$/, '');
const SESSION_KEY = 'investai.refresh.v1';
let accessToken: string | null = null;
let refreshInProgress: Promise<User> | null = null;

export class ApiError extends Error {
  constructor(message:string, public status = 0) {super(message);this.name = 'ApiError';}
}
export function apiConfigured(){return /^https?:\/\//.test(API_URL);}
function url(path:string) {
  if (!apiConfigured()) throw new ApiError('Configure EXPO_PUBLIC_API_URL em mobile/.env antes de entrar.');
  if (!__DEV__ && !API_URL.startsWith('https://')) {
    throw new ApiError('A versão distribuída exige uma API hospedada em HTTPS para proteger seus dados.');
  }
  return API_URL + '/api' + path;
}
async function parse<T>(response:Response):Promise<T> {
  const value:unknown = await response.json().catch(()=>null);
  if (!response.ok) {
    const obj = value && typeof value==='object'? value as Record<string,unknown> : {};
    const detail = obj.detail;
    const msg = typeof detail==='string'?detail:Array.isArray(detail)?'Confira os campos informados.':`Erro HTTP ${response.status}`;
    throw new ApiError(msg,response.status);
  }
  return value as T;
}
async function fetchApi<T>(path:string,init:RequestInit={}) {
  try {
    return await parse<T>(await fetch(url(path),{
      ...init,
      headers:{'Content-Type':'application/json',...(init.headers||{})}
    }));
  } catch(e) {
    if (e instanceof ApiError) throw e;
    throw new ApiError('Não foi possível conectar à API. Verifique o endereço e se o servidor está online.');
  }
}
async function saveTokens(data:Tokens) {
  // A renovação fica persistida SOMENTE no cofre protegido do aparelho.
  await SecureStore.setItemAsync(SESSION_KEY,data.refresh_token);
  accessToken=data.access_token;
}
export async function register(full_name:string,email:string,password:string) {
  const data=await fetchApi<Tokens>('/mobile/auth/register',{method:'POST',body:JSON.stringify({full_name,email,password})});
  await saveTokens(data);return data.user;
}
export async function login(email:string,password:string){
  const data=await fetchApi<Tokens>('/mobile/auth/login',{method:'POST',body:JSON.stringify({email,password})});
  await saveTokens(data);return data.user;
}
export async function resetLocalSession() {
  accessToken=null;
  await SecureStore.deleteItemAsync(SESSION_KEY);
}
export async function refreshSession():Promise<User> {
  if(refreshInProgress)return refreshInProgress;
  refreshInProgress=(async()=>{
    const old=await SecureStore.getItemAsync(SESSION_KEY);
    if(!old)throw new ApiError('Entre na sua conta novamente.',401);
    try {
      const next=await fetchApi<Tokens>('/mobile/auth/refresh',{method:'POST',body:JSON.stringify({refresh_token:old})});
      await saveTokens(next);
      return next.user;
    }catch(e){
      // Falha de rede não apaga o login; token recusado pelo servidor apaga.
      if(e instanceof ApiError && e.status===401)await resetLocalSession();
      throw e;
    }
  })();
  try {return await refreshInProgress;}finally{refreshInProgress=null;}
}
export async function restoreSession() {
  const saved=await SecureStore.getItemAsync(SESSION_KEY);
  if(!saved)return null;
  return refreshSession();
}
export async function api<T>(path:string,method='GET',body?:unknown):Promise<T>{
  if(!accessToken) await refreshSession();
  const execute=()=>fetchApi<T>(path,{method,body:body===undefined?undefined:JSON.stringify(body),headers:{'Authorization':`Bearer ${accessToken}`}});
  try {return await execute();}catch(e){
    if(e instanceof ApiError && e.status===401){await refreshSession();return execute();}
    throw e;
  }
}
export async function logout(){
  try {if(accessToken)await api('/mobile/auth/logout','POST');}
  finally{await resetLocalSession();}
}
export async function requestReset(email:string){return fetchApi<{message:string}>('/auth/password-reset/request',{method:'POST',body:JSON.stringify({email})});}
export async function confirmReset(token:string,new_password:string){return fetchApi('/auth/password-reset/confirm',{method:'POST',body:JSON.stringify({token,new_password})});}
