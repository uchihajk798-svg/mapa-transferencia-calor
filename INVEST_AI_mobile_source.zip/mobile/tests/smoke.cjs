/* Execute após npm install (usa o compilador TS como dependência de desenvolvimento). */
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const ts=require('typescript');
const dir=path.resolve(__dirname,'..');
const source=fs.readFileSync(path.join(dir,'src/simulator.ts'),'utf8');
const transpiled=ts.transpileModule(source,{fileName:'simulator.ts',reportDiagnostics:true,compilerOptions:{target:ts.ScriptTarget.ES2020,module:ts.ModuleKind.CommonJS}});
assert.equal((transpiled.diagnostics||[]).length,0,'O arquivo do simulador contém erro de sintaxe');
const m={exports:{}};
new Function('module','exports',transpiled.outputText)(m,m.exports);
const {calculateScenario}=m.exports;
const base={initial:100,monthly:0,years:1,rate:0,inflation:0,tax:0};
const v=calculateScenario(base);
assert(Math.abs(v.net-100)<1e-7);
assert.equal(v.invested,100);
const comp=calculateScenario({...base,rate:10});
assert(Math.abs(comp.net-110)<1e-7);
const taxed=calculateScenario({...base,rate:10,tax:20});
assert(Math.abs(taxed.net-108)<1e-7);
const aportes=calculateScenario({...base,monthly:20});
assert.equal(aportes.invested,340);
assert(Math.abs(aportes.net-340)<1e-7);
assert.equal(calculateScenario({...base,years:-1}),null);
assert.equal(calculateScenario({...base,tax:101}),null);
for(const file of ['App.tsx','src/api.ts','src/types.ts','src/simulator.ts','src/offline.ts','src/publicMarkets.ts','src/OfflineApp.tsx']) {
 const f=path.join(dir,file),src=fs.readFileSync(f,'utf8');
 const result=ts.transpileModule(src,{fileName:file,reportDiagnostics:true,compilerOptions:{jsx:ts.JsxEmit.ReactJSX,target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}});
 assert.equal((result.diagnostics||[]).length,0,`${file} tem erro de sintaxe`);
}

const offlineSource=fs.readFileSync(path.join(dir,'src/offline.ts'),'utf8');
const offlineTranspiled=ts.transpileModule(offlineSource,{fileName:'offline.ts',compilerOptions:{target:ts.ScriptTarget.ES2020,module:ts.ModuleKind.CommonJS}});
const offlineModule={exports:{}};
new Function('module','exports',offlineTranspiled.outputText)(offlineModule,offlineModule.exports);
const {positionsFromTrades,validateTrade,inputNumber,validateLocal}=offlineModule.exports;
const buy={id:'a',symbol:'BTC',kind:'BUY',quantity:2,price:100,fee:2,date:'2026-10-08T00:00:00.000Z'};
const sell={id:'b',symbol:'BTC',kind:'SELL',quantity:1,price:150,fee:1,date:'2026-10-08T01:00:00.000Z'};
const result=positionsFromTrades([sell,buy]);
assert.equal(result.length,1);
assert.equal(result[0].quantity,1);
assert.equal(result[0].cost,101);
assert.equal(result[0].average,101);
assert.equal(result[0].realized,48);
assert.equal(inputNumber('1.234,56'),1234.56);
assert.equal(inputNumber('0,015'),0.015);
assert(validateTrade([buy],{...sell,quantity:3}).includes('acima'));
assert.equal(validateTrade([buy],sell),null);
assert.equal(validateLocal(null).version,1);
assert.throws(()=>positionsFromTrades([sell]));
console.log('7 testes de cálculo + 11 testes de carteira local + 7 verificações de sintaxe concluídas.');

