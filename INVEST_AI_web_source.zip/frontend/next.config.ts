import type { NextConfig } from 'next';
const config: NextConfig = { output: 'export', reactStrictMode: true, poweredByHeader: false, images: {unoptimized:true}, trailingSlash:true };
export default config;
