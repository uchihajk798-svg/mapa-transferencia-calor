import hashlib
import secrets
from datetime import timedelta, timezone, datetime
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, VerificationError
import jwt
from fastapi import Request, HTTPException, Depends
from sqlalchemy.orm import Session
from .config import get_settings
from .database import get_db
from .models import User, UserSession, utcnow

hasher = PasswordHasher(time_cost=2, memory_cost=19456, parallelism=2)
ACCESS_SECONDS = 15 * 60
REFRESH_DAYS = 14


def hash_password(value: str) -> str:
    return hasher.hash(value)


def verify_password(value: str, hash_value: str) -> bool:
    try:
        return hasher.verify(hash_value, value)
    except (VerifyMismatchError, VerificationError):
        return False


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def generate_refresh() -> str:
    return secrets.token_urlsafe(48)


def issue_access(user_id: str, session_id: str) -> str:
    now = utcnow()
    return jwt.encode({"sub": user_id, "sid": session_id, "iat": now, "exp": now + timedelta(seconds=ACCESS_SECONDS), "typ": "access"}, get_settings().jwt_secret, algorithm="HS256")


def set_auth_cookies(response, user: User, session: UserSession, refresh: str):
    secure = get_settings().cookie_secure
    response.set_cookie("invest_access", issue_access(user.id, session.id), max_age=ACCESS_SECONDS, httponly=True, secure=secure, samesite="lax", path="/")
    response.set_cookie("invest_refresh", f"{session.id}.{refresh}", max_age=REFRESH_DAYS * 86400, httponly=True, secure=secure, samesite="lax", path="/api/auth")


def clear_auth_cookies(response):
    response.delete_cookie("invest_access", path="/")
    response.delete_cookie("invest_refresh", path="/api/auth")


def get_session_from_access(request: Request, db: Session) -> UserSession:
    # Nativo: bearer token no cabeçalho. Web: cookie httpOnly existente.
    authorization = request.headers.get("authorization", "")
    if authorization:
        parts = authorization.split()
        if len(parts) != 2 or parts[0].lower() != "bearer" or not parts[1]:
            raise HTTPException(401, "Autorização inválida")
        token = parts[1]
    else:
        token = request.cookies.get("invest_access")
    if not token:
        raise HTTPException(401, "Entre na sua conta")
    try:
        claims = jwt.decode(token, get_settings().jwt_secret, algorithms=["HS256"], options={"require": ["exp", "iat", "sub", "sid"]})
        if claims.get("typ") != "access":
            raise ValueError("Tipo inválido")
    except (jwt.PyJWTError, ValueError):
        raise HTTPException(401, "Sessão expirada") from None
    active = db.get(UserSession, claims["sid"])
    if not active or active.user_id != claims["sub"] or active.revoked_at or active.expires_at.replace(tzinfo=timezone.utc) <= utcnow():
        raise HTTPException(401, "Sessão inválida")
    return active


def current_user(request: Request, db: Session = Depends(get_db)) -> User:
    active = get_session_from_access(request, db)
    user = db.get(User, active.user_id)
    if not user:
        raise HTTPException(401, "Usuário indisponível")
    return user


def create_session(db: Session, user: User, user_agent: str):
    refresh = generate_refresh()
    session = UserSession(user_id=user.id, user_agent=user_agent[:255], refresh_hash=hash_token(refresh), expires_at=utcnow() + timedelta(days=REFRESH_DAYS))
    db.add(session)
    db.flush()
    return session, refresh
