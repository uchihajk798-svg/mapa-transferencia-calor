from fastapi import HTTPException
import pytest
from app.api.ai import ExplainIn, ask_model, SYSTEM


def test_ai_requires_session(client):
    r = client.post('/api/ai/explain', json={'question': 'O que é Selic?'})
    assert r.status_code == 401


def test_ai_config_not_faked_for_authenticated_user(registered):
    r = registered.post('/api/ai/explain', json={'question': 'Explique renda fixa'})
    assert r.status_code == 503
    assert 'não configurada' in r.json()['detail']


def test_ai_rejects_short_or_huge_queries(registered):
    assert registered.post('/api/ai/explain', json={'question': 'x'}).status_code == 422
    assert registered.post('/api/ai/explain', json={'question': 'A'*601}).status_code == 422


def test_ai_safety_prompt_contains_source_restriction():
    assert 'cotações, notícias' in SYSTEM
