def test_auth_cookie_sessions_and_rotation(client):
    data={"email":"aluno@example.com", "password":"senha-muito-longa-456", "full_name":"Conta de Teste"}
    res=client.post('/api/auth/register',json=data)
    assert res.status_code==201, res.text
    assert res.json()['email']=='aluno@example.com'
    assert 'httponly' in res.headers['set-cookie'].lower()
    assert client.get('/api/me').status_code==200
    assert client.post('/api/auth/register',json=data).status_code==409
    assert client.post('/api/auth/login',json={"email":data['email'],"password":"errada"}).status_code==401
    cookies_before=client.cookies.get('invest_refresh')
    rotated=client.post('/api/auth/refresh')
    assert rotated.status_code==200
    assert client.cookies.get('invest_refresh')!=cookies_before
    sessions=client.get('/api/me/sessions').json()
    assert len(sessions)==1 and sessions[0]['current']
    assert client.post('/api/auth/logout').status_code==200
    assert client.get('/api/me').status_code==401
    assert client.post('/api/auth/refresh').status_code==401
    assert client.post('/api/auth/login',json={"email":data['email'],"password":data['password']}).status_code==200


def test_password_reset_dependency_is_explicit(client):
    res=client.post('/api/auth/password-reset/request',json={"email":"a@example.com"})
    assert res.status_code==503
    assert 'SMTP' in res.json()['detail']


def test_profile_and_prefs(registered):
    client=registered
    profile={"experience":"intermediate","goal":"reserve","horizon":"short","liquidity":"immediate","risk_tolerance":"low","interests":["fixed"],"onboarding_completed":True}
    assert client.put('/api/me/investor-profile',json=profile).status_code==200
    assert client.get('/api/me/investor-profile').json()==profile
    prefs={"theme":"light","level":"professional","notifications_enabled":False,"digest":"off"}
    assert client.put('/api/me/preferences',json=prefs).status_code==200
    assert client.get('/api/me/preferences').json()==prefs
    assert client.patch('/api/me',json={"full_name":"Outra Pessoa"}).json()['full_name']=='Outra Pessoa'
    assert client.request('DELETE','/api/me',json={"password":"senha errada"}).status_code==403
    assert client.request('DELETE','/api/me',json={"password":"muito-segura-123"}).status_code==200
    assert client.get('/api/me').status_code==401


def test_origin_check(registered):
    assert registered.post('/api/auth/logout',headers={"Origin":"https://evil.invalid"}).status_code==403
    assert registered.get('/api/me').status_code==200


def test_session_revoke_other_device(registered):
    client=registered
    first=client.get('/api/me/sessions').json()[0]['id']
    assert client.post('/api/auth/login',json={"email":"pessoa@example.com", "password":"muito-segura-123"}).status_code==200
    sessions=client.get('/api/me/sessions').json()
    assert len(sessions)==2
    assert client.delete(f'/api/me/sessions/{first}').status_code==200
    assert len(client.get('/api/me/sessions').json())==1


def test_revoke_current_session(registered):
    client=registered
    sid=client.get('/api/me/sessions').json()[0]['id']
    assert client.delete(f'/api/me/sessions/{sid}').status_code==200
    assert client.get('/api/me').status_code==401


def test_invalid_name_and_origin(registered):
    assert registered.patch('/api/me', json={'full_name':'   '}).status_code==422
    assert registered.post('/api/portfolio/transactions', json={"asset_code":"bitcoin", "type":"BUY", "quantity":"1", "unit_price_brl":"100", "traded_at":"2026-01-01T01:00:00"}).status_code==422


def test_data_export_excludes_secrets(registered):
    data=registered.get('/api/me/export')
    assert data.status_code==200
    assert data.json()['account']['email']=='pessoa@example.com'
    assert 'password' not in str(data.json()).lower()
    assert 'token' not in str(data.json()).lower()
    assert registered.get('/api/health').status_code==200
