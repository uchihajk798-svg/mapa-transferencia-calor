/** Contabilidade local educativa. Preços e taxas são inseridos pelo usuário; não há ordens na corretora. */
export type Trade = {id:string;symbol:string;kind:'BUY'|'SELL';quantity:number;price:number;fee:number;date:string};
export type Position = {symbol:string;quantity:number;cost:number;average:number;realized:number};
export type LocalData = {version:1;name:string;trades:Trade[];watchlist:string[];level:'beginner'|'professional';theme:'dark'|'light'};
export const emptyLocal:LocalData = {version:1,name:'',trades:[],watchlist:[],level:'beginner',theme:'dark'};
export function inputNumber(raw:string):number {
  let value=raw.trim().replace(/\s/g,'');
  if (value.includes(',')) value=value.replace(/\./g,'').replace(',','.');
  const parsed=Number(value);
  return value!==''&&Number.isFinite(parsed)?parsed:NaN;
}
export function normalizeSymbol(symbol:string){return symbol.trim().replace(/\s+/g,'').slice(0,22).toUpperCase();}
export function positionsFromTrades(trades:Trade[]):Position[]{
  const balances=new Map<string,Position>();
  for(const t of [...trades].sort((a,b)=>a.date.localeCompare(b.date)||a.id.localeCompare(b.id))){
    if(!Number.isFinite(t.quantity)||t.quantity<=0||!Number.isFinite(t.price)||t.price<0||!Number.isFinite(t.fee)||t.fee<0||!t.symbol.trim()) throw new Error('Movimentação com valores inválidos.');
    const key=normalizeSymbol(t.symbol);
    const p=balances.get(key)||{symbol:key,quantity:0,cost:0,average:0,realized:0};
    if(t.kind==='BUY') {
      p.cost+=t.quantity*t.price+t.fee;
      p.quantity+=t.quantity;
    } else if(t.kind==='SELL'){
      if(t.quantity>p.quantity+1e-9)throw new Error(`Venda de ${key} acima da quantidade disponível.`);
      const avg=p.quantity?p.cost/p.quantity:0;
      p.realized+=t.quantity*t.price-t.fee-avg*t.quantity;
      p.cost-=avg*t.quantity;
      p.quantity=Math.max(0,p.quantity-t.quantity);
      if(p.quantity<1e-9){p.quantity=0;p.cost=0;}
    } else throw new Error('Tipo de movimentação não permitido.');
    p.average=p.quantity?p.cost/p.quantity:0;
    balances.set(key,p);
  }
  return [...balances.values()].filter(p=>p.quantity>0||Math.abs(p.realized)>0.0000001).sort((a,b)=>a.symbol.localeCompare(b.symbol));
}
export function validateTrade(current:Trade[],next:Trade):string|null {
  if(!next.symbol.trim()||!Number.isFinite(next.quantity)||next.quantity<=0||!Number.isFinite(next.price)||next.price<=0||!Number.isFinite(next.fee)||next.fee<0)return 'Informe um ativo, quantidade e preço positivos e taxas não negativas.';
  if(next.quantity>1e12||next.price>1e15||next.fee>1e12)return 'O valor informado está fora do limite aceito.';
  try{positionsFromTrades([...current,next]);return null;}catch(e){return e instanceof Error?e.message:'Movimentação inválida.';}
}
export function validateLocal(raw:unknown):LocalData {
  if(!raw||typeof raw!=='object')return {...emptyLocal};
  const data=raw as Partial<LocalData>;
  if(data.version!==1 || !Array.isArray(data.trades)||!Array.isArray(data.watchlist))return {...emptyLocal};
  const trades=data.trades.filter(t=>t&&typeof t.id==='string'&&typeof t.symbol==='string'&&(t.kind==='BUY'||t.kind==='SELL')&&typeof t.quantity==='number'&&typeof t.price==='number'&&typeof t.fee==='number'&&typeof t.date==='string');
  try{positionsFromTrades(trades);}catch{return {...emptyLocal};}
  return {version:1,name:typeof data.name==='string'?data.name.slice(0,65):'',trades:trades.slice(0,2500),watchlist:data.watchlist.filter(x=>typeof x==='string').slice(0,100),level:data.level==='professional'?'professional':'beginner',theme:data.theme==='light'?'light':'dark'};
}
