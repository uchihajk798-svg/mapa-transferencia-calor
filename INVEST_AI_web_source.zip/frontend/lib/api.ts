const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
export class ApiError extends Error {
  constructor(message: string, public status: number) { super(message); }
}
export async function api<T>(path: string, options: RequestInit = {}, retry = true): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${API}/api${path}`, {
      ...options,
      credentials: 'include',
      headers: { 'Content-Type': 'application/json', ...options.headers },
    });
  } catch { throw new ApiError('Não foi possível conectar ao servidor. Verifique se a API está em execução.', 0); }
  if (res.status === 401 && retry && !path.startsWith('/auth/')) {
    try {
      const r = await fetch(`${API}/api/auth/refresh`, { method: 'POST', credentials: 'include' });
      if (r.ok) return api<T>(path, options, false);
    } catch { /* conexão indisponível */ }
  }
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    const detail = body.detail;
    throw new ApiError(typeof detail === 'string' ? detail : `Falha na requisição (${res.status})`, res.status);
  }
  return res.json() as Promise<T>;
}
export const post = <T>(path: string, data: unknown) => api<T>(path, { method: 'POST', body: JSON.stringify(data) });
export const put = <T>(path: string, data: unknown) => api<T>(path, { method: 'PUT', body: JSON.stringify(data) });
export const patch = <T>(path: string, data: unknown) => api<T>(path, { method: 'PATCH', body: JSON.stringify(data) });
export const del = <T>(path: string, data?: unknown) => api<T>(path, { method: 'DELETE', ...(data ? { body: JSON.stringify(data) } : {}) });
