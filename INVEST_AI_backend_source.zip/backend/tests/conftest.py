import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from app.database import Base, get_db
from app.main import app
from app.main import rate_window
from app import models  # noqa


@pytest.fixture()
def client():
    rate_window.clear()  # limiter state must not leak between independent test cases
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Base.metadata.create_all(engine)
    Local = sessionmaker(bind=engine, expire_on_commit=False)

    def override_db():
        with Local() as db:
            yield db

    app.dependency_overrides[get_db] = override_db
    with TestClient(app, base_url="http://localhost:8000") as client:
        yield client
    app.dependency_overrides.clear()
    engine.dispose()


@pytest.fixture()
def registered(client):
    response = client.post('/api/auth/register', json={"email":"Pessoa@Example.com", "password":"muito-segura-123", "full_name":"Pessoa Teste"})
    assert response.status_code == 201, response.text
    return client
