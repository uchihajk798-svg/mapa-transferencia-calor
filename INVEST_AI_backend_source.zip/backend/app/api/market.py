"""Fontes públicas: CoinGecko / Banco Central. Sem dados fabricados."""
from datetime import datetime, timezone, timedelta
from threading import Lock
import httpx
from fastapi import APIRouter, HTTPException

router = APIRouter(prefix="/api/market", tags=["market"])
SUPPORTED = {"bitcoin": "Bitcoin", "ethereum": "Ethereum", "solana": "Solana", "usd-coin": "USD Coin"}
_cache = {}
_lock = Lock()


def cached(key: str, ttl: int, loader):
    now = datetime.now(timezone.utc)
    with _lock:
        entry = _cache.get(key)
        if entry and (now - entry[0]).total_seconds() < ttl:
            return entry[1]
    try:
        value = loader()
    except (httpx.HTTPError, ValueError, KeyError, TypeError) as exc:
        raise HTTPException(status_code=503, detail=f"Fonte externa indisponível ({key}). Tente novamente mais tarde.") from exc
    with _lock:
        _cache[key] = (now, value)
    return value


@router.get("/crypto")
def crypto_quotes():
    def loader():
        with httpx.Client(timeout=8, headers={"User-Agent": "InvestAI/0.1 contact:admin@localhost"}) as client:
            response = client.get("https://api.coingecko.com/api/v3/simple/price", params={"ids": ",".join(SUPPORTED), "vs_currencies": "brl", "include_24hr_change": "true", "include_last_updated_at": "true"})
            response.raise_for_status()
            data = response.json()
        rows = []
        for code, name in SUPPORTED.items():
            item = data.get(code)
            if not item or not isinstance(item.get("brl"), (int, float)) or not isinstance(item.get("last_updated_at"), int):
                continue
            rows.append({"code": code, "name": name, "price_brl": item["brl"], "change_24h_pct": item.get("brl_24h_change"), "updated_at": datetime.fromtimestamp(item["last_updated_at"], timezone.utc).isoformat(), "source": "CoinGecko", "source_url": "https://www.coingecko.com/", "delayed": True})
        if not rows:
            raise ValueError("Sem cotações válidas")
        return {"assets": rows, "note": "Cotação informativa do provedor; pode conter atraso e diferir da corretora. Não constitui recomendação."}
    return cached("crypto", 90, loader)


@router.get("/selic")
def selic_rate():
    def loader():
        with httpx.Client(timeout=8) as client:
            response = client.get("https://api.bcb.gov.br/dados/serie/bcdata.sgs.432/dados/ultimos/1", params={"formato": "json"})
            response.raise_for_status()
            record = response.json()[0]
        value = float(str(record["valor"]).replace(",", "."))
        if not 0 <= value <= 100:
            raise ValueError("Taxa inválida")
        return {"annual_rate_pct": value, "reference_date": record["data"], "source": "Banco Central do Brasil — série SGS 432 (meta Selic)", "source_url": "https://www.bcb.gov.br/controleinflacao/taxaselic", "note": "Meta anual, não rendimento garantido de um produto."}
    return cached("selic", 6 * 3600, loader)
