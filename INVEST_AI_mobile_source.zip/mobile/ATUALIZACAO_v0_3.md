# INVEST AI Mobile 0.3 — correção de experiência sem servidor

## Problema confirmado
O APK 0.2 foi distribuído sem `EXPO_PUBLIC_API_URL` (o endereço HTTPS da API).
O formulário de cadastro chamava `/api/mobile/auth/register`, mas não existia servidor publicado. Isso torna o cadastro/login e as funcionalidades autenticadas indisponíveis.

## O que muda em 0.3
- **Modo local ativado automaticamente** quando a API não está configurada, sem botão de cadastro que sempre falha.
- **Carteira manual local**, com compras, vendas, validação de saldo, cálculo do preço médio, custo histórico, ganho/perda realizados antes de tributos, histórico e exclusão segura de operações.
- **Persistência local** das movimentações, lista de acompanhamento e nome pelo AsyncStorage. Os dados **não estão criptografados** pelo app nem sincronizados; evite informações financeiras sensíveis.
- **Exportação JSON** através do compartilhamento do Android, que contém os registros em texto claro.
- **Consultas diretas** à CoinGecko (quatro moedas) e meta Selic do Banco Central, com data, fonte e mensagem clara quando indisponível. Não garante disponibilidade permanente e não usa dados inventados.
- **Academia com oito temas** em linguagem iniciante/profissional, simulação de cenários e calculadora hipotética de juros compostos.
- **Quatro abas**, com funções identificadas e sem fingir que o radar de IA já está operacional.

## Pendente de infraestrutura — importante
- **Cadastro, recuperação de senha e login reais** só poderão funcionar quando FastAPI/PostgreSQL/Redis estiverem publicados com HTTPS e o APK recompilado com URL da API.
- O modo local não cria uma conta online, não gera recomendações de investimento e não executa ordens.
- IA conversacional, notícias automatizadas, radar completo, alertas push, ações e FIIs em tempo real ainda não foram implementados.
- Ainda será preciso validar o APK em um dispositivo real e com rede móvel.

## Segurança
O armazenamento AsyncStorage serve somente para rascunhos de transações inseridos pelo usuário e não é adequado para senhas, CPF ou dados bancários. Ao desinstalar ou limpar os dados, os registros podem ser perdidos; use o botão de exportação antes de desinstalar. **Não existe sincronização entre o modo local e uma futura conta online.**
