# INVEST AI — como gerar APK no GitHub sem Android Studio

A aplicação Android está escrita com Expo/React Native, mas **este pacote ainda não inclui APK compilado**. Este projeto inclui o workflow `/.github/workflows/android-apk.yml` para solicitar uma compilação usando um computador do GitHub Actions. Esse workflow **ainda não foi testado em um executor GitHub**.

## Opção 1 — Expo EAS Build (recomendada)

1. Tenha uma conta em https://expo.dev/ e configure o projeto no Expo EAS.
2. Em um computador ou terminal cloud com Node.js 22+, instale as dependências e entre na sua conta Expo:

```bash
cd mobile
npm install
npx eas-cli login
npx eas-cli build:configure
npx eas-cli build --platform android --profile preview
```

3. Configure `EXPO_PUBLIC_API_URL` como URL HTTPS da sua API em variáveis de ambiente do projeto Expo antes do build. Sem isso, a versão instalada oferece apenas conteúdo educativo e simulador em modo convidado. A criação de conta/carteira necessita do backend FastAPI hospedado.
4. Após a compilação terminar, use o link do arquivo `.apk` disponibilizado no painel Expo para instalar no Android.

Fonte: https://docs.expo.dev/build-reference/apk/

## Opção 2 — GitHub Actions (não exige conta Expo)

1. Publique a **estrutura de pastas e arquivos extraídos** (não o arquivo ZIP sozinho) em um repositório GitHub privado seu, de preferência com branch `main`.
2. Abra a aba **Actions**, escolha `INVEST AI - Gerar APK Android` e toque em **Run workflow**.
3. A compilação do runner instalará Node.js, Java, o SDK Android, o Expo e o Gradle e tentará executar `assembleRelease`.
4. Se tudo passar, abra a execução e baixe o arquivo `INVEST-AI-Android-APK` na seção **Artifacts**. Ele virá em um ZIP contendo o APK. Se falhar, veja a etapa marcada em vermelho e copie os logs para correção.
5. Para ativar login/carteira, hospede o FastAPI em HTTPS e configure `EXPO_PUBLIC_API_URL` em **Settings > Secrets and variables > Actions > Variables** do repositório. É uma URL **pública**, sem chave secreta.

Este workflow gera um **APK de teste**, não um pacote assinado para distribuição oficial pela Google Play. Antes da publicação, configure assinatura própria e testes de segurança. Não publique `.env`, bancos de dados, chaves ou credenciais.

## Limitações importantes

- Sem a compilação executar em um ambiente com rede e SDK, não é correto afirmar que o APK está pronto ou validado.
- Um APK contém o aplicativo mobile, **não hospeda** FastAPI ou PostgreSQL. Para cadastro, carteira, mercados e notificações é necessário publicar uma API externa segura.
- A versão sem servidor permite abrir as lições e o simulador educativo, mas **não** possui radar automático ou analista IA real.
- O app ainda precisa ser testado em um aparelho Android real depois da compilação.
