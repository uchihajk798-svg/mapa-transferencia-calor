"""Rota opcional de IA generativa, protegida por autenticação e segredos no servidor.

A ausência de OPENAI_API_KEY mantém o endpoint indisponível sem respostas artificiais.
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
import httpx
from ..security import current_user
from ..models import User
from ..config import get_settings

router = APIRouter(prefix="/api/ai", tags=["ai"])

SYSTEM = """Você é o INVEST AI, um assistente educacional em investimentos para brasileiros.
Responda em português do Brasil, de forma simples e objetiva, com destaque para incertezas.
Não faça recomendações personalizadas de compra, venda ou timing, não prometa retornos
nem invente cotações, notícias, decisões de governo, taxas, URLs, datas ou fontes.
Se forem necessários dados recentes, explique que não foram fornecidos nem verificados.
Se o usuário perguntar por movimentações em carteira, informe que só pode comentar posições
quando dados forem explicitamente compartilhados. Não peça senhas ou chaves de corretoras.
Quando relevante, explique impactos possíveis de juros, inflação e decisões públicas,
separando fatos fornecidos, hipóteses e riscos. Evite jargão e seja didático."""

class ExplainIn(BaseModel):
    question: str = Field(min_length=3, max_length=600)

class ExplainOut(BaseModel):
    answer: str
    model: str
    source: str = "openai-api"
    live_market_data: bool = False


def ask_model(question: str) -> ExplainOut:
    settings = get_settings()
    if not settings.openai_api_key:
        raise HTTPException(503, "IA generativa não configurada. O assistente educativo local continua disponível.")
    try:
        with httpx.Client(timeout=22) as client:
            response = client.post(
                "https://api.openai.com/v1/responses",
                headers={"Authorization": f"Bearer {settings.openai_api_key}", "Content-Type": "application/json"},
                json={"model": settings.openai_model,
                      "instructions": SYSTEM,
                      "input": question,
                      "max_output_tokens": 500,
                      "store": False},
            )
            response.raise_for_status()
            body = response.json()
        content = [c.get("text", "") for output in body.get("output", [])
                   if output.get("type") == "message"
                   for c in output.get("content", [])
                   if c.get("type") == "output_text" and isinstance(c.get("text"), str)]
        answer = "\n".join(content).strip()
        if not answer:
            raise ValueError("Resposta vazia do provedor")
        return ExplainOut(answer=answer[:5000], model=settings.openai_model)
    except (httpx.HTTPError, ValueError, KeyError, TypeError) as exc:
        raise HTTPException(503, "Provedor de IA temporariamente indisponível. Tente novamente mais tarde.") from exc


@router.post("/explain", response_model=ExplainOut)
def explain(payload: ExplainIn, _user: User = Depends(current_user)):
    return ask_model(payload.question)
