from datetime import datetime
from decimal import Decimal
from typing import Literal
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator


class RegisterIn(BaseModel):
    email: EmailStr
    full_name: str = Field(min_length=2, max_length=100)
    password: str = Field(min_length=10, max_length=128)

    @field_validator("full_name")
    @classmethod
    def validate_full_name(cls, value):
        if len(value.strip()) < 2:
            raise ValueError("Informe um nome com pelo menos 2 caracteres")
        return value.strip()

    @field_validator("email")
    @classmethod
    def normalize(cls, value):
        return value.lower()


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    email: EmailStr
    full_name: str
    created_at: datetime


class MeUpdate(BaseModel):
    full_name: str = Field(min_length=2, max_length=100)

    @field_validator("full_name")
    @classmethod
    def validate_name(cls, value):
        if len(value.strip()) < 2:
            raise ValueError("Nome muito curto")
        return value.strip()


class ProfileIn(BaseModel):
    experience: Literal["beginner", "intermediate", "advanced"]
    goal: Literal["learn", "reserve", "growth", "income", "retirement"]
    horizon: Literal["unsure", "short", "medium", "long"]
    liquidity: Literal["unsure", "immediate", "months", "years"]
    risk_tolerance: Literal["unsure", "low", "medium", "high"]
    interests: list[Literal["fixed", "stocks", "funds", "crypto", "global", "etfs"]] = Field(max_length=6)
    onboarding_completed: bool = True


class ProfileOut(ProfileIn):
    model_config = ConfigDict(from_attributes=True)


class PreferencesIn(BaseModel):
    theme: Literal["dark", "light"]
    level: Literal["beginner", "professional"]
    notifications_enabled: bool
    digest: Literal["off", "daily", "weekly"]


class PreferencesOut(PreferencesIn):
    model_config = ConfigDict(from_attributes=True)


class WatchIn(BaseModel):
    asset_code: Literal["bitcoin", "ethereum", "solana", "usd-coin"]


class TransactionIn(BaseModel):
    asset_code: Literal["bitcoin", "ethereum", "solana", "usd-coin", "OTHER"]
    type: Literal["BUY", "SELL"]
    quantity: Decimal = Field(gt=0, max_digits=24, decimal_places=10)
    unit_price_brl: Decimal = Field(gt=0, max_digits=24, decimal_places=8)
    fee_brl: Decimal = Field(ge=0, max_digits=18, decimal_places=2, default=Decimal("0"))
    traded_at: datetime

    @field_validator("traded_at")
    @classmethod
    def timezone_required(cls, value):
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("Informe a data com fuso horário")
        return value


class DeleteAccountIn(BaseModel):
    password: str


class ResetRequestIn(BaseModel):
    email: EmailStr


class ResetConfirmIn(BaseModel):
    token: str
    new_password: str = Field(min_length=10, max_length=128)
