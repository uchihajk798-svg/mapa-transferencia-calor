# INVEST AI Mobile — versão inicial (Expo)

Aplicativo React Native / Expo SDK 57 para **Android e iPhone**. O código mobile reutiliza a API FastAPI da pasta `../backend` e **não é apenas uma webview**. O modo sem conta funciona **offline** com lições de educação financeira e um simulador real de juros compostos (premissas hipotéticas). Cadastro, login, dados de mercado e carteira necessitam de API online.

## Funcionalidades nesta entrega

- Autenticação mobile: cadastro, login, encerramento de sessão e renovação de tokens com refresh rotativo. Refresh token guardado em `expo-secure-store` (Keystore/Keychain). A API existente por cookies para web continua funcionando.
- Onboarding com seis perguntas e preferência de risco/objetivos, gravados na conta.
- Quatro abas: **Início**, **Explorar**, **Carteira** e **Perfil**.
- Início sem valores inventados; custo histórico registrado e consultas públicas, quando disponíveis.
- Explorar: preços dos quatro criptoativos integrados no backend à CoinGecko; meta Selic via Banco Central; data/fonte e lista de acompanhamento; indisponibilidades exibidas explicitamente.
- Carteira pessoal: registrar compra/venda, posições por custo médio, validação no backend para impedir venda maior que o saldo, histórico, exclusão e distribuição do custo histórico; **não calcula patrimônio a mercado**.
- Academia: seis lições, explicação de termos, modo convidado sem conta.
- Simulador: aportes, impostos hipotéticos, inflação, cenários matemáticos, validação de parâmetros.
- Perfil: nome, preferências, tema, sessões, exportação JSON por compartilhamento nativo, exclusão de conta, recuperação de senha (só com SMTP configurado na API).
- Visual responsivo premium em verde-esmeralda, claro/escuro e navegação touch.

**Ainda não há IA conversacional real, detector de oportunidades, feed geopolítico, análise global, push, biometria nem execução de ordens.** Esses recursos são explicitamente identificados como pendentes na UI. O botão de ajuda oferece glossário, não se apresenta como modelo de IA.

## Como abrir pelo celular com Expo Go

1. Instale Node.js 22+, Python 3.12+ e as dependências do backend em um computador ou servidor.
2. Execute a API na sua rede local:

```bash
cd backend
pip install -r requirements.txt
python -m alembic upgrade head
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

> Execute `alembic upgrade head` antes do uvicorn; em dev, o backend pode usar SQLite se `DATABASE_URL` não estiver configurada. **Não faça exposição pública de SQLite + secrets padrão.** Em produção use HTTPS, PostgreSQL, Redis e segredos robustos.

3. Crie `mobile/.env` a partir de `mobile/.env.example`. Substitua `192.168.1.100` pelo **IP da máquina com a API** na mesma rede Wi-Fi. No emulador Android oficial, `http://10.0.2.2:8000` geralmente aponta para o computador. **Em dispositivo físico, `localhost` é o próprio celular — não funciona para a API do computador.**
4. Em outro terminal:

```bash
cd mobile
npm install
npx expo install --check
npm start
```

5. Instale o app **Expo Go** no Android ou iPhone e escaneie o QR Code do terminal. Ele precisa acessar o Metro do computador na rede local. Teste cadastro e carteira com o backend em execução. Para testar **Academia** e **Simulador** sem servidor, selecione **“Explorar sem criar conta”**.

A variável `EXPO_PUBLIC_API_URL` é pública, uma URL e **não pode conter senha, segredo de API ou token**. Ela é incorporada no app durante o build. Não inclua credenciais privadas em arquivos `EXPO_PUBLIC_*`.

## Como gerar um APK Android

Para uma versão de teste que possa ser instalada, é necessário um build Android (EAS Build ou Android Studio). Sem conta de desenvolvedor vinculada, SDK Android e acesso a dependências de internet, este ZIP **não contém APK pronto**.

1. Hospede o backend em URL HTTPS segura e configure o endereço via `EXPO_PUBLIC_API_URL` no ambiente do build. URLs locais só servem para desenvolvimento.
2. Entre na conta Expo e configure o projeto EAS:

```bash
cd mobile
npm install
npx eas-cli login
npx eas-cli build:configure
npx eas-cli build --platform android --profile preview
```

O `eas.json` já inclui `android.buildType = "apk"` no perfil `preview`. **Configure `EXPO_PUBLIC_API_URL` no ambiente do EAS Build** (por exemplo nas variáveis de ambiente do projeto em expo.dev), não apenas na máquina local. Sem API pública HTTPS, o APK abre apenas o modo educativo; cadastro e carteira não conseguem se conectar. Um APK não inclui FastAPI ou PostgreSQL dentro do telefone.

O Expo fornece as instruções oficiais de APK: https://docs.expo.dev/build-reference/apk/

## Testes e validação

```bash
cd backend && python -m pytest -q
cd ../mobile && npm run check && npm test
```

**Resultado neste ambiente de criação:** 16 testes do backend aprovados, 7 verificações matemáticas do simulador e 4 verificações de sintaxe de fontes TS/TSX. Os testes matemáticos e sintáticos foram executados com compilador TypeScript global. Não foi possível instalar dependências React Native ou testar `npm run check`, Expo Go, emulador, interface final ou build de APK (registro npm inacessível, sem SDK Android). Não considerar essas partes validadas até completar teste no aparelho.

## Segurança e limites

- HTTPS **obrigatório em builds de distribuição** para chamadas da API (o app recusa URL HTTP quando `__DEV__` é falso).
- Acesso curto em memória; refresh rotativo armazenado no cofre seguro do dispositivo. Em caso de falha de rede, token persistido pode continuar para futura tentativa; em caso de recusa 401, é apagado.
- O servidor revoga sessões e usa Argon2 para hash de senhas; valide rate limiting, SMTP, termos, privacidade e conformidade regulatória antes de publicar.
- O app **não tem carteira integrada a corretoras**. Transações são digitadas manualmente e usadas para custo histórico; não equivalem a ordens nem a extratos.
- O modo convidado não armazena dados de conta.
- Sem garantia de rentabilidade ou interpretação individualizada como consultoria de investimento.

## Próximas tarefas

1. Executar o Metro + Expo Go com APIs reais, corrigir problemas de layout e tipos do RN.
2. Publicar uma API de homologação HTTPS, com autenticação e banco dedicados.
3. Compilar e testar APK `preview` em Android real.
4. Implantar notificações push com consentimento e relatórios.
5. Desenvolver Analista IA com fonte e ferramentas, depois radar e pipeline Global Intelligence.
6. Testar iOS, acessibilidade, endpoints sob carga, política de privacidade e segurança regulatória.

## Alternativa sem Android Studio — GitHub Actions

Agora também há um workflow para tentativa de build em servidor GitHub sem instalar o Android Studio localmente: [COMO-GERAR-O-APK.md](COMO-GERAR-O-APK.md). Ele prepara as dependências do Expo e compila um APK de testes pelo Gradle; **não foi executado no GitHub e a compilação não é garantida até os testes**. A publicação do backend HTTPS é independente do APK.
