"""Isolated user backup. Never overwrites a newer revision silently."""
import json
import math
import re
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import CloudStore, User, utcnow
from ..security import current_user

router = APIRouter(prefix="/api/me", tags=["cloud-storage"])
CATEGORIES = {"Criptomoeda", "Ação", "FII", "ETF", "Renda fixa", "Outro"}
TICKER = re.compile(r"^[A-Z0-9][A-Z0-9._-]{0,24}$")


class BackupIn(BaseModel):
    expected_revision: int = Field(ge=0)
    data: dict


def validate_local_store(data):
    if len(json.dumps(data, ensure_ascii=False)) > 250_000:
        raise HTTPException(422, "Backup maior que 250 KB")
    if data.get("version") != 1 or not isinstance(data.get("entries"), list) or not isinstance(data.get("watch"), list):
        raise HTTPException(422, "Formato de backup inválido")
    entries, watch = data["entries"], data["watch"]
    if len(entries) > 5000 or len(watch) > 100 or len({v for v in watch if isinstance(v, str)}) != len(watch):
        raise HTTPException(422, "Limite de itens ou duplicação na lista")
    if not all(isinstance(v, str) and TICKER.fullmatch(v) for v in watch):
        raise HTTPException(422, "Lista de acompanhamento inválida")
    seen = set()
    positions = {}
    for x in sorted(entries, key=lambda v: v.get("createdAt", "") if isinstance(v, dict) else ""):
        if not isinstance(x, dict) or x.get("kind") not in ("BUY", "SELL") or x.get("category") not in CATEGORIES:
            raise HTTPException(422, "Movimentação inválida")
        if not isinstance(x.get("id"), str) or not 1 <= len(x["id"]) <= 120 or x["id"] in seen:
            raise HTTPException(422, "ID inválido ou duplicado")
        seen.add(x["id"])
        if not isinstance(x.get("ticker"), str) or not TICKER.fullmatch(x["ticker"]):
            raise HTTPException(422, "Código do ativo inválido")
        try:
            timestamp = datetime.fromisoformat(x["createdAt"].replace("Z", "+00:00"))
            if timestamp.tzinfo is None or timestamp.astimezone(timezone.utc) > utcnow():
                raise ValueError()
        except (ValueError, AttributeError, KeyError, TypeError):
            raise HTTPException(422, "Data inválida") from None
        for field in ("quantity", "unitPrice", "fee"):
            value = x.get(field)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 <= value <= 1e12:
                raise HTTPException(422, "Valor financeiro inválido")
        if x["quantity"] <= 0:
            raise HTTPException(422, "Quantidade inválida")
        key = x["category"] + ":" + x["ticker"]
        previous = positions.get(key, 0.0)
        if x["kind"] == "SELL" and x["quantity"] > previous + 1e-9:
            raise HTTPException(422, "Venda maior que saldo em backup")
        positions[key] = previous + (x["quantity"] if x["kind"] == "BUY" else -x["quantity"])
    return data


@router.get("/cloud-backup")
def get_backup(db: Session = Depends(get_db), user: User = Depends(current_user)):
    record = db.get(CloudStore, user.id)
    return {"revision": record.revision if record else 0, "data": record.data if record else None,
            "updated_at": record.updated_at if record else None}


@router.put("/cloud-backup")
def put_backup(payload: BackupIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    data = validate_local_store(payload.data)
    # Serialize concurrent updates by locking the user row in PostgreSQL.
    db.execute(select(User).where(User.id == user.id).with_for_update()).scalar_one()
    record = db.get(CloudStore, user.id)
    revision = record.revision if record else 0
    if payload.expected_revision != revision:
        raise HTTPException(409, "Backup na nuvem foi alterado. Recarregue antes de salvar.")
    if record:
        record.data, record.revision, record.updated_at = data, revision + 1, utcnow()
    else:
        db.add(CloudStore(user_id=user.id, data=data, revision=1, updated_at=utcnow()))
    db.commit()
    return {"revision": revision + 1, "ok": True}