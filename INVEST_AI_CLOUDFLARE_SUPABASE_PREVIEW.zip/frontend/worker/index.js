/**
 * Cloudflare Worker - INVEST AI
 * Serves Next.js export via ASSETS; the only dynamic route uses authenticated
 * Supabase Auth and the free-tier Gemini key kept as a Worker secret.
 * No trading orders, no price predictions or recommendations are generated.
 */
const json = (value, status = 200) => new Response(JSON.stringify(value), {
  status, headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  },
});
function problem(detail, status) { return json({detail}, status); }

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith('/api/')) return env.ASSETS.fetch(request);
    if (url.pathname === '/api/health' && request.method === 'GET') {
      return json({status:'ok', auth_configured:Boolean(env.SUPABASE_URL && env.SUPABASE_PUBLISHABLE_KEY),ai_enabled:Boolean(env.GEMINI_API_KEY)});
    }
    if (url.pathname !== '/api/ai/explain') return problem('Recurso não encontrado.', 404);
    if (request.method !== 'POST') return problem('Método não permitido.', 405);
    if (!env.GEMINI_API_KEY) return problem('IA generativa ainda não ativada. Use o modo explicativo gratuito.', 503);
    if (!env.SUPABASE_URL || !env.SUPABASE_PUBLISHABLE_KEY) return problem('Autenticação não configurada.', 503);
    const token = request.headers.get('Authorization')?.match(/^Bearer (\S+)$/)?.[1];
    if (!token || token.length > 8192) return problem('Faça login no INVEST AI para usar a IA.', 401);
    if (!(request.headers.get('Content-Type') || '').startsWith('application/json')) return problem('Envie uma pergunta JSON.', 415);
    const bodyText = await request.text();
    if (bodyText.length > 4096) return problem('Pergunta muito grande.', 413);
    let body;
    try { body = JSON.parse(bodyText); } catch { return problem('JSON inválido.', 400); }
    const question = typeof body?.question === 'string' ? body.question.trim() : '';
    if (question.length < 3 || question.length > 600) return problem('Use uma pergunta de 3 a 600 caracteres.', 400);
    const supa = env.SUPABASE_URL.replace(/\/$/, '');
    if (!/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(supa)) return problem('Configuração Supabase inválida.', 503);
    const headers = {'apikey':env.SUPABASE_PUBLISHABLE_KEY,'Authorization':`Bearer ${token}`};
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 18000);
    try {
      // Validate the user's signed JWT with Supabase Auth, not just with a decoded claim.
      const verify = await fetch(`${supa}/auth/v1/user`, {headers,signal:controller.signal});
      if (!verify.ok) return problem('Sessão expirada. Entre novamente.', 401);
      const identity = await verify.json();
      if (!identity?.id) return problem('Identidade inválida.', 401);
      const usage = await fetch(`${supa}/rest/v1/rpc/invest_ai_claim_ai_quota`, {
        method:'POST',headers:{...headers,'Content-Type':'application/json'},body:'{}',signal:controller.signal
      });
      if (!usage.ok) {
        if (usage.status === 404) return problem('Limite de IA ainda não configurado no banco.', 503);
        return problem('Limite diário atingido ou banco indisponível. Tente novamente amanhã.', 429);
      }
      const model = 'gemini-2.5-flash-lite';
      const llm = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
        method:'POST',signal:controller.signal,
        headers:{'Content-Type':'application/json','x-goog-api-key':env.GEMINI_API_KEY},
        body:JSON.stringify({
          systemInstruction:{parts:[{text:'Você é o INVEST AI, assistente de educação financeira em português brasileiro. Explique conceitos, incertezas e riscos com clareza. Não invente cotações, notícias, fontes ou certezas de lucro. Não dê ordens de compra/venda, nem aconselhamento individualizado. Avise quando não houver dados atuais. Não solicite senhas nem dados bancários.'}]},
          contents:[{role:'user',parts:[{text:question}]}],
          generationConfig:{temperature:0.35,maxOutputTokens:600}
        })
      });
      if (llm.status === 429) return problem('Cota gratuita do provedor esgotada. Use o modo explicativo.',429);
      if (!llm.ok) return problem('Serviço de IA indisponível. Não houve resposta gerada.',503);
      const result = await llm.json();
      const answer = result?.candidates?.[0]?.content?.parts?.map(p=>typeof p.text==='string'?p.text:'').join('').trim();
      if (!answer) return problem('Provedor não retornou uma resposta de texto.',502);
      return json({answer:answer.slice(0,3000),provider:'gemini',mode:'educational'});
    } catch (e) {
      return problem(e?.name === 'AbortError' ? 'Tempo esgotado. Tente novamente.' : 'Falha na integração com o provedor.',503);
    } finally { clearTimeout(timeout); }
  }
};
