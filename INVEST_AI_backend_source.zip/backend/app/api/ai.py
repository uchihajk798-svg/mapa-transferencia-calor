"""IA generativa opcional via Gemini Flash-Lite, sem API paga por padrão.

Requer chave de um projeto Google AI Studio no nível gratuito, SEM faturamento.
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
import httpx
from ..security import current_user
from ..models import User
from ..config import get_settings

router = APIRouter(prefix="/api/ai", tags=["ai"])

SYSTEM = """Você é o INVEST AI, um assistente educacional em investimentos para brasileiros.
Responda em português do Brasil, de forma simples e objetiva, com destaque para incertezas.
Não faça recomendações personalizadas de compra, venda ou timing, não prometa retornos
nem invente cotações, notícias, decisões de governo, taxas, URLs, datas ou fontes.
Se forem necessários dados recentes, explique que não foram fornecidos nem verificados.
Se o usuário perguntar por movimentações em carteira, informe que só pode comentar posições
quando dados forem explicitamente compartilhados. Não peça senhas ou chaves de corretoras.
Quando relevante, explique impactos possíveis de juros, inflação e decisões públicas,
separando fatos fornecidos, hipóteses e riscos. Evite jargão e seja didático."""

class ExplainIn(BaseModel):
    question: str = Field(min_length=3, max_length=600)

class ExplainOut(BaseModel):
    answer: str
    model: str
    source: str = "gemini-free-tier"
    live_market_data: bool = False


def ask_model(question: str) -> ExplainOut:
    settings = get_settings()
    if not settings.gemini_api_key:
        raise HTTPException(503, "IA gratuita não configurada. O assistente educativo local continua disponível.")
    try:
        with httpx.Client(timeout=22) as client:
            response = client.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/{settings.gemini_model}:generateContent",
                headers={"x-goog-api-key": settings.gemini_api_key, "Content-Type": "application/json"},
                json={"systemInstruction": {"parts": [{"text": SYSTEM}]},
                      "contents": [{"role": "user", "parts": [{"text": question}]}],
                      "generationConfig": {"maxOutputTokens": 700, "temperature": 0.3}},
            )
            response.raise_for_status()
            body = response.json()
        content = [part.get("text", "") for candidate in body.get("candidates", [])
                   for part in candidate.get("content", {}).get("parts", [])
                   if isinstance(part.get("text"), str)]
        answer = "\n".join(content).strip()
        if not answer:
            raise ValueError("Resposta vazia do provedor")
        return ExplainOut(answer=answer[:5000], model=settings.gemini_model)
    except (httpx.HTTPError, ValueError, KeyError, TypeError) as exc:
        raise HTTPException(503, "Provedor de IA temporariamente indisponível. Tente novamente mais tarde.") from exc


@router.post("/explain", response_model=ExplainOut)
def explain(payload: ExplainIn, _user: User = Depends(current_user)):
    settings = get_settings()
    if settings.gemini_api_key and settings.redis_url:
        try:
            from redis import Redis
            from datetime import datetime, timezone
            r = Redis.from_url(settings.redis_url, socket_connect_timeout=3)
            key = f"gemini-daily:{datetime.now(timezone.utc).date().isoformat()}:{_user.id}"
            n = r.incr(key)
            if n == 1:
                r.expire(key, 86400)
            if n > 12:
                raise HTTPException(429, "Limite gratuito diário de 12 perguntas por conta atingido")
        except HTTPException:
            raise
        except Exception:
            raise HTTPException(503, "Limite gratuito indisponível; IA suspensa por segurança") from None
    return ask_model(payload.question)
