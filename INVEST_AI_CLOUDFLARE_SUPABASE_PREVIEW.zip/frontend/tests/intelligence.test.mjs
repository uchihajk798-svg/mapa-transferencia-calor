import {test} from 'node:test';
import assert from 'node:assert/strict';
import {classifyHeadline,parseNewsResponse,parseMacro,explainQuestion} from '../lib/intelligence.ts';
import {DEFAULT_STORE} from '../lib/local-finance.ts';
const now=Date.parse('2026-10-08T20:00:00Z');
const example={articles:[{title:'Central bank raises interest rates to tackle inflation',url:'https://example.org/news/1',seendate:'20261008190000',sourcecountry:'United States'},{title:'Central bank raises interest rates to tackle inflation',url:'https://example.org/news/1',seendate:'20261008190000'},{title:'Old headline economic growth with enough words',url:'https://example.org/news/2',seendate:'20250101090000'}]};
test('categoriza juros com relação possível, não preço previsto',()=>{const r=classifyHeadline('Central bank increases interest rates');assert.equal(r.topic,'Juros e bancos centrais');assert.ok(!r.implications.join('').includes('lucro garantido'));});
test('descarta notícias antigas e duplicadas',()=>{const r=parseNewsResponse(example,now);assert.equal(r.length,1);assert.equal(r[0].domain,'example.org');assert.equal(r[0].score,74);});
test('bloqueia URL javascript e data e title curto',()=>{const r=parseNewsResponse({articles:[{title:'The economy falls following very large developments',url:'javascript:alert(1)',seendate:'20261008190000'},{title:'Small',url:'https://example.com',seendate:'20261008190000'}]},now);assert.equal(r.length,0)});
test('não inventa data onde não há',()=>{assert.equal(parseNewsResponse({articles:[{title:'Central bank makes an important announcement',url:'https://example.com/news'}]},now).length,0)});
test('extrai Selic SGS oficial',()=>{const r=parseMacro([{data:'08/10/2026',valor:'12.50'}],432);assert.equal(r.value,12.5);assert.equal(r.code,432)});
test('recusa macro não numérico',()=>{assert.throws(()=>parseMacro([{data:'08/10/2026',valor:'erro'}],432))});
test('assistente não inventa cotação',()=>{const r=explainQuestion('Devo comprar bitcoin?',{store:DEFAULT_STORE,positions:[],quotes:[],news:[],macro:[]});assert.match(r.text,/não há preço recente confirmado/i);assert.equal(r.kind,'rule')});
test('analisa concentração apenas quando há posição',()=>{const r=explainQuestion('analise minha carteira',{store:DEFAULT_STORE,positions:[{ticker:'BTC',category:'Criptomoeda',quantity:1,cost:900,buyValue:900,fees:0},{ticker:'PETR4',category:'Ação',quantity:2,cost:100,buyValue:100,fees:0}],quotes:[],news:[],macro:[]});assert.match(r.text,/90.0%/)});
test('não inventa notícia',()=>{const r=explainQuestion('O que ocorreu na economia mundial?',{store:DEFAULT_STORE,positions:[],quotes:[],news:[],macro:[]});assert.match(r.text,/não retornou publicações verificáveis/i)});

test('formato GDELT ISO compacto é aceito',()=>{const r=parseNewsResponse({articles:[{title:'Central bank interest rates headline today',url:'https://example.org/news/a',seendate:'20261008T190000Z'}]},now);assert.equal(r.length,1);});
