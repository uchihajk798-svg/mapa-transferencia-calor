"""Server-side backup with optimistic revision checks."""
from alembic import op
import sqlalchemy as sa

revision = "8a46153f78b1"
down_revision = "6bc3ba7110ec"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "cloud_stores",
        sa.Column("user_id", sa.String(36), sa.ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("data", sa.JSON(), nullable=False),
        sa.Column("revision", sa.Integer(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )


def downgrade():
    op.drop_table("cloud_stores")