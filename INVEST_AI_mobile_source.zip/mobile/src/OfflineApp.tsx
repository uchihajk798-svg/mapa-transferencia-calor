import React,{useEffect,useMemo,useState} from 'react';
import {ActivityIndicator,Alert,Linking,Modal,Pressable,ScrollView,Share,StyleSheet,Text,TextInput,View} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {brl,dateTime,pct,type CryptoResult,type Selic} from './types';
import {calculateScenario} from './simulator';
import {emptyLocal,inputNumber,normalizeSymbol,positionsFromTrades,validateLocal,validateTrade,type LocalData,type Trade} from './offline';
import {publicCrypto,publicSelic} from './publicMarkets';

const STORAGE_KEY='investai.local.v1';
const concepts=[
  {title:'Seu primeiro investimento',simple:'Comece entendendo seus gastos, suas dívidas e por que está poupando. Investir envolve risco. Uma reserva para imprevistos pode vir antes de procurar ativos arriscados.',pro:'Defina prazo, tolerância a perdas e necessidade de liquidez; compare rentabilidade líquida de impostos, taxas e inflação.'},
  {title:'Reserva de emergência',simple:'É um dinheiro separado para situações inesperadas. Precisa ser fácil de retirar, com baixo risco e sem carências incompatíveis.',pro:'Avalie risco de crédito, horários de resgate, liquidez efetiva e garantia aplicável ao produto.'},
  {title:'Tesouro Selic e renda fixa',simple:'São opções para estudar ao pensar em segurança e prazo. Renda fixa não significa ausência de riscos ou taxas.',pro:'Veja marcação a mercado, spread, taxa de custódia, IR regressivo e condições de resgate antecipado.'},
  {title:'Ações e dividendos',simple:'Ações são pequenas participações em empresas. Elas podem subir ou cair. Dividendos não são pagamentos garantidos.',pro:'Analise fluxo de caixa, endividamento, lucro recorrente, múltiplos, governança e risco setorial.'},
  {title:'Fundos imobiliários e ETFs',simple:'Fundos reúnem vários investimentos. Compare o que compram, as taxas, os riscos e a facilidade de vender.',pro:'Leia regulamentos, concentração, índice de referência, tracking error, liquidez e tributação.'},
  {title:'Criptomoedas e stablecoins',simple:'Criptoativos oscilam muito, e você pode perder dinheiro. Stablecoins também têm riscos de emissor e perda de paridade.',pro:'Considere risco de custódia, liquidez de exchanges, reservas, auditorias, contratos inteligentes e regulação.'},
  {title:'Impostos, taxas e resgate',simple:'O que você ganha pode diminuir por impostos, tarifas e taxas. Alguns investimentos não permitem sacar rapidamente.',pro:'Compare retorno após IR e IOF quando aplicáveis, taxas de administração, spread, carência e vencimento.'},
  {title:'Diversificação e riscos',simple:'Concentrar tudo em um investimento pode aumentar as perdas. Espalhar os riscos ajuda, mas não elimina prejuízos.',pro:'Estude correlação, drawdown, volatilidade, risco de contraparte e exposição por país, setor e moeda.'},
];
type Tab='home'|'explore'|'wallet'|'profile';
type Explore='market'|'learn'|'sim'|'world';
const CODES=[{code:'BITCOIN',name:'Bitcoin'},{code:'ETHEREUM',name:'Ethereum'},{code:'SOLANA',name:'Solana'},{code:'USD-COIN',name:'USD Coin'}];
function Btn({label,onPress,subtle=false,danger=false,disabled=false}:{label:string;onPress:()=>void;subtle?:boolean;danger?:boolean;disabled?:boolean}){
  return <Pressable accessibilityRole="button" disabled={disabled} onPress={onPress} style={({pressed})=>[styles.btn,{backgroundColor:danger?'#E85863':subtle?'#1D3245':'#10B981',opacity:disabled?0.5:pressed?0.74:1}]}><Text style={{color:subtle?'#E5EEF7':'#041B14',fontWeight:'800',fontSize:13,textAlign:'center'}}>{label}</Text></Pressable>;
}
function Box({children}:{children:React.ReactNode}){return <View style={styles.box}>{children}</View>}
function Label({children,muted=false,big=false}:{children:React.ReactNode;muted?:boolean;big?:boolean}){return <Text style={{color:muted?'#9BADBF':'#F1F7FA',fontSize:big?20:14,lineHeight:big?26:21,fontWeight:big?'800':'400'}}>{children}</Text>}
function Head({title,subtitle}:{title:string;subtitle?:string}){return <View style={{gap:3,marginBottom:7}}><Label big>{title}</Label>{subtitle?<Label muted>{subtitle}</Label>:null}</View>}
function Entry({label,value,onChange,keyboard='default'}:{label:string;value:string;onChange:(x:string)=>void;keyboard?:'default'|'decimal-pad'}){return <View style={{gap:5}}><Label>{label}</Label><TextInput accessibilityLabel={label} value={value} onChangeText={onChange} keyboardType={keyboard} autoCapitalize="none" placeholderTextColor="#92A2B0" style={styles.entry}/></View>}
function Source({label,url}:{label:string;url:string}){return <Pressable accessibilityRole="link" onPress={()=>Linking.openURL(url).catch(()=>Alert.alert('Falha','Não foi possível abrir a fonte.'))}><Text style={{color:'#37D5A0',textDecorationLine:'underline',fontSize:12}}>{label} ↗</Text></Pressable>}
export default function OfflineApp({onTheme}:{onTheme:(value:'dark'|'light')=>void}){
  const [data,setData]=useState<LocalData>(emptyLocal),[loaded,setLoaded]=useState(false),[tab,setTab]=useState<Tab>('home'),[page,setPage]=useState<Explore>('market');
  const [coin,setCoin]=useState<CryptoResult|null>(null),[selic,setSelic]=useState<Selic|null>(null),[marketStatus,setMarketStatus]=useState('Toque em atualizar para consultar fontes públicas.'),[refreshing,setRefreshing]=useState(false);
  const [tradeOpen,setTradeOpen]=useState(false),[kind,setKind]=useState<'BUY'|'SELL'>('BUY'),[symbol,setSymbol]=useState('BITCOIN'),[quantity,setQuantity]=useState(''),[price,setPrice]=useState(''),[fee,setFee]=useState('0');
  const [name,setName]=useState(''),[lesson,setLesson]=useState<number|null>(null);
  const [params,setParams]=useState({initial:'200',monthly:'100',years:'5',rate:'8',inflation:'4',tax:'15'});
  const positions=useMemo(()=>positionsFromTrades(data.trades),[data.trades]);
  const cost=positions.reduce((sum,p)=>sum+p.cost,0);
  const [recordNotice,setRecordNotice]=useState('');
  const update=(fn:(old:LocalData)=>LocalData)=>setData(old=>fn(old));
  useEffect(()=>{let active=true;AsyncStorage.getItem(STORAGE_KEY).then(s=>{if(!active)return;const next=s?validateLocal(JSON.parse(s)):emptyLocal;setData(next);setName(next.name);onTheme(next.theme);}).catch(()=>{if(active)setRecordNotice('Não foi possível ler os registros locais. Não registre dados importantes até corrigir o armazenamento.');}).finally(()=>{if(active)setLoaded(true)});return()=>{active=false};},[onTheme]);
  useEffect(()=>{if(!loaded)return;AsyncStorage.setItem(STORAGE_KEY,JSON.stringify(data)).catch(()=>setRecordNotice('Falha ao salvar no aparelho! Exporte uma cópia dos registros.'));},[data,loaded]);
  const refresh=async()=>{setRefreshing(true);const both=await Promise.allSettled([publicCrypto(),publicSelic()]);
    if(both[0].status==='fulfilled')setCoin(both[0].value);else setCoin(null);
    if(both[1].status==='fulfilled')setSelic(both[1].value);else setSelic(null);
    const errs=both.filter(v=>v.status==='rejected') as PromiseRejectedResult[];
    setMarketStatus(errs.length===2?'Fontes externas indisponíveis. Confira sua internet e tente novamente.':errs.length===1?'Uma das fontes está indisponível; não foram inventados valores.':'Fontes atualizadas. Confira os horários de cada dado.');setRefreshing(false);
  };
  useEffect(()=>{refresh();},[]);
  const saveTrade=()=>{
    const tx:Trade={id:String(Date.now())+'-'+Math.random().toString(36).slice(2,8),symbol:normalizeSymbol(symbol),kind,quantity:inputNumber(quantity),price:inputNumber(price),fee:inputNumber(fee),date:new Date().toISOString()};
    const error=validateTrade(data.trades,tx);if(error){Alert.alert('Verifique a movimentação',error);return;}
    update(old=>({...old,trades:[...old.trades,tx]}));setTradeOpen(false);setQuantity('');setPrice('');setFee('0');Alert.alert('Registrado','Movimentação salva somente neste aparelho.');
  };
  const deleteTrade=(id:string)=>Alert.alert('Excluir movimentação?','O custo médio e o saldo serão recalculados.',[{text:'Cancelar',style:'cancel'},{text:'Apagar',style:'destructive',onPress:()=>{
    const updated=data.trades.filter(t=>t.id!==id);try{positionsFromTrades(updated);update(x=>({...x,trades:updated}));}catch{Alert.alert('Não pode excluir','A exclusão deixaria vendas sem saldo. Exclua as vendas posteriores primeiro.');}
  }}]);
  const exportData=()=>Share.share({title:'INVEST AI — dados locais',message:JSON.stringify({exported_at:new Date().toISOString(),disclaimer:'Registros manuais locais; não são saldos de corretora.',data},null,2)}).catch(()=>Alert.alert('Erro ao compartilhar','Tente novamente.'));
  const changeWatch=(value:string)=>update(old=>({...old,watchlist:old.watchlist.includes(value)?old.watchlist.filter(x=>x!==value):[...old.watchlist,value]}));
  const simArgs={initial:inputNumber(params.initial),monthly:inputNumber(params.monthly),years:inputNumber(params.years),rate:inputNumber(params.rate),inflation:inputNumber(params.inflation),tax:inputNumber(params.tax)};
  const simulation=calculateScenario(simArgs),pessimistic=calculateScenario(simArgs,simArgs.rate-6),optimistic=calculateScenario(simArgs,simArgs.rate+6);
  if(!loaded)return <View style={[styles.root,styles.center]}><ActivityIndicator color="#10B981"/><Label>Carregando seus dados locais...</Label></View>;
  const quick=(label:string,next:Tab,to?:Explore)=><Btn label={label} onPress={()=>{setTab(next);if(to)setPage(to)}} subtle/>;
  return <View style={styles.root}>
    <View style={styles.header}><Text style={styles.brand}>✦ INVEST AI</Text><Text style={styles.title}>{tab==='home'?'Início':tab==='explore'?'Explorar':tab==='wallet'?'Carteira':'Perfil'}</Text><Text style={styles.badge}>MODO LOCAL</Text></View>
    <ScrollView style={{flex:1}} keyboardShouldPersistTaps="handled" contentContainerStyle={{padding:16,gap:13,paddingBottom:36}}>
      {recordNotice?<Box><Text style={{color:'#FFB6B9'}}>{recordNotice}</Text></Box>:null}
      {tab==='home'?<>
        <Label>{data.name?`Olá, ${data.name}!`:'Bem-vindo ao INVEST AI!'}</Label>
        <View style={[styles.box,{backgroundColor:'#07523E'}]}><Text style={styles.kicker}>REGISTROS MANUAIS • NÃO É SALDO ATUAL</Text><Text style={styles.money}>{brl(cost)}</Text><Text style={{color:'#CBF5E4',marginBottom:10}}>Custo histórico das posições abertas. Sem integração com corretoras ou precificação automática.</Text><Btn label="+ Registrar compra ou venda" onPress={()=>setTradeOpen(true)}/></View>
        <Box><Head title="Comece por aqui" subtitle="Recursos que já funcionam no aparelho."/>
          {quick('Explorar mercados e fontes', 'explore','market')}{quick('Aprender a investir','explore','learn')}{quick('Simular investimentos','explore','sim')}{quick('Ver minha carteira','wallet')}
        </Box>
        <Box><Head title="Resumo das fontes"/>{coin?<Label>{coin.assets.length} criptoativos consultados via CoinGecko.</Label>:<Label muted>Cripto: sem dados confirmados agora.</Label>}{selic?<Label>Meta Selic: {pct(selic.annual_rate_pct)} a.a. (referência {selic.reference_date})</Label>:<Label muted>Selic: aguardando fonte oficial.</Label>}<Btn label={refreshing?'Atualizando...':'Atualizar mercado'} onPress={refresh} disabled={refreshing} subtle/></Box>
        <Box><Head title="O que mudou no mundo?"/><Label muted>Radar de notícias e análises de IA ainda não estão conectados. Não mostramos notícias inventadas.</Label>{quick('Ver dados macroeconômicos','explore','world')}</Box>
      </>:null}
      {tab==='explore'?<>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{gap:8,paddingBottom:6}}>{([{id:'market',name:'Mercados'},{id:'learn',name:'Academia'},{id:'sim',name:'Simular'},{id:'world',name:'Global'}] as const).map(t=><Pressable key={t.id} onPress={()=>setPage(t.id)} style={[styles.chip,{backgroundColor:page===t.id?'#0A7252':'#1D3245'}]}><Text style={styles.chipText}>{t.name}</Text></Pressable>)}</ScrollView>
        {page==='market'?<>
          <Box><Head title="Cotações reais • Criptomoedas" subtitle="Consulta direta à CoinGecko, sujeita a limites gratuitos."/><Label muted>{marketStatus}</Label>
            {coin?.assets.map(x=><View key={x.code} style={styles.item}><View style={{flex:1,gap:3}}><Label big>{x.name}</Label><Label>{brl(x.price_brl)}</Label><Label muted>24 h: {typeof x.change_24h_pct==='number'?pct(x.change_24h_pct):'Sem dado'}</Label><Label muted>Atualizado: {dateTime(x.updated_at)}</Label></View><Btn label={data.watchlist.includes(x.code.toUpperCase())?'✓ Seguindo':'+ Acompanhar'} subtle onPress={()=>changeWatch(x.code.toUpperCase())}/></View>)}
            {!coin?<Label muted>Sem cotação verificável. Não usamos valores de demonstração.</Label>:null}<Source label="Fonte: CoinGecko" url="https://www.coingecko.com/"/><Btn label={refreshing?'Consultando...':'Atualizar fontes'} onPress={refresh} disabled={refreshing}/></Box>
          <Box><Head title="Minha lista de acompanhamento" subtitle="Salva no celular, sem alertas automáticos."/>{data.watchlist.length===0?<Label muted>Nenhum ativo acompanhado.</Label>:data.watchlist.map(x=><View key={x} style={styles.item}><Label>{x}</Label><Btn label="Remover" subtle onPress={()=>changeWatch(x)}/></View>)}</Box>
        </>:null}
        {page==='learn'?<>
          <Head title="Academia INVEST AI" subtitle="Aprenda os conceitos sem depender de conta."/>{concepts.map((x,i)=><Pressable key={x.title} accessibilityRole="button" onPress={()=>setLesson(lesson===i?null:i)}><Box><Head title={`${i+1}. ${x.title}`}/>{lesson===i?<><Label>{data.level==='professional'?x.pro:x.simple}</Label><Btn label="Não entendi — explicar de forma simples" onPress={()=>Alert.alert(x.title,x.simple)} subtle/></>:<Label muted>Toque para aprender ›</Label>}</Box></Pressable>)}
        </>:null}
        {page==='sim'?<Box><Head title="Simulador de investimento" subtitle="Cálculo hipotético, não é previsão nem indicação de compra."/>
          {([{key:'initial',label:'Valor inicial (R$)'},{key:'monthly',label:'Aporte mensal (R$)'},{key:'years',label:'Prazo (anos)'},{key:'rate',label:'Rentabilidade anual hipotética (%)'},{key:'inflation',label:'Inflação anual hipotética (%)'},{key:'tax',label:'Imposto hipotético sobre ganhos (%)'}] as const).map(x=><Entry key={x.key} label={x.label} value={params[x.key]} onChange={v=>setParams(old=>({...old,[x.key]:v}))} keyboard="decimal-pad"/>)}
          {simulation?<><Head title={`Cenário central: ${brl(simulation.net)}`}/><Label>Valor aportado: {brl(simulation.invested)}</Label><Label>Poder de compra estimado: {brl(simulation.real)}</Label><Label muted>Cenário pessimista (-6 p.p.): {pessimistic?brl(pessimistic.net):'Indisponível'}</Label><Label muted>Cenário otimista (+6 p.p.): {optimistic?brl(optimistic.net):'Indisponível'}</Label></>:<Label>Digite valores válidos e taxas entre -100% e 100%.</Label>}
          <Label muted>Premissas: aportes ao fim de cada mês; taxa anual convertida em mensal equivalente; inflação constante; imposto simplificado somente sobre ganhos. Não inclui IOF e regras específicas de cada produto.</Label>
        </Box>:null}
        {page==='world'?<Box><Head title="Inteligência econômica global" subtitle="Versão atual: somente indicadores oficiais disponíveis."/>{selic?<><Text style={styles.money}>{pct(selic.annual_rate_pct)}</Text><Label>Meta Selic — referência {selic.reference_date}</Label><Source label="Abrir a fonte no Banco Central" url={selic.source_url}/></>:<Label muted>Taxa oficial indisponível: não será estimada.</Label>}
          <Label muted>O radar de notícias, decisões governamentais, pontuação de impacto e notificações push ainda exigem backend, provedores e IA configurados.</Label><Source label="Banco Central do Brasil" url="https://www.bcb.gov.br/"/><Source label="IBGE" url="https://www.ibge.gov.br/"/><Btn label="Consultar novamente" onPress={refresh} disabled={refreshing}/></Box>:null}
      </>:null}
      {tab==='wallet'?<>
        <Box><Head title="Minha carteira manual" subtitle="Registros no aparelho, sem conexão com corretora."/><Text style={styles.money}>{brl(cost)}</Text><Label muted>Custo histórico das posições abertas, não patrimônio atual.</Label><Btn label="+ Nova movimentação" onPress={()=>setTradeOpen(true)}/><Btn label="Exportar meus registros (JSON)" onPress={exportData} subtle/></Box>
        <Head title="Posições"/>{positions.length?positions.map(p=><Box key={p.symbol}><Head title={p.symbol}/><Label>Quantidade: {p.quantity.toLocaleString('pt-BR',{maximumFractionDigits:10})}</Label><Label>Preço médio de compra: {brl(p.average)}</Label><Label>Custo remanescente: {brl(p.cost)}</Label><Label muted>Resultado realizado em vendas: {brl(p.realized)} (antes dos tributos).</Label></Box>):<Box><Label muted>Você ainda não registrou nenhuma compra.</Label></Box>}
        <Head title="Histórico de transações"/>{[...data.trades].reverse().map(t=><Box key={t.id}><View style={styles.item}><View style={{flex:1}}><Label big>{t.kind==='BUY'?'Compra':'Venda'} · {t.symbol}</Label><Label muted>{dateTime(t.date)}</Label><Label>{t.quantity} × {brl(t.price)}</Label><Label muted>Taxas informadas: {brl(t.fee)}</Label></View><Btn label="Excluir" onPress={()=>deleteTrade(t.id)} subtle/></View></Box>)}
      </>:null}
      {tab==='profile'?<>
        <Box><Head title="Meu perfil local" subtitle="Não é uma conta na internet nem sincroniza entre dispositivos."/><Entry label="Como quer ser chamado?" value={name} onChange={setName}/><Btn label="Salvar nome neste celular" onPress={()=>{update(x=>({...x,name:name.trim().slice(0,65)}));Alert.alert('Pronto','Nome salvo no aparelho.');}}/></Box>
        <Box><Head title="Modo de explicação"/><View style={styles.item}><Btn label="Iniciante" subtle={data.level!=='beginner'} onPress={()=>update(x=>({...x,level:'beginner'}))}/><Btn label="Profissional" subtle={data.level!=='professional'} onPress={()=>update(x=>({...x,level:'professional'}))}/></View><Label muted>As explicações das aulas mudam conforme a opção.</Label></Box>
        <Box><Head title="Segurança e privacidade"/><Label muted>Os registros são armazenados localmente sem criptografia própria do aplicativo. Não insira senhas bancárias, CPF ou dados secretos. Exportações via compartilhamento contêm valores em texto simples.</Label><Btn label="Exportar registros locais" onPress={exportData} subtle/><Btn label="Apagar todos os dados deste aparelho" danger onPress={()=>Alert.alert('Apagar dados locais?','Esta ação apaga nome, carteira e ativos acompanhados. Exporte antes, se desejar.',[{text:'Cancelar',style:'cancel'},{text:'Apagar',style:'destructive',onPress:()=>{update(()=>({...emptyLocal}));setName('');setTab('home');}}])}/></Box>
        <Box><Head title="Conta online e IA"/><Label muted>Cadastro, senha, carteira sincronizada, radar de IA, notícias e push dependem de um servidor HTTPS que ainda não foi publicado. Esta versão não finge criar uma conta real.</Label><Btn label="Por que não consigo criar conta?" subtle onPress={()=>Alert.alert('Servidor pendente','Precisamos publicar a API FastAPI com PostgreSQL e configurar o endereço HTTPS no APK. Até lá, use a carteira local sem criar conta.')}/></Box>
      </>:null}
    </ScrollView>
    <View style={styles.navigation}>{([{id:'home',symbol:'⌂',label:'Início'},{id:'explore',symbol:'◎',label:'Explorar'},{id:'wallet',symbol:'▤',label:'Carteira'},{id:'profile',symbol:'☰',label:'Perfil'}] as const).map(x=><Pressable key={x.id} accessibilityRole="tab" accessibilityState={{selected:tab===x.id}} onPress={()=>setTab(x.id)} style={styles.navItem}><Text style={{color:tab===x.id?'#10B981':'#95A8BC',fontSize:24}}>{x.symbol}</Text><Text style={{color:tab===x.id?'#10B981':'#95A8BC',fontSize:11,fontWeight:'700'}}>{x.label}</Text></Pressable>)}</View>
    <Modal visible={tradeOpen} animationType="slide" onRequestClose={()=>setTradeOpen(false)}><View style={styles.modal}><ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{padding:19,paddingTop:48,gap:14,paddingBottom:60}}>
      <Head title="Registrar investimento" subtitle="Compra e venda são registros manuais, não operações reais."/><Btn label="Fechar" subtle onPress={()=>setTradeOpen(false)}/><View style={styles.item}><Btn label="Compra" subtle={kind!=='BUY'} onPress={()=>setKind('BUY')}/><Btn label="Venda" subtle={kind!=='SELL'} onPress={()=>setKind('SELL')}/></View>
      <Entry label="Ativo (ex.: PETR4, BITCOIN, Tesouro Selic)" value={symbol} onChange={setSymbol}/><View style={{flexDirection:'row',flexWrap:'wrap',gap:8}}>{CODES.map(x=><Btn key={x.code} label={x.name} subtle onPress={()=>setSymbol(x.code)}/>)}</View>
      <Entry label="Quantidade" value={quantity} onChange={setQuantity} keyboard="decimal-pad"/><Entry label="Preço unitário pago (R$)" value={price} onChange={setPrice} keyboard="decimal-pad"/><Entry label="Taxas totais (R$)" value={fee} onChange={setFee} keyboard="decimal-pad"/><Label muted>Para registrar uma venda é preciso ter quantidade suficiente de compras anteriores. Os valores informados são seus, não cotações automaticamente detectadas.</Label><Btn label="Salvar movimentação no aparelho" onPress={saveTrade}/>
    </ScrollView></View></Modal>
  </View>;
}
const styles=StyleSheet.create({root:{flex:1,backgroundColor:'#081320'},center:{justifyContent:'center',alignItems:'center',gap:12},header:{paddingHorizontal:18,paddingTop:13,paddingBottom:12,borderBottomWidth:1,borderColor:'#273E53',gap:3},brand:{color:'#10B981',fontSize:11,fontWeight:'800',letterSpacing:1.2},title:{color:'#F1F7FA',fontSize:25,fontWeight:'800'},badge:{color:'#A9F6D6',fontSize:10,fontWeight:'800',alignSelf:'flex-start'},box:{backgroundColor:'#112338',borderWidth:1,borderColor:'#263E52',borderRadius:17,padding:15,gap:11},btn:{paddingVertical:12,paddingHorizontal:15,minHeight:44,alignItems:'center',justifyContent:'center',borderRadius:12},kicker:{color:'#CFF9E4',fontSize:10,fontWeight:'800',letterSpacing:0.8},money:{color:'#BDFDE1',fontSize:28,fontWeight:'900',marginVertical:5},chip:{paddingHorizontal:15,paddingVertical:10,borderRadius:30},chipText:{color:'#F1F7FA',fontWeight:'800',fontSize:12},item:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',gap:10,paddingVertical:7},entry:{color:'#FAFEFF',backgroundColor:'#1D3245',borderWidth:1,borderColor:'#355168',borderRadius:12,minHeight:49,paddingHorizontal:13,fontSize:15},navigation:{flexDirection:'row',backgroundColor:'#112338',borderTopWidth:1,borderColor:'#284054',paddingBottom:8,paddingTop:7},navItem:{flex:1,alignItems:'center',gap:2},modal:{flex:1,backgroundColor:'#081320'}});
