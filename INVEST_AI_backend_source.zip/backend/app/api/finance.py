from datetime import datetime, timezone
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import User, WatchItem, Transaction
from ..schemas import WatchIn, TransactionIn
from ..security import current_user
from ..services.portfolio import positions_from_transactions

router = APIRouter(prefix="/api", tags=["finance"])


@router.get("/watchlist")
def get_watchlist(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [{"id": x.id, "asset_code": x.asset_code, "created_at": x.created_at} for x in db.scalars(select(WatchItem).where(WatchItem.user_id == user.id).order_by(WatchItem.created_at.desc())).all()]


@router.post("/watchlist", status_code=201)
def add_watchlist(payload: WatchIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    existing = db.scalar(select(WatchItem).where(WatchItem.user_id == user.id, WatchItem.asset_code == payload.asset_code))
    if existing:
        raise HTTPException(409, "Ativo já acompanhado")
    item = WatchItem(user_id=user.id, asset_code=payload.asset_code)
    db.add(item)
    db.commit()
    return {"id": item.id, "asset_code": item.asset_code}


@router.delete("/watchlist/{id}")
def delete_watchlist(id: str, db: Session = Depends(get_db), user: User = Depends(current_user)):
    item = db.scalar(select(WatchItem).where(WatchItem.id == id, WatchItem.user_id == user.id))
    if not item:
        raise HTTPException(404, "Ativo não encontrado")
    db.delete(item)
    db.commit()
    return {"ok": True}


def get_transactions(db: Session, user_id: str):
    return db.scalars(select(Transaction).where(Transaction.user_id == user_id).order_by(Transaction.traded_at, Transaction.created_at, Transaction.id)).all()


@router.get("/portfolio")
def portfolio(db: Session = Depends(get_db), user: User = Depends(current_user)):
    transactions = get_transactions(db, user.id)
    return {"positions": positions_from_transactions(transactions), "transactions": [{"id": t.id, "asset_code": t.asset_code, "type": t.type, "quantity": str(t.quantity), "unit_price_brl": str(t.unit_price_brl), "fee_brl": str(t.fee_brl), "traded_at": t.traded_at} for t in reversed(transactions)], "valuation": None, "note": "Sem marcação a mercado automática: os valores exibidos são custos históricos, não patrimônio atualizado."}


@router.post("/portfolio/transactions", status_code=201)
def add_transaction(payload: TransactionIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    if payload.traded_at > datetime.now(timezone.utc):
        raise HTTPException(422, "A data da movimentação não pode estar no futuro")
    db.execute(select(User).where(User.id == user.id).with_for_update()).scalar_one()
    transactions = get_transactions(db, user.id)
    entry = Transaction(user_id=user.id, **payload.model_dump())
    db.add(entry)
    db.flush()
    # Reprocessar todo o histórico evita venda sem saldo e lançamentos retroativos inconsistentes.
    positions_from_transactions(transactions + [entry])
    db.commit()
    return {"ok": True, "id": entry.id}


@router.delete("/portfolio/transactions/{id}")
def delete_transaction(id: str, db: Session = Depends(get_db), user: User = Depends(current_user)):
    db.execute(select(User).where(User.id == user.id).with_for_update()).scalar_one()
    record = db.scalar(select(Transaction).where(Transaction.id == id, Transaction.user_id == user.id))
    if not record:
        raise HTTPException(404, "Lançamento não encontrado")
    transactions = [t for t in get_transactions(db, user.id) if t.id != id]
    positions_from_transactions(transactions)
    db.delete(record)
    db.commit()
    return {"ok": True}
