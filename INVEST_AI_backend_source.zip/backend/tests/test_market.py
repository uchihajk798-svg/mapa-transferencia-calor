from datetime import datetime, timezone
import httpx
import pytest
from app.api import market


class FakeResponse:
    def __init__(self, value): self.value=value
    def raise_for_status(self): pass
    def json(self): return self.value


def test_market_contract_without_publishing_fake_data(client, monkeypatch):
    """Provedor é simulado SOMENTE no teste; resposta pública nunca é hardcoded."""
    class FakeClient:
        def __init__(self, *args, **kwargs): pass
        def __enter__(self): return self
        def __exit__(self,*args): return None
        def get(self,url,params=None):
            if 'coingecko' in url:
                return FakeResponse({'bitcoin':{'brl':777777.77,'brl_24h_change':-2.5,'last_updated_at':1777777777}})
            return FakeResponse([{'data':'01/01/2026','valor':'12.25'}])
    market._cache.clear()
    monkeypatch.setattr(market.httpx,'Client',FakeClient)
    crypto=client.get('/api/market/crypto')
    assert crypto.status_code==200
    assert crypto.json()['assets'][0]['source']=='CoinGecko'
    assert crypto.json()['assets'][0]['price_brl']==777777.77
    assert len(crypto.json()['assets'])==1
    selic=client.get('/api/market/selic')
    assert selic.status_code==200
    assert selic.json()['annual_rate_pct']==12.25
    assert selic.json()['source_url'].startswith('https://')
    market._cache.clear()


def test_provider_offline_fails_clearly(client, monkeypatch):
    class Offline:
        def __init__(self,*a,**k): pass
        def __enter__(self): return self
        def __exit__(self,*a): return None
        def get(self,*a,**k): raise httpx.ConnectError('connection failed')
    market._cache.clear()
    monkeypatch.setattr(market.httpx,'Client',Offline)
    assert client.get('/api/market/crypto').status_code==503
    assert client.get('/api/market/selic').status_code==503
    market._cache.clear()
