from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_env: str = "development"
    database_url: str = "sqlite:///./investai.db"
    redis_url: str | None = None
    jwt_secret: str = "dev-only-not-for-production-change-this-secret-please"
    cookie_secure: bool = False
    cors_origins: str = "http://localhost:3000"
    openai_api_key: str | None = None
    openai_model: str = "gpt-4.1-mini"
    gemini_api_key: str | None = None
    gemini_model: str = "gemini-2.5-flash-lite"
    smtp_host: str | None = None
    smtp_port: int = 587
    smtp_username: str | None = None
    smtp_password: str | None = None
    smtp_from: str | None = None
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def origins(self) -> list[str]:
        return [x.strip().rstrip("/") for x in self.cors_origins.split(",") if x.strip()]


@lru_cache
def get_settings() -> Settings:
    settings = Settings()
    if settings.app_env == "production":
        if not (settings.database_url.startswith("postgresql://") or settings.database_url.startswith("postgres://") or settings.database_url.startswith("postgresql+psycopg://")):
            raise RuntimeError("DATABASE_URL do PostgreSQL é obrigatório em produção: SQLite não persiste no Render Free")
        if len(settings.jwt_secret) < 48 or "CHANGE_ME" in settings.jwt_secret or "dev-only" in settings.jwt_secret:
            raise RuntimeError("JWT_SECRET seguro é obrigatório em produção")
        if not settings.cookie_secure:
            raise RuntimeError("COOKIE_SECURE=true é obrigatório em produção")
        if not settings.redis_url:
            raise RuntimeError("REDIS_URL é obrigatório em produção para rate limiting")
    return settings
