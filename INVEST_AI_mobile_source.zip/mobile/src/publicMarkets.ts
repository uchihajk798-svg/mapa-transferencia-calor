import type {CryptoResult,Quote,Selic} from './types';

const COINGECKO='https://api.coingecko.com/api/v3/coins/markets?vs_currency=brl&ids=bitcoin%2Cethereum%2Csolana%2Cusd-coin&price_change_percentage=24h';
const BCB='https://api.bcb.gov.br/dados/serie/bcdata.sgs.432/dados/ultimos/1?formato=json';
const LABELS:Record<string,string>={bitcoin:'Bitcoin',ethereum:'Ethereum',solana:'Solana','usd-coin':'USD Coin'};
export async function publicCrypto():Promise<CryptoResult>{
  const response=await fetch(COINGECKO,{headers:{Accept:'application/json'}});
  if(!response.ok)throw new Error(`CoinGecko indisponível (HTTP ${response.status}).`);
  const raw:unknown=await response.json();
  if(!Array.isArray(raw))throw new Error('Resposta da CoinGecko inválida.');
  const assets:Quote[]=raw.flatMap((x:unknown)=>{
    if(!x||typeof x!=='object')return [];
    const v=x as Record<string,unknown>;
    if(typeof v.id!=='string'||!(v.id in LABELS)||typeof v.current_price!=='number'||!Number.isFinite(v.current_price)||v.current_price<=0)return [];
    const date=typeof v.last_updated==='string'&&Number.isFinite(Date.parse(v.last_updated))?v.last_updated:null;
    if(!date)return []; // Não mostrar valores sem data verificável.
    return [{code:v.id,name:LABELS[v.id],price_brl:v.current_price,change_24h_pct:typeof v.price_change_percentage_24h==='number'&&Number.isFinite(v.price_change_percentage_24h)?v.price_change_percentage_24h:null,updated_at:date,source:'CoinGecko',source_url:'https://www.coingecko.com',delayed:true}];
  });
  if(assets.length===0)throw new Error('Sem cotações verificáveis neste momento.');
  return {assets,note:'Cotações informativas da CoinGecko, sujeitas a atraso, indisponibilidade e limites de acesso.'};
}
export async function publicSelic():Promise<Selic>{
  const response=await fetch(BCB,{headers:{Accept:'application/json'}});
  if(!response.ok)throw new Error(`Banco Central indisponível (HTTP ${response.status}).`);
  const raw:unknown=await response.json();
  const first=Array.isArray(raw)?raw[0]:null;
  if(!first||typeof first!=='object')throw new Error('Resposta oficial da Selic inválida.');
  const item=first as Record<string,unknown>;
  const value=typeof item.valor==='string'?Number(item.valor.replace(',','.')):NaN;
  if(!Number.isFinite(value)||value<0||typeof item.data!=='string'||!/^\d{2}\/\d{2}\/\d{4}$/.test(item.data))throw new Error('Dados oficiais da Selic incompletos.');
  return {annual_rate_pct:value,reference_date:item.data,source:'Banco Central do Brasil – Série 432',source_url:BCB,note:'Meta Selic definida pelo Copom. Não é uma rentabilidade garantida.'};
}
