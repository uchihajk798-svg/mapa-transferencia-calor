/** INVEST AI Global Intelligence: interpretação transparente, não previsão de preços. */
import type { Position, MarketQuote, LocalStore } from './local-finance';

export type NewsItem = { title:string; url:string; domain:string; publishedAt:string; country:string; language:string; topic:string; score:number; implications:string[]; confidence:'contextual'|'low' };
export type MacroValue = { code:432|433; name:string; value:number; date:string; source:string; unit:string };
export type AdvisorAnswer = { text:string; sources:{label:string;url:string}[]; kind:'rule' };
const NEWS_API = 'https://api.gdeltproject.org/api/v2/doc/doc';
const NEWS_QUERY = '("central bank" OR "interest rates" OR "inflation" OR "oil prices" OR "tariffs" OR "sanctions" OR "cryptocurrency" OR "economic growth")';
const SAFE_URL=/^https:\/\//i;
const CATEGORIES=[
 {topic:'Juros e bancos centrais',re:/interest rate|central bank|federal reserve|copom|selic|taxa de juros|juros|fed\b|ecb\b/i,implications:['Mudanças de juros podem alterar preços de títulos e o custo do crédito.', 'O efeito sobre ações e câmbio depende das expectativas que já estavam nos preços.']},
 {topic:'Inflação',re:/inflation|infla[cç][aã]o|consumer price|ipca/i,implications:['A inflação reduz poder de compra e pode pressionar decisões sobre juros.', 'Renda fixa com retorno nominal precisa ser comparada à inflação e aos impostos.']},
 {topic:'Energia e commodities',re:/\boil\b|petrol|brent|opec|energy|petr[oó]leo/i,implications:['Mudanças no petróleo afetam custos de transporte e empresas de energia.', 'O impacto para PETR4, inflação e câmbio varia com a causa e a duração do choque.']},
 {topic:'Comércio e governos',re:/tariff|sanction|trade war|tarifa|san[cç][aã]o|government|governo/i,implications:['Tarifas e sanções podem mudar cadeias de suprimento e margens das empresas.', 'A exposição a países e moedas diferentes pode ampliar ou reduzir o risco.']},
 {topic:'Criptoativos',re:/bitcoin|cryptocurrency|crypto|ethereum|criptomoeda/i,implications:['Notícias de regulação e liquidez podem coincidir com volatilidade elevada.', 'Uma notícia isolada não determina o preço futuro de criptomoedas.']},
];

export function classifyHeadline(title:string){
 const hits=CATEGORIES.filter(t=>t.re.test(title));
 const topic=hits.length?hits[0].topic:'Economia global';
 const implications=hits.length?[...new Set(hits.flatMap(t=>t.implications))].slice(0,3):['O impacto depende de dados econômicos e da reação dos mercados.', 'É necessário verificar a publicação original antes de concluir causa e efeito.'];
 return {topic,implications,score:Math.min(100,30+hits.length*18+(title.length>42?8:0)),confidence:hits.length?'contextual' as const:'low' as const};
}

function safeDate(value:unknown):string|null {
 if(typeof value!=='string')return null;
 const compact=value.match(/^(\d{4})(\d{2})(\d{2})T?(\d{2})(\d{2})(\d{2})Z?$/);
 const d=compact?new Date(`${compact[1]}-${compact[2]}-${compact[3]}T${compact[4]}:${compact[5]}:${compact[6]}Z`):new Date(value);
 return Number.isFinite(d.getTime())?d.toISOString():null;
}
export function parseNewsResponse(raw:unknown,now=Date.now()):NewsItem[]{
 if(!raw||typeof raw!=='object'||!Array.isArray((raw as {articles?:unknown}).articles))return [];
 const articles=(raw as {articles:unknown[]}).articles;
 const visited=new Set<string>();const rows:NewsItem[]=[];
 for(const item of articles){
  if(!item||typeof item!=='object')continue;
  const a=item as Record<string,unknown>;
  if(typeof a.title!=='string'||a.title.trim().length<15||typeof a.url!=='string'||!SAFE_URL.test(a.url))continue;
  let url:URL;try{url=new URL(a.url);if(url.username||url.password||url.hostname==='localhost'||url.hostname.endsWith('.local'))continue;}catch{continue}
  const stamp=safeDate(a.seendate)||safeDate(a.publishedAt);
  if(!stamp||Date.parse(stamp)>now+3*60*60*1000||now-Date.parse(stamp)>72*60*60*1000)continue;
  const title=a.title.trim().slice(0,280);const canonical=url.hostname+url.pathname;
  if(visited.has(canonical))continue;visited.add(canonical);
  const category=classifyHeadline(title);
  rows.push({title,url:url.href,domain:url.hostname.replace(/^www\./,''),publishedAt:stamp,country:typeof a.sourcecountry==='string'?a.sourcecountry.slice(0,50):'',language:typeof a.language==='string'?a.language.slice(0,30):'',...category});
 }
 return rows.sort((a,b)=>b.score-a.score||b.publishedAt.localeCompare(a.publishedAt)).slice(0,25);
}
export async function fetchGlobalNews(signal?:AbortSignal):Promise<NewsItem[]> {
 const query=new URLSearchParams({query:NEWS_QUERY,mode:'artlist',format:'json',timespan:'48h',maxrecords:'35',sort:'datedesc'});
 const response=await fetch(`${NEWS_API}?${query.toString()}`,{signal,headers:{Accept:'application/json'}});
 if(!response.ok)throw new Error(`Notícias temporariamente indisponíveis (HTTP ${response.status}).`);
 const raw=await response.json();return parseNewsResponse(raw);
}

export function parseMacro(raw:unknown,code:432|433):MacroValue {
 if(!Array.isArray(raw)||!raw.length)throw new Error('Série econômica vazia.');
 const record=raw[raw.length-1];if(!record||typeof record!=='object')throw new Error('Série inválida.');
 const n=Number(String(record.valor).replace(',','.'));
 const d=String(record.data||'');
 if(!Number.isFinite(n)||Math.abs(n)>100||!/^(\d{2})\/(\d{2})\/(\d{4})$/.test(d))throw new Error('Indicador inválido.');
 return {code,name:code===432?'Meta Selic':'IPCA mensal',value:n,date:d,unit:code===432?'% ao ano':'% no mês',source:`https://dadosabertos.bcb.gov.br/dataset/${code===432?'432-taxa-de-juros---meta-selic-definida-pelo-copom':'433-indice-nacional-de-precos-ao-consumidor-amplo-ipca'}`};
}
export async function fetchMacroValues(signal?:AbortSignal):Promise<MacroValue[]> {
 const res=await Promise.allSettled(([432,433] as const).map(async code=>{
  const url=`https://api.bcb.gov.br/dados/serie/bcdata.sgs.${code}/dados/ultimos/1?formato=json`;
  const r=await fetch(url,{signal,headers:{Accept:'application/json'}});
  if(!r.ok)throw new Error(`Banco Central indisponível (${r.status}).`);
  return parseMacro(await r.json(),code);
 }));
 return res.flatMap(r=>r.status==='fulfilled'?[r.value]:[]);
}
const brl=(n:number)=>new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(n);
export function explainQuestion(question:string,opts:{store:LocalStore;positions:Position[];quotes:MarketQuote[];news:NewsItem[];macro:MacroValue[]}):AdvisorAnswer {
 const q=question.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
 const {positions,store,quotes,news,macro}=opts;
 const total=positions.reduce((a,p)=>a+p.cost,0);
 const max=positions.length?positions.reduce((a,p)=>a.cost>p.cost?a:p):null;
 const concentration=max&&total>0?100*max.cost/total:0;
 const summary=max?`Você registrou ${positions.length} posição(ões), com custo remanescente de ${brl(total)}. A maior posição é ${max.ticker}, com ${concentration.toFixed(1)}% desse custo.`:'Sua carteira local ainda não tem posições registradas. Não vou assumir investimentos que você não informou.';
 const sources:{label:string;url:string}[]=[];
 let body='';
 if(/(carteira|portfolio|diversific|concentra|risco|analis|avalie|minhas posic)/.test(q)){
  body=`**Raio-X da sua carteira**\n${summary}\n`;
  if(max&&concentration>=40)body+=`**Ponto de atenção:** ${max.ticker} representa ${concentration.toFixed(1)}% do custo registrado. Um choque nesse ativo pode ter grande impacto. Considere comparar classes, liquidez e horizonte antes de novas compras.\n`;
  else if(max)body+='Sua maior posição não ultrapassa 40% do custo registrado, mas essa medida sozinha não confirma diversificação real: ativos podem cair juntos.\n';
  if(store.risk==='baixo')body+='Você informou menor tolerância a perdas. Oscilações de cripto e concentração merecem atenção especial.\n';
  body+='**Limite da análise:** valores por custo, sem considerar impostos, correlações nem cotações atualizadas de todas as classes.';
 }else if(/(selic|juros|renda fixa|tesouro|cdb|ipca|inflac)/.test(q)){
  const selic=macro.find(x=>x.code===432),ipca=macro.find(x=>x.code===433);
  body=`**Juros e poder de compra**\n${selic?`Meta Selic divulgada: ${selic.value.toFixed(2)}% a.a. (referência ${selic.date}). `:'A Meta Selic ao vivo não está disponível neste momento. '}${ipca?`IPCA mensal informado: ${ipca.value.toFixed(2)}% (referência ${ipca.date}).`:'O IPCA não foi confirmado agora.'}\nA taxa básica orienta a renda fixa, mas o rendimento líquido depende do produto, impostos, taxas e prazo. Uma rentabilidade nominal positiva pode não superar a inflação.`;
  if(selic||ipca)sources.push({label:'Banco Central do Brasil (SGS)',url:'https://dadosabertos.bcb.gov.br/'});
 }else if(/(mundo|mundial|noticia|guerra|governo|tarifa|geopolit|petroleo|economia global|internacional)/.test(q)){
  body='**Inteligência global: relação entre eventos e investimentos**\n';
  if(news.length){const n=news[0];body+=`Notícia encontrada: “${n.title}” (fonte: ${n.domain}; observada em ${new Date(n.publishedAt).toLocaleString('pt-BR')}).\nTema: ${n.topic}.\nPossíveis canais de impacto: ${n.implications.join(' ')}\nIsso é uma interpretação por regras de palavras-chave, não confirmação da notícia nem prova de causalidade.`;sources.push({label:n.domain,url:n.url});}
  else body+='O agregador de notícias não retornou publicações verificáveis nesta sessão. Não vou inventar acontecimentos. Abra o Radar Global para atualizar e checar diretamente as fontes.';
 }else if(/(bitcoin|ethereum|cripto|btc|eth|solana|comprar|vender|momento|hora|lucro|retirar|sair)/.test(q)){
  const matched=quotes.find(x=>q.includes(x.ticker.toLowerCase())||q.includes(x.name.toLowerCase()))||quotes.find(x=>x.ticker==='BTC');
  body=`**Antes de decidir uma entrada ou saída**\n${matched?`${matched.name}: ${brl(matched.price)}; variação em 24h ${matched.change===null?'não disponível':matched.change.toFixed(2)+'%'} (CoinGecko, ${new Date(matched.updatedAt).toLocaleString('pt-BR')}).`:'Não há preço recente confirmado nesta sessão.'}\nUse três perguntas: quanto você aceita perder, quanto tempo pode esperar e qual evento invalidaria sua hipótese? Uma alta de 24h não é sinal automático de compra; uma queda não é garantia de recuperação. Não existe momento de saída certo dedutível só de preço e notícia.`;
  if(matched)sources.push({label:'CoinGecko',url:'https://www.coingecko.com/'});
 }else if(/(reserva|emergencia|iniciante|comec|primeiro|aprend)/.test(q)){
  body='**Primeiros passos**\nOrganize despesas e dívidas caras. Avalie uma reserva de emergência com liquidez e baixo risco apropriado. Só então compare renda fixa, fundos, ações e cripto em função do prazo e da tolerância a perdas. Comece com pequenos valores que você pode manter investidos. Não há necessidade de acertar o topo ou o fundo do mercado.';
 }else{
  body=`Posso explicar carteira, risco, inflação, Selic, criptomoedas e notícias econômicas usando os dados disponíveis. ${summary}\nFaça uma pergunta mais específica, por exemplo: “Minha carteira está concentrada?” ou “Como juros altos afetam meus investimentos?”.`;
 }
 if(!body)body='Não consegui formar uma resposta sustentada pelos dados disponíveis.';
 return {kind:'rule',text:body+'\n\n**Nota:** análise automatizada e educativa, não recomendação personalizada nem consulta a um modelo generativo.',sources};
}
