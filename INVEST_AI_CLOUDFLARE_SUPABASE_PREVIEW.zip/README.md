# INVEST AI — Cloudflare Workers + Supabase (prévia de migração)

**Status:** fonte preparada; ainda NÃO está publicada nem conectada a um projeto Supabase real. Render continua ativo, sem alterações.

## Arquitetura gratuita
- Next.js export estático hospedado com **Cloudflare Workers Static Assets**, com Worker dinâmico em `/api/*`.
- **Supabase Free Auth** para contas com e-mail e senha; **PostgreSQL + RLS** para backups individuais.
- Backup **manual** com controle de revisão otimista. Nunca sincroniza automaticamente ou sobrescreve dados sem confirmação.
- Gemini **Flash-Lite** opcional, com chave privada no Worker e limite de 12 perguntas autenticadas por dia/conta; se não houver cota gratuita ou chave, continua o assistente local baseado em regras, sem cobrança.
- O site original https://invest-ai-web.onrender.com permanece funcionando até validação da nova versão.

## 1. Configurar Supabase (sem cartão, Free)
1. Entre em https://supabase.com/dashboard, crie projeto **Free** (não ative plano pago).
2. SQL Editor → execute `supabase/migrations/20261008_invest_ai_initial.sql` para criar as tabelas, políticas RLS e funções de salvamento/limite.
3. Project Settings → API Keys: copie a **Project URL** e a chave **publishable** (`sb_publishable_...`). Essa chave pode ir no frontend; **NUNCA** use secret/service_role.
4. Authentication → Providers → Email: habilite cadastros. Confirmação de e-mail é recomendada. Configure Site URL e Redirect URLs para o endereço `.workers.dev` definitivo (além de recuperação de senha).

## 2. Cloudflare Workers (sem plano pago)
1. Entre em https://dash.cloudflare.com, Workers & Pages; use plano gratuito sem cadastrar cartão.
2. No código da pasta `frontend`, configure **apenas** variáveis públicas de build `NEXT_PUBLIC_SUPABASE_URL` e `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` (os valores reais do seu projeto, não os exemplos).
3. Execute `npm install`, `npm test`, `npm run lint`, `npm run build` e `npx wrangler deploy` com login do Cloudflare (ou conecte o repositório GitHub com a pasta `frontend` como raiz).
4. No ambiente do Worker, configure `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY` e, **somente se houver uma chave gratuita sem billing**, `GEMINI_API_KEY` como Secret via `npx wrangler secret put GEMINI_API_KEY`.
5. Worker só chama IA generativa se `GEMINI_API_KEY` estiver configurada; a cota gratuita pode mudar ou ficar indisponível. Nenhuma compra/crédito é ativado pelo código.

## 3. Como validar
- Abra `/api/health` no endereço Workers: `auth_configured` deve ser true após configurar variáveis de Worker.
- Crie conta com um e-mail de teste, confirme o e-mail, faça login.
- Registre um ativo local, envie backup e abra outra janela anônima para restaurar somente depois de logar na mesma conta.
- Teste com segunda conta: ela NÃO deve ler backup da primeira (RLS).
- Teste colisão de revisão: salvar com versão antiga deve falhar, nunca sobrescrever silenciosamente.
- Teste Gemini sem secret: HTTP 503 e modo local ainda funciona.

## Limitações honestas
- Backend Python antigo **não** é executado no Cloudflare Workers. Este ramo migra a funcionalidade de cadastro/backup/IA específica para Supabase + Worker JS.
- Dados do navegador Render **não migram automaticamente** para o novo endereço. Exporte JSON no Render e importe manualmente no Cloudflare se desejar.
- O Supabase Free pode pausar após período de inatividade; faça backups e acompanhe cotas. O plano gratuito Cloudflare também possui limites.
- IA não prevê mercado. Não há integração de corretora, ordens reais nem alertas push.
- Revisão de segurança e testes reais no Supabase/Cloudflare são necessários antes de abrir o produto ao público.
