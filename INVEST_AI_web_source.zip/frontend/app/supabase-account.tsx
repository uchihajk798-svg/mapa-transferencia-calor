'use client';
import { useEffect, useState, type FormEvent } from 'react';
import { Cloud, CloudUpload, CloudDownload, LockKeyhole, LogOut, ShieldAlert } from 'lucide-react';
import type { User as SupaUser } from '@supabase/supabase-js';
import type { LocalStore } from '@/lib/local-finance';
import { sanitizeBackup } from '@/lib/local-finance';
import { getSupabase, supabaseConfigured } from '@/lib/supabase';

type Snapshot = {revision: number; data: unknown | null; updated_at: string | null};
const empty: Snapshot = {revision: 0, data: null, updated_at: null};

function message(error: unknown): string {
  return error instanceof Error ? error.message : 'Falha na comunicação. Tente novamente.';
}

export default function SupabaseAccount({ store, onRestore, onToken }: {
  store: LocalStore; onRestore: (s: LocalStore) => void; onToken: (token: string) => void;
}) {
  const [user, setUser] = useState<SupaUser | null>(null);
  const [mode, setMode] = useState<'register'|'login'|'reset'|'change'>('register');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState('');
  const [error, setError] = useState('');
  const [snapshot, setSnapshot] = useState<Snapshot>(empty);
  const client = getSupabase();

  useEffect(() => {
    if (!client) return;
    let live = true;
    void client.auth.getSession().then(({data}) => {
      if (live) { setUser(data.session?.user ?? null); onToken(data.session?.access_token ?? ''); }
    });
    const { data: subscription } = client.auth.onAuthStateChange((event, session) => {
      if (!live) return;
      if (event === 'PASSWORD_RECOVERY') setMode('change');
      setUser(session?.user ?? null);
      onToken(session?.access_token ?? '');
      if (!session) setSnapshot(empty);
    });
    return () => { live = false; subscription.subscription.unsubscribe(); };
  }, [client, onToken]);

  const fetchBackup = async (id: string): Promise<Snapshot> => {
    if (!client) throw new Error('Supabase não configurado.');
    const { data, error: err } = await client.from('invest_ai_backups')
      .select('revision,data,updated_at').eq('user_id', id).maybeSingle();
    if (err) throw err;
    const result = data ? (data as Snapshot) : empty;
    setSnapshot(result);
    return result;
  };

  useEffect(() => {
    if (!user) return;
    let alive = true;
    void fetchBackup(user.id).catch(e => { if (alive) setError('Backup online: ' + message(e)); });
    return () => { alive = false; };
    // user ID is the only input; the client remains singleton.
  }, [user?.id]);

  const authenticate = async (e: FormEvent) => {
    e.preventDefault(); if (!client) return;
    setError(''); setNote(''); setBusy(true);
    try {
      if (mode === 'reset') {
        const {error: err} = await client.auth.resetPasswordForEmail(email.trim(), {
          redirectTo: typeof window !== 'undefined' ? window.location.origin : undefined
        });
        if (err) throw err;
        setNote('Se o e-mail estiver cadastrado, você receberá as instruções de recuperação.');
      } else if (mode === 'register') {
        const { data, error: err } = await client.auth.signUp({
          email: email.trim(), password, options: {
            emailRedirectTo: typeof window !== 'undefined' ? window.location.origin : undefined,
            data: { full_name: name.trim().slice(0,100) }
          }
        });
        if (err) throw err;
        setPassword('');
        setNote(data.session ? 'Conta criada e conectada.' : 'Confira seu e-mail para confirmar o cadastro. Se a mensagem não chegar, verifique o spam.');
      } else {
        const { error: err } = await client.auth.signInWithPassword({email:email.trim(),password});
        if (err) throw err;
        setPassword(''); setNote('Você entrou na conta. Confira o backup antes de salvar ou restaurar.');
      }
    } catch (e) { setError(message(e)); } finally { setBusy(false); }
  };

  const changePassword = async (e: FormEvent) => {
    e.preventDefault(); if (!client) return;
    setBusy(true); setError('');
    try {
      const {error: err} = await client.auth.updateUser({password});
      if (err) throw err;
      setPassword(''); setMode('login');
      setNote('Senha atualizada. Faça login novamente quando a sessão expirar.');
    } catch(e) { setError(message(e)); } finally { setBusy(false); }
  };

  const upload = async () => {
    if (!client || !user) return;
    if (!window.confirm('Salvar a carteira atual na nuvem? Confirme que o backup do navegador está correto.')) return;
    setBusy(true); setError(''); setNote('');
    try {
      const latest = await fetchBackup(user.id);
      if (latest.revision && !window.confirm('Já existe um backup na nuvem. Deseja substituir pela carteira deste navegador?')) return;
      const payload = {version: 1, ...store};
      const { error: err } = await client.rpc('invest_ai_save_backup', {
        p_expected_revision: latest.revision, p_data: payload,
      });
      if (err) throw err;
      await fetchBackup(user.id);
      setNote('Backup salvo. Novas movimentações precisam de outro salvamento manual.');
    } catch (e) { setError('Não foi possível salvar: ' + message(e) + '. Se houver conflito, atualize a página antes de tentar novamente.'); }
    finally { setBusy(false); }
  };
  const restore = async () => {
    if (!client || !user) return;
    setBusy(true); setError(''); setNote('');
    try {
      const latest = await fetchBackup(user.id);
      if (!latest.data) throw new Error('A conta não tem backup.');
      const safe = sanitizeBackup(latest.data);
      if (!window.confirm(`Restaurar ${safe.entries.length} movimentações da nuvem? Isso substitui os dados deste navegador. Exporte antes um backup local.`)) return;
      onRestore(safe); setNote('Backup restaurado no navegador.');
    } catch(e) { setError(message(e)); } finally { setBusy(false); }
  };
  const logout = async () => {
    if (!client) return;
    const {error: err} = await client.auth.signOut();
    if (err) setError(message(err));
    else {setNote('Você saiu da conta. Seus dados locais continuam neste navegador.');setSnapshot(empty);}
  };

  return <div className="gcard gcloud">
    <div className="gsection"><h2><Cloud size={20}/> Minha conta — Supabase</h2><p>Cadastro e backup na nuvem, independentes da carteira local. O login só é ativado quando um projeto Supabase gratuito estiver configurado.</p></div>
    {!supabaseConfigured() || !client ? <div className="ginlineinfo"><ShieldAlert size={17}/> Ainda falta conectar o projeto Supabase. Continue usando a carteira local e exporte um arquivo JSON como segurança.</div>
      : user ? <>
        {mode === 'change' && <form className="gform" onSubmit={e=>void changePassword(e)}><label>Nova senha<input type="password" minLength={10} maxLength={128} required autoComplete="new-password" value={password} onChange={e=>setPassword(e.target.value)}/></label><button type="submit" className="gprimary" disabled={busy}>Definir nova senha</button></form>}
        <div className="gcloudwho"><strong>{user.email || 'Sua conta'}</strong><button className="gsecondary" type="button" onClick={()=>void logout()}><LogOut size={16}/> Sair</button></div>
        <p className="gmuted">Backup remoto: {snapshot.revision ? `versão ${snapshot.revision}` : 'nenhum'}. {snapshot.updated_at ? `Atualizado em ${new Date(snapshot.updated_at).toLocaleString('pt-BR')}.` : ''}</p>
        <div className="grow"><button className="gprimary" onClick={()=>void upload()} disabled={busy}><CloudUpload size={16}/> Salvar na nuvem</button><button className="gsecondary" onClick={()=>void restore()} disabled={busy || !snapshot.data}><CloudDownload size={16}/> Restaurar backup</button></div>
        <p className="gmuted gmini">Sincronização manual. Não compartilhe dados bancários nem senhas. O backup fica protegido por políticas que limitam cada conta aos próprios dados.</p>
      </> : <>
        <div className="gcloudtabs"><button className={mode==='register'?'gprimary':'gsecondary'} onClick={()=>setMode('register')}>Criar conta</button><button className={mode==='login'?'gprimary':'gsecondary'} onClick={()=>setMode('login')}>Entrar</button><button className={mode==='reset'?'gprimary':'gsecondary'} onClick={()=>setMode('reset')}>Esqueci a senha</button></div>
        <form className="gform" onSubmit={e=>void authenticate(e)}>
          {mode==='register'&&<label>Nome<input required minLength={2} maxLength={100} autoComplete="name" value={name} onChange={e=>setName(e.target.value)}/></label>}
          <label>E-mail<input type="email" autoComplete="email" required value={email} onChange={e=>setEmail(e.target.value)}/></label>
          {mode!=='reset'&&<label>Senha<input type="password" required minLength={mode==='register'?10:1} maxLength={128} autoComplete={mode==='register'?'new-password':'current-password'} value={password} onChange={e=>setPassword(e.target.value)}/></label>}
          <button type="submit" className="gprimary" disabled={busy}><LockKeyhole size={16}/>{busy?'Aguarde…':mode==='register'?'Criar conta grátis':mode==='login'?'Entrar':'Enviar recuperação'}</button>
        </form>
      </>}
    {note&&<div className="ginlineinfo">{note}</div>}{error&&<div className="ginlinewarn">{error}</div>}
    <p className="gmuted gmini">O Supabase Free pode pausar após inatividade. Mantenha seus backups JSON locais; este produto está em fase de testes.</p>
  </div>;
}
