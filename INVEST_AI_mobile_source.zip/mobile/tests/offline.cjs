const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
function load(filename){const raw=fs.readFileSync(path.join(__dirname,'..','src',filename),'utf8');const compiled=ts.transpileModule(raw,{fileName:filename,reportDiagnostics:true,compilerOptions:{target:ts.ScriptTarget.ES2020,module:ts.ModuleKind.CommonJS}});assert.equal(compiled.diagnostics?.length||0,0);const module={exports:{}};new Function('module','exports',compiled.outputText)(module,module.exports);return module.exports;}
const {positionsFromTrades,validateTrade,inputNumber,validateLocal}=load('offline.ts');
assert.equal(inputNumber('1.234,56'),1234.56);
assert.equal(inputNumber(''),Number.NaN);
const t=(id,kind,quantity,price,fee=0)=>({id,symbol:'PETR4',kind,quantity,price,fee,date:`2026-10-${String(id).padStart(2,'0')}T10:00:00.000Z`});
const purchases=[t(1,'BUY',10,12,1),t(2,'BUY',10,18,1)];
assert.equal(positionsFromTrades(purchases)[0].cost,302);
assert.equal(positionsFromTrades(purchases)[0].average,15.1);
const p=positionsFromTrades([...purchases,t(3,'SELL',5,20,2)])[0];
assert.equal(p.quantity,15);assert(Math.abs(p.realized-22.5)<1e-8);
assert.match(validateTrade(purchases,t(3,'SELL',21,20)),'Venda');
assert.equal(validateTrade(purchases,t(3,'SELL',5,20)),null);
assert.equal(validateLocal({version:1,trades:purchases,watchlist:['PETR4'],name:'Ana'}).trades.length,2);
assert.equal(validateLocal({version:1,trades:[t(1,'SELL',2,10)],watchlist:[]}).trades.length,0);
console.log('Offline portfolio + parsers: PASS (11 checks)');
