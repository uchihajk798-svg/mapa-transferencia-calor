import React, {useCallback, useEffect, useState} from 'react';
import {
  ActivityIndicator, Alert, BackHandler, Modal, Platform,
  Pressable, RefreshControl, SafeAreaView, ScrollView, Share, StatusBar,
  StyleSheet, Switch, Text, TextInput, View, type TextStyle, type ViewStyle,
} from 'react-native';
import {StatusBar as ExpoStatusBar} from 'expo-status-bar';
import {api, apiConfigured, ApiError, confirmReset, login, logout, register, requestReset, resetLocalSession, restoreSession} from './src/api';
import {brl, COINS, coinName, dateTime, initialPrefs, initialProfile, pct, type CryptoResult, type Portfolio, type Prefs, type Profile, type Selic, type Tab, type User, type Watch} from './src/types';
import {calculateScenario} from './src/simulator';
import OfflineApp from './src/OfflineApp';

const DARK={bg:'#081320',panel:'#112338',panel2:'#182E42',text:'#F8FAFC',muted:'#9DAFC2',border:'#284054',primary:'#10B981',strong:'#054A38',red:'#FB7185',ink:'#071B13',soft:'#134535'};
const LIGHT={bg:'#F3F7F9',panel:'#FFFFFF',panel2:'#E9F2F4',text:'#142236',muted:'#62748A',border:'#DFE7EA',primary:'#058B62',strong:'#075D47',red:'#C62846',ink:'#FFFFFF',soft:'#DDF7EA'};
type Theme=typeof DARK;
const ThemeContext=React.createContext<Theme>(DARK);
const usePalette=()=>React.useContext(ThemeContext);

type TextVariant='hero'|'h1'|'h2'|'body'|'caption'|'micro';
function Txt({children,variant='body',muted=false,color,style}:{children:React.ReactNode;variant?:TextVariant;muted?:boolean;color?:string;style?:TextStyle}){
  const c=usePalette();
  const size:Record<TextVariant,TextStyle>={hero:{fontSize:31,fontWeight:'800',letterSpacing:-1.1},h1:{fontSize:24,fontWeight:'800',letterSpacing:-.5},h2:{fontSize:17,fontWeight:'700'},body:{fontSize:14.5,lineHeight:21},caption:{fontSize:12,lineHeight:18},micro:{fontSize:10,fontWeight:'700',letterSpacing:1}};
  return <Text style={[{color:color||(muted?c.muted:c.text)},size[variant],style]}>{children}</Text>;
}
function Panel({children,style}:{children:React.ReactNode;style?:ViewStyle}){const c=usePalette();return <View style={[s.panel,{backgroundColor:c.panel,borderColor:c.border},style]}>{children}</View>;}
function Primary({label,onPress,loading=false,disabled=false,secondary=false,danger=false,small=false}:{label:string;onPress:()=>void;loading?:boolean;disabled?:boolean;secondary?:boolean;danger?:boolean;small?:boolean}){
  const c=usePalette();return <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} disabled={loading||disabled} style={({pressed})=>[s.button,{backgroundColor:danger?c.red:secondary?c.panel2:c.primary,opacity:(loading||disabled)?0.55:(pressed?0.77:1),minHeight:small?38:49,paddingHorizontal:small?12:18}]}>{loading?<ActivityIndicator color={c.ink}/>:<Txt style={{color:danger?'#FFFFFF':secondary?c.text:c.ink,fontWeight:'800',textAlign:'center'}}>{label}</Txt>}</Pressable>;
}
function Field({label,value,onChange,placeholder='',secure=false,keyboard='default',multiline=false}:{label:string;value:string;onChange:(text:string)=>void;placeholder?:string;secure?:boolean;keyboard?:'default'|'email-address'|'decimal-pad'|'numeric';multiline?:boolean}){
  const c=usePalette();return <View style={{gap:6}}><Txt variant="caption" style={{fontWeight:'700'}}>{label}</Txt><TextInput accessibilityLabel={label} placeholder={placeholder} placeholderTextColor={c.muted} value={value} onChangeText={onChange} secureTextEntry={secure} autoCapitalize={secure||keyboard==='email-address'?'none':'sentences'} autoCorrect={false} keyboardType={keyboard} multiline={multiline} style={[s.input,{borderColor:c.border,backgroundColor:c.panel2,color:c.text,minHeight:multiline?90:48,textAlignVertical:multiline?'top':'center'}]}/></View>;
}
function SmallChip({label,onPress,selected=false}:{label:string;onPress:()=>void;selected?:boolean}){
  const c=usePalette();return <Pressable accessibilityRole="button" accessibilityState={{selected}} onPress={onPress} style={[s.chip,{backgroundColor:selected?c.soft:c.panel2,borderColor:selected?c.primary:c.border}]}><Txt variant="caption" color={selected?c.primary:c.text} style={{fontWeight:selected?'800':'600'}}>{label}</Txt></Pressable>;
}
function Msg({message}:{message:string}){const c=usePalette();if(!message)return null;return <View style={[s.msg,{borderColor:c.red}]}><Txt color={c.red}>{message}</Txt></View>;}
function Divider(){const c=usePalette();return <View style={{height:1,backgroundColor:c.border,marginVertical:4}}/>;}
function SectionHead({title,subtitle}:{title:string;subtitle?:string}){return <View style={{gap:5,marginBottom:11}}><Txt variant="h2">{title}</Txt>{subtitle?<Txt variant="caption" muted>{subtitle}</Txt>:null}</View>}
function StatusTag({label}:{label:string}){const c=usePalette();return <View style={{alignSelf:'flex-start',backgroundColor:c.soft,paddingHorizontal:10,paddingVertical:5,borderRadius:16}}><Txt variant="micro" color={c.primary}>{label}</Txt></View>}
const track=(error:unknown,setError:(v:string)=>void)=>setError(error instanceof Error?error.message:'Não foi possível concluir.');

const STEPS:{key:keyof Profile;title:string;sub:string;options:{label:string;value:string}[]}[]=[
  {key:'experience',title:'Você já investiu?',sub:'A experiência muda a linguagem do aplicativo.',options:[{label:'Nunca investi',value:'beginner'},{label:'Já sei o básico',value:'intermediate'},{label:'Invisto há algum tempo',value:'advanced'}]},
  {key:'goal',title:'O que quer alcançar?',sub:'Seu objetivo ajuda a organizar os conteúdos.',options:[{label:'Começar a aprender',value:'learn'},{label:'Criar reserva',value:'reserve'},{label:'Aumentar patrimônio',value:'growth'},{label:'Receber renda',value:'income'},{label:'Aposentadoria',value:'retirement'}]},
  {key:'horizon',title:'Por quanto tempo?',sub:'Horizonte é o prazo esperado para usar o dinheiro.',options:[{label:'Ainda não sei',value:'unsure'},{label:'Até 1 ano',value:'short'},{label:'De 1 a 5 anos',value:'medium'},{label:'Mais de 5 anos',value:'long'}]},
  {key:'liquidity',title:'Quando vai precisar?',sub:'Liquidez é a facilidade de retirar dinheiro.',options:[{label:'Não sei ainda',value:'unsure'},{label:'Em qualquer momento',value:'immediate'},{label:'Em alguns meses',value:'months'},{label:'Só daqui a anos',value:'years'}]},
  {key:'risk_tolerance',title:'Como vê as perdas?',sub:'Investimentos podem oscilar ou perder valor.',options:[{label:'Não sei',value:'unsure'},{label:'Quero evitar perdas',value:'low'},{label:'Aceito alguma queda',value:'medium'},{label:'Aceito grande oscilação',value:'high'}]},
  {key:'interests',title:'O que deseja explorar?',sub:'Escolha quantas categorias quiser.',options:[{label:'Renda fixa',value:'fixed'},{label:'Ações',value:'stocks'},{label:'Fundos',value:'funds'},{label:'Criptomoedas',value:'crypto'},{label:'Mercado global',value:'global'},{label:'ETFs',value:'etfs'}]},
];
const lessons=[
  {title:'O que é investir?',summary:'Investir é aplicar recursos buscando objetivos futuros, assumindo riscos e condições específicas.',simple:'Antes de investir, faça um orçamento, cuide das dívidas mais caras e conheça a diferença entre guardar e investir. Ganhos não são garantidos.',terms:'Objetivo, prazo e risco.'},
  {title:'Reserva de emergência',summary:'É um dinheiro separado para imprevistos, com foco em liquidez e baixo risco.',simple:'Uma reserva deve estar em instrumentos que permitam resgates nas condições necessárias. Verifique carência, horário de resgate e proteção aplicável.',terms:'Liquidez: facilidade de acessar o dinheiro.'},
  {title:'Renda fixa e Tesouro',summary:'Produtos de renda fixa seguem regras de remuneração definidas, mas podem ter riscos.',simple:'Tesouro Selic é um título público brasileiro. Ao comparar opções, verifique taxa, imposto, prazos, risco do emissor e marcação a mercado.',terms:'Vencimento: dia previsto para pagamento do título.'},
  {title:'Ações e dividendos',summary:'Uma ação representa participação numa empresa; os preços variam.',simple:'Dividendos são distribuições de resultados quando declaradas pela empresa. Não são certos e não anulam riscos de queda no preço da ação.',terms:'Volatilidade: intensidade das oscilações de preço.'},
  {title:'FIIs, ETFs e fundos',summary:'Fundos reúnem recursos para investir segundo uma estratégia.',simple:'Compare carteiras, custos, liquidez, riscos e regulamento. FIIs e ETFs podem perder valor e seus rendimentos não são garantidos.',terms:'Taxa de administração: custo cobrado pelo fundo.'},
  {title:'Criptomoedas',summary:'Criptoativos têm riscos próprios, incluindo preço, custódia e fraudes.',simple:'Bitcoin e outros ativos podem oscilar muito; também há riscos regulatórios, de plataforma e de perda de chaves de acesso. Stablecoin não significa garantia absoluta.',terms:'Custódia: responsabilidade pela guarda dos ativos.'},
];

function AuthView({onSuccess,onGuest}:{onSuccess:(user:User)=>void;onGuest:()=>void}){
  const c=usePalette();const [mode,setMode]=useState<'login'|'register'|'forgot'|'confirm'>('login');
  const[email,setEmail]=useState('');const[pass,setPass]=useState('');const[name,setName]=useState('');
  const[token,setToken]=useState('');const[busy,setBusy]=useState(false);const[error,setError]=useState('');const[done,setDone]=useState('');
  const submit=async()=>{setError('');setDone('');setBusy(true);try{
    if(mode==='login')onSuccess(await login(email.trim(),pass));
    if(mode==='register')onSuccess(await register(name.trim(),email.trim(),pass));
    if(mode==='forgot'){const res=await requestReset(email.trim());setDone(res.message);setMode('confirm');}
    if(mode==='confirm'){await confirmReset(token.trim(),pass);setDone('Senha alterada. Entre com sua nova senha.');setPass('');setMode('login');}
  }catch(e){track(e,setError)}finally{setBusy(false)}};
  return <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{padding:25,paddingTop:45,paddingBottom:50,gap:22,flexGrow:1,justifyContent:'center'}}>
    <View style={{flexDirection:'row',alignItems:'center',gap:12}}><View style={{backgroundColor:c.primary,borderRadius:18,width:53,height:53,justifyContent:'center',alignItems:'center'}}><Txt color={c.ink} variant="h1">✦</Txt></View><View><Txt variant="h1">INVEST AI</Txt><Txt variant="caption" color={c.primary}>SEU DINHEIRO, MAIS INTELIGENTE</Txt></View></View>
    <View style={{marginTop:14,gap:8}}><StatusTag label="VERSÃO MOBILE"/><Txt variant="hero">Invista em{ '\n' }conhecimento.</Txt><Txt muted>Entenda seu dinheiro. Descubra oportunidades. Invista com mais consciência.</Txt></View>
    <Panel style={{gap:14}}><Txt variant="h2">{mode==='login'?'Entre na sua conta':mode==='register'?'Comece gratuitamente':mode==='forgot'?'Recuperar acesso':'Insira o código recebido'}</Txt>
      {mode==='register'?<Field label="Nome" value={name} onChange={setName} placeholder="Como quer ser chamado?"/>:null}
      {mode!=='confirm'?<Field label="E-mail" value={email} onChange={setEmail} keyboard="email-address" placeholder="email@exemplo.com"/>:null}
      {mode==='confirm'?<Field label="Código recebido" value={token} onChange={setToken} placeholder="Código do e-mail"/>:null}
      {mode!=='forgot'?<Field label={mode==='confirm'?'Nova senha (10 caracteres ou mais)':'Senha'} value={pass} onChange={setPass} secure placeholder="Sua senha"/>:null}
      <Msg message={error}/>{done?<Txt color={c.primary}>{done}</Txt>:null}
      <Primary label={mode==='login'?'Entrar':mode==='register'?'Criar conta':mode==='forgot'?'Solicitar código':'Trocar senha'} onPress={submit} loading={busy}/>
      <Pressable onPress={()=>{setMode(mode==='login'?'register':'login');setError('');setDone('')}} accessibilityRole="button"><Txt color={c.primary} style={{textAlign:'center',fontWeight:'800'}}>{mode==='login'?'Ainda não tem conta? Cadastre-se':'Voltar para entrar'}</Txt></Pressable>
      {mode==='login'?<Pressable onPress={()=>{setMode('forgot');setError('')}} accessibilityRole="button"><Txt muted style={{textAlign:'center'}}>Esqueci minha senha</Txt></Pressable>:null}
      <Txt muted variant="caption">A recuperação por e-mail só funciona com SMTP configurado no servidor.</Txt>
    </Panel>
    <Primary label="Explorar sem criar conta" onPress={onGuest} secondary/>
    {!apiConfigured()?<Msg message="API não configurada. O modo sem conta permite acessar a Academia e o simulador; login e carteira exigem servidor."/>:null}
    <Txt variant="caption" muted style={{textAlign:'center'}}>INVEST AI oferece educação e registro pessoal. Não executa compras ou vendas em corretoras e não garante rendimentos.</Txt>
  </ScrollView>
}
function OnboardingView({value,onSave}:{value:Profile;onSave:(p:Profile)=>Promise<void>}){
  const c=usePalette();const [step,setStep]=useState(0);const [v,setV]=useState<Profile>(value);const[busy,setBusy]=useState(false);const[error,setError]=useState('');
  const item=STEPS[step];
  const choose=(key:keyof Profile,option:string)=>{
    if(key==='interests'){const interests=v.interests.includes(option as Profile['interests'][number])?v.interests.filter(x=>x!==option):[...v.interests,option as Profile['interests'][number]];setV({...v,interests});}
    else setV({...v,[key]:option});
  };
  const next=async()=>{if(step<STEPS.length-1){setStep(step+1);return}setBusy(true);try{await onSave({...v,onboarding_completed:true})}catch(e){track(e,setError)}finally{setBusy(false)}};
  return <ScrollView contentContainerStyle={{padding:24,paddingBottom:40,gap:24,flexGrow:1,justifyContent:'center'}}>
    <View style={{flexDirection:'row',gap:7}}>{STEPS.map((_,i)=><View key={i} style={{flex:1,height:5,borderRadius:4,backgroundColor:i<=step?c.primary:c.border}}/>)}</View>
    <View style={{gap:9}}><Txt variant="micro" color={c.primary}>PASSO {step+1} DE {STEPS.length}</Txt><Txt variant="hero">{item.title}</Txt><Txt muted>{item.sub}</Txt></View>
    <View style={{gap:10}}>{item.options.map(op=>{const selected=item.key==='interests'?v.interests.includes(op.value as Profile['interests'][number]):v[item.key]===op.value;return <Pressable key={op.value} onPress={()=>choose(item.key,op.value)} style={[s.option,{backgroundColor:selected?c.soft:c.panel,borderColor:selected?c.primary:c.border}]}><Txt style={{fontWeight:selected?'800':'500'}}>{op.label}</Txt><Txt color={selected?c.primary:c.muted}>{selected?'✓':'○'}</Txt></Pressable>})}</View>
    <Msg message={error}/><View style={{flexDirection:'row',gap:9}}>{step>0?<View style={{flex:1}}><Primary label="Voltar" onPress={()=>setStep(step-1)} secondary/></View>:null}<View style={{flex:2}}><Primary label={step===STEPS.length-1?'Concluir':'Continuar'} onPress={next} loading={busy}/></View></View>
    <Txt variant="caption" muted>Seu perfil personaliza os conteúdos, não cria uma recomendação individualizada de compra.</Txt>
  </ScrollView>
}

type ExplorePage='markets'|'learn'|'simulator'|'global';
function Simulator(){
  const c=usePalette();const[raw,setRaw]=useState({initial:'200',monthly:'100',years:'5',rate:'8',inflation:'4',tax:'15'});
  const nums=Object.fromEntries(Object.entries(raw).map(([k,v])=>[k,Number(v.replace(',','.'))])) as unknown as {initial:number;monthly:number;years:number;rate:number;inflation:number;tax:number};
  const middle=calculateScenario(nums);const lower=calculateScenario(nums,nums.rate-6);const upper=calculateScenario(nums,nums.rate+6);
  return <View style={{gap:14}}><Panel style={{gap:12}}><SectionHead title="Simulador de juros compostos" subtitle="Exemplo matemático editável, não previsão do mercado."/>
    {([{key:'initial',label:'Valor inicial (R$)'},{key:'monthly',label:'Aporte mensal (R$)'},{key:'years',label:'Anos'},{key:'rate',label:'Taxa anual hipotética (%)'},{key:'inflation',label:'Inflação hipotética (%)'},{key:'tax',label:'Imposto hipotético sobre ganhos (%)'}] as const).map(x=><Field key={x.key} label={x.label} value={raw[x.key]} onChange={v=>setRaw(old=>({...old,[x.key]:v}))} keyboard="decimal-pad"/>)}
    {middle?<><Divider/><Txt muted variant="caption">Cenário central: valor líquido ilustrativo</Txt><Txt variant="hero" color={c.primary}>{brl(middle.net)}</Txt><Txt muted>Você teria aportado: {brl(middle.invested)}</Txt><Txt muted>Poder de compra estimado: {brl(middle.real)}</Txt><View style={{gap:8}}><Txt variant="caption">Cenário menor (-6 p.p.): {lower?brl(lower.net):'Inválido'}</Txt><Txt variant="caption">Cenário maior (+6 p.p.): {upper?brl(upper.net):'Inválido'}</Txt></View></>:<Msg message="Confira os valores: prazo entre 1 mês e 50 anos; taxas anuais entre -100% e 100%; imposto de 0 a 100%."/>}
    <Txt muted variant="caption">Hipóteses: aportes no fim do mês, taxa anual convertida em taxa efetiva mensal, imposto simplificado apenas sobre lucro positivo e inflação constante. Não inclui volatilidade real, IOF nem regras de cada produto.</Txt>
  </Panel></View>
}

function GuestView({onExit}:{onExit:()=>void}){
  const c=usePalette();const[view,setView]=useState<'learn'|'simulator'>('learn');const[opened,setOpened]=useState<number|null>(null);
  return <View style={{flex:1}}><View style={[s.head,{borderColor:c.border}]}><View><Txt variant="micro" color={c.primary}>✦ INVEST AI</Txt><Txt variant="h1">Explore sem conta</Txt></View><Primary label="Entrar" onPress={onExit} small secondary/></View>
    <ScrollView contentContainerStyle={{padding:18,gap:14,paddingBottom:32}}><Panel style={{backgroundColor:c.strong,borderColor:c.strong,gap:9}}><StatusTag label="MODO EDUCATIVO"/><Txt variant="h1" color="#FFFFFF">Comece pelo conhecimento.</Txt><Txt color="#D0F6E2">Neste modo não há cotações, recomendações, cadastro de carteira ou dados simulados de investimentos.</Txt></Panel>
      <View style={{flexDirection:'row',gap:10}}><SmallChip label="Academia" selected={view==='learn'} onPress={()=>setView('learn')}/><SmallChip label="Simulador" selected={view==='simulator'} onPress={()=>setView('simulator')}/></View>
      {view==='simulator'?<Simulator/>:lessons.map((l,i)=><Pressable key={l.title} accessibilityRole="button" onPress={()=>setOpened(opened===i?null:i)}><Panel style={{gap:10}}><View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'center'}}><Txt variant="h2">{i+1}. {l.title}</Txt><Txt color={c.primary}>{opened===i?'−':'+'}</Txt></View><Txt muted>{l.summary}</Txt>{opened===i?<><Divider/><Txt>{l.simple}</Txt><Txt muted variant="caption">{l.terms}</Txt></>:null}</Panel></Pressable>)}
    </ScrollView><View style={[s.nav,{backgroundColor:c.panel,borderColor:c.border,padding:12}]}><View style={{flex:1}}><Primary label="Criar conta para salvar carteira" onPress={onExit}/></View></View></View>;
}
function InvestApp({onTheme}:{onTheme:(theme:'dark'|'light')=>void}){
  const c=usePalette();
  const[user,setUser]=useState<User|null>(null);const [loading,setLoading]=useState(true);const[hydrated,setHydrated]=useState(false);const[guest,setGuest]=useState(false);
  const[tab,setTab]=useState<Tab>('home');const[page,setPage]=useState<ExplorePage>('markets');
  const[profile,setProfile]=useState<Profile>(initialProfile);const[prefs,setPrefs]=useState<Prefs>(initialPrefs);
  const[portfolio,setPortfolio]=useState<Portfolio|null>(null);const[watch,setWatch]=useState<Watch[]>([]);
  const[crypto,setCrypto]=useState<CryptoResult|null>(null);const[selic,setSelic]=useState<Selic|null>(null);
  const[marketError,setMarketError]=useState('');const[dataError,setDataError]=useState('');const[busy,setBusy]=useState(false);
  const[help,setHelp]=useState(false);const[lesson,setLesson]=useState<number|null>(null);
  const[txOpen,setTxOpen]=useState(false);const[txType,setTxType]=useState<'BUY'|'SELL'>('BUY');const[txCoin,setTxCoin]=useState<'bitcoin'|'ethereum'|'solana'|'usd-coin'|'OTHER'>('bitcoin');
  const[qty,setQty]=useState('');const[price,setPrice]=useState('');const[fee,setFee]=useState('0');
  const[fullName,setFullName]=useState('');const[deletePass,setDeletePass]=useState('');const[sessions,setSessions]=useState<{id:string;user_agent:string;created_at:string;current:boolean}[]>([]);
  const[selectedTopic,setSelectedTopic]=useState('Liquidez');const[refreshing,setRefreshing]=useState(false);
  const loginDone=useCallback((u:User)=>{setHydrated(false);setUser(u);setFullName(u.full_name);},[]);
  const privateData=useCallback(async()=>{
    if(!user)return;
    try{const [p,preferences,port,w]=await Promise.all([api<Profile>('/me/investor-profile'),api<Prefs>('/me/preferences'),api<Portfolio>('/portfolio'),api<Watch[]>('/watchlist')]);setProfile(p);setPrefs(preferences);onTheme(preferences.theme);setPortfolio(port);setWatch(w);setDataError('');}
    catch(e){track(e,setDataError);if(e instanceof ApiError&&e.status===401)setUser(null)}finally{setHydrated(true)}
  },[user,onTheme]);
  const marketData=useCallback(async()=>{
    const r=await Promise.allSettled([api<CryptoResult>('/market/crypto'),api<Selic>('/market/selic')]);
    if(r[0].status==='fulfilled')setCrypto(r[0].value);else setCrypto(null);
    if(r[1].status==='fulfilled')setSelic(r[1].value);else setSelic(null);
    setMarketError(r.every(x=>x.status==='rejected')?'As fontes externas estão indisponíveis. Tente atualizar mais tarde.':r.some(x=>x.status==='rejected')?'Parte das fontes está temporariamente indisponível.':'');
  },[]);
  useEffect(()=>{let mounted=true;(async()=>{try{const u=await restoreSession();if(mounted&&u)loginDone(u);}catch(e){if(mounted&&!(e instanceof ApiError&&e.status===401))track(e,setDataError);}finally{if(mounted)setLoading(false)}})();return()=>{mounted=false}},[loginDone]);
  useEffect(()=>{if(user){privateData();marketData()}},[user,privateData,marketData]);
  const refresh=useCallback(async()=>{setRefreshing(true);await Promise.all([privateData(),marketData()]);setRefreshing(false)},[privateData,marketData]);
  useEffect(()=>{const sub=BackHandler.addEventListener('hardwareBackPress',()=>{if(help){setHelp(false);return true}if(lesson!==null){setLesson(null);return true}if(txOpen){setTxOpen(false);return true}if(tab!=='home'){setTab('home');return true}return false});return()=>sub.remove()},[help,lesson,txOpen,tab]);
  const saveProfile=async(v:Profile)=>{const p=await api<Profile>('/me/investor-profile','PUT',v);setProfile(p)};
  const savePrefs=async(next:Prefs)=>{setBusy(true);try{const saved=await api<Prefs>('/me/preferences','PUT',next);setPrefs(saved);onTheme(saved.theme);}catch(e){track(e,setDataError)}finally{setBusy(false)}};
  const watched=(code:string)=>watch.some(w=>w.asset_code===code);
  const toggleWatch=async(code:string)=>{setBusy(true);try{const current=watch.find(w=>w.asset_code===code);if(current)await api(`/watchlist/${current.id}`,'DELETE');else await api('/watchlist','POST',{asset_code:code});setWatch(await api<Watch[]>('/watchlist'));}catch(e){Alert.alert('Não foi possível',e instanceof Error?e.message:'Erro de atualização')}finally{setBusy(false)}};
  const addTx=async()=>{
    const quantity=Number(qty.replace(',','.')),unit=Number(price.replace(',','.')),fees=Number(fee.replace(',','.'));
    if(!Number.isFinite(quantity)||quantity<=0||!Number.isFinite(unit)||unit<=0||!Number.isFinite(fees)||fees<0){Alert.alert('Dados inválidos','Informe quantidade e preço positivos e taxa igual ou maior que zero.');return}
    setBusy(true);try{await api('/portfolio/transactions','POST',{asset_code:txCoin,type:txType,quantity:String(quantity),unit_price_brl:String(unit),fee_brl:String(fees),traded_at:new Date().toISOString()});setPortfolio(await api<Portfolio>('/portfolio'));setTxOpen(false);setQty('');setPrice('');setFee('0');Alert.alert('Salvo','Movimentação registrada na sua carteira.');}catch(e){Alert.alert('Erro',e instanceof Error?e.message:'Não foi possível registrar')}finally{setBusy(false)}
  };
  const removeTx=(id:string)=>Alert.alert('Apagar movimentação?','A carteira será recalculada. Essa ação não movimenta investimentos reais.',[
    {text:'Cancelar',style:'cancel'},{text:'Apagar',style:'destructive',onPress:async()=>{try{await api(`/portfolio/transactions/${id}`,'DELETE');setPortfolio(await api<Portfolio>('/portfolio'))}catch(e){Alert.alert('Erro',e instanceof Error?e.message:'Falha ao apagar')}}}]);
  const openPage=(target:ExplorePage)=>{setPage(target);setTab('explore')};
  const logoutUser=async()=>{setBusy(true);try{await logout();setUser(null);setProfile(initialProfile);setPrefs(initialPrefs);setPortfolio(null);setWatch([]);setCrypto(null);setSelic(null);setTab('home');onTheme('dark')}catch(e){setUser(null);setTab('home');onTheme('dark');Alert.alert('Sessão local encerrada','Não foi possível confirmar o logout remoto. Revogue as outras sessões ao entrar novamente.')}finally{setBusy(false)}};
  const signout=()=>Alert.alert('Sair da conta?', 'Você precisará entrar novamente.',[{text:'Cancelar',style:'cancel'},{text:'Sair',onPress:logoutUser}]);
  const exportData=async()=>{setBusy(true);try{const data=await api<unknown>('/me/export');await Share.share({message:JSON.stringify(data,null,2),title:'Meus dados INVEST AI'});}catch(e){Alert.alert('Exportação',e instanceof Error?e.message:'Não foi possível exportar')}finally{setBusy(false)}};
  const deleteAccount=()=>{if(!deletePass){Alert.alert('Senha necessária','Digite sua senha atual no campo indicado.');return}Alert.alert('Excluir conta definitivamente?','Seus dados no servidor serão apagados. Esta ação não pode ser desfeita.',[
    {text:'Cancelar',style:'cancel'},{text:'Excluir definitivamente',style:'destructive',onPress:async()=>{setBusy(true);try{await api('/me','DELETE',{password:deletePass});await resetLocalSession();setUser(null);setDeletePass('');setPortfolio(null)}catch(e){Alert.alert('Não foi possível',e instanceof Error?e.message:'Falha ao excluir')}finally{setBusy(false)}}}
  ])};
  const loadSessions=async()=>{try{setSessions(await api('/me/sessions'))}catch(e){track(e,setDataError)}};
  const revoke=(id:string)=>Alert.alert('Revogar sessão?','O dispositivo perderá o acesso.',[{text:'Cancelar',style:'cancel'},{text:'Revogar',style:'destructive',onPress:async()=>{try{await api(`/me/sessions/${id}`,'DELETE');await loadSessions();const current=sessions.find(x=>x.id===id);if(current?.current){await resetLocalSession();setUser(null)}}catch(e){Alert.alert('Erro',e instanceof Error?e.message:'Não foi possível revogar')}}}]);
  const topics:Record<string,string>={
    'Liquidez':'Liquidez é a facilidade de converter um investimento em dinheiro. Observe prazos, carências e condições de resgate.',
    'Risco':'Risco é a possibilidade de resultados diferentes do esperado, inclusive perda do capital. Varia conforme o produto, emissor e mercado.',
    'Selic':'A meta Selic é definida pelo Comitê de Política Monetária (Copom). Não é o retorno líquido garantido de nenhum investimento.',
    'Rentabilidade':'Rentabilidade é a variação relativa do investimento. Pode ser negativa, depende de custos, impostos e do intervalo avaliado.',
    'Preço médio':'Preço médio é o custo médio de aquisição de uma posição. Não equivale ao preço atual nem à rentabilidade efetiva.',
    'Diversificação':'Diversificar é distribuir exposições entre ativos e riscos diferentes. Não elimina perdas.',
    'Dividendos':'Dividendos são distribuições de resultados quando declaradas. Não são rendimentos garantidos.',
    'Volatilidade':'Volatilidade descreve a oscilação dos preços ao longo do tempo. Maior volatilidade costuma significar maior incerteza no curto prazo.'
  };

  if(loading)return <View style={[s.center,{backgroundColor:c.bg}]}><ActivityIndicator color={c.primary} size="large"/><Txt muted>Carregando INVEST AI...</Txt></View>;
  if(!user)return guest?<GuestView onExit={()=>setGuest(false)}/>:<AuthView onGuest={()=>setGuest(true)} onSuccess={u=>{setGuest(false);loginDone(u)}}/>;
  if(!hydrated)return <View style={[s.center,{backgroundColor:c.bg}]}><ActivityIndicator color={c.primary}/><Txt muted>Sincronizando sua conta...</Txt></View>;
  if(!profile.onboarding_completed && !dataError)return <OnboardingView value={profile} onSave={saveProfile}/>;
  const cost=portfolio?.positions.reduce((sum,p)=>sum+Number(p.cost_basis_brl),0)??0;
  const screenTitle:Record<Tab,string>={home:'Início',explore:'Explorar',portfolio:'Carteira',profile:'Perfil'};
  return <View style={{flex:1}}>
    <View style={[s.head,{borderColor:c.border}]}><View><Txt variant="micro" color={c.primary}>✦ INVEST AI</Txt><Txt variant="h1">{screenTitle[tab]}</Txt></View><Pressable style={[s.round,{backgroundColor:c.panel2}]} accessibilityRole="button" accessibilityLabel="Abrir ajuda financeira" onPress={()=>setHelp(true)}><Txt color={c.primary} variant="h2">?</Txt></Pressable></View>
    <ScrollView style={{flex:1}} contentContainerStyle={{paddingHorizontal:17,paddingTop:13,paddingBottom:28,gap:16}} refreshControl={<RefreshControl tintColor={c.primary} refreshing={refreshing} onRefresh={refresh}/>} keyboardShouldPersistTaps="handled">
      <Msg message={dataError}/>
      {tab==='home'?<>
        <View style={{gap:5}}><Txt muted>Olá, {user.full_name.split(' ')[0]} 👋</Txt><Txt variant="h2">Seu dinheiro com mais clareza.</Txt></View>
        <Panel style={{backgroundColor:c.strong,borderColor:c.strong,gap:12,paddingVertical:19}}>
          <Txt color="#C1F8DE" variant="micro">CARTEIRA MANUAL</Txt><Txt color="#FFFFFF" variant="hero">{portfolio?.transactions.length?brl(cost):'Comece aqui'}</Txt>
          <Txt color="#CAEFDE">{portfolio?.transactions.length?'Custo histórico registrado — não é seu patrimônio atual.':'Cadastre sua primeira movimentação para acompanhar seus registros.'}</Txt>
          <Primary label="+ Registrar investimento" onPress={()=>setTxOpen(true)} secondary/>
        </Panel>
        <View style={{gap:10}}><SectionHead title="O que deseja fazer?"/><View style={{flexDirection:'row',gap:10}}><View style={{flex:1}}><Quick label="Encontrar investimentos" icon="◎" onPress={()=>openPage('markets')}/></View><View style={{flex:1}}><Quick label="Meu dinheiro" icon="▤" onPress={()=>setTab('portfolio')}/></View></View>
          <View style={{flexDirection:'row',gap:10}}><View style={{flex:1}}><Quick label="Economia global" icon="◉" onPress={()=>openPage('global')}/></View><View style={{flex:1}}><Quick label="Aprender a investir" icon="◇" onPress={()=>openPage('learn')}/></View></View></View>
        <Panel style={{gap:11}}><SectionHead title="Radar de acompanhamento" subtitle="Sem promessa de lucro ou sinais de compra automática."/><StatusTag label="FONTES PÚBLICAS"/>
          {crypto?<Txt>O mercado monitorado possui {crypto.assets.length} criptoativos com cotações informativas disponíveis.</Txt>:<Txt muted>Dados de criptoativos indisponíveis neste momento.</Txt>}
          {selic?<Txt>Meta Selic informada pelo BCB: <Txt color={c.primary} style={{fontWeight:'800'}}>{pct(selic.annual_rate_pct)}</Txt> ao ano, referência {selic.reference_date}.</Txt>:<Txt muted>Meta Selic indisponível no momento.</Txt>}
          <Primary label="Ver dados e fontes" onPress={()=>openPage('markets')} secondary small/>
        </Panel>
        <Panel style={{gap:9}}><Txt variant="h2">O que mudou desde ontem?</Txt><Txt muted>O resumo mundial automático está em desenvolvimento. Nenhuma notícia é gerada ou apresentada como verificada sem uma fonte conectada.</Txt><Primary label="Ver status da inteligência global" onPress={()=>openPage('global')} secondary small/></Panel>
      </>:null}
      {tab==='explore'?<>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{gap:8,paddingBottom:2}}>{([{id:'markets',label:'Mercados'},{id:'learn',label:'Academia'},{id:'simulator',label:'Simular'},{id:'global',label:'Global'}] as const).map(t=><SmallChip key={t.id} label={t.label} selected={page===t.id} onPress={()=>{setPage(t.id);setLesson(null)}}/>)}</ScrollView>
        {page==='markets'?<>
          <Panel style={{gap:12}}><SectionHead title="Ativos acompanhados" subtitle="Cotações externas informativas, sujeitas a atraso."/>
            <Msg message={marketError}/>{crypto?crypto.assets.map(q=><View key={q.code} style={{gap:10}}><View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'center',gap:8}}><View style={{flex:1}}><Txt style={{fontWeight:'800'}}>{q.name}</Txt><Txt muted variant="caption">{brl(q.price_brl)} · 24 h: <Txt color={typeof q.change_24h_pct==='number'?(q.change_24h_pct<0?c.red:c.primary):c.muted}>{typeof q.change_24h_pct==='number'?pct(q.change_24h_pct):'Indisponível'}</Txt></Txt></View><Primary label={watched(q.code)?'✓ Seguindo':'+ Seguir'} onPress={()=>toggleWatch(q.code)} secondary={!watched(q.code)} small disabled={busy}/></View><Txt muted variant="caption">Fonte: {q.source} · {dateTime(q.updated_at)}{q.delayed?' · Pode ter atraso':''}</Txt><Divider/></View>):<Txt muted>Sem cotações disponíveis. A API não retornou dados verificáveis.</Txt>}
            <Primary label="Atualizar fontes" onPress={marketData} secondary/><Txt muted variant="caption">Não constitui indicação de compra, venda ou retorno futuro.</Txt></Panel>
          <Panel style={{gap:9}}><SectionHead title="Juros no Brasil" subtitle="Fonte oficial: Banco Central do Brasil"/>{selic?<><Txt variant="hero" color={c.primary}>{pct(selic.annual_rate_pct)}</Txt><Txt muted>Meta Selic ao ano · referência {selic.reference_date}</Txt><Txt muted variant="caption">{selic.note}</Txt></>:<Txt muted>Taxa temporariamente indisponível.</Txt>}</Panel>
          <Panel style={{gap:10}}><SectionHead title="Minha lista de acompanhamento"/><Txt muted>{watch.length?`${watch.length} ativo(s) acompanhado(s)`:'Você ainda não acompanha nenhum ativo.'}</Txt>{watch.map(w=><View key={w.id} style={{flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}><Txt>{coinName(w.asset_code)}</Txt><Primary label="Remover" onPress={()=>toggleWatch(w.asset_code)} secondary small disabled={busy}/></View>)}</Panel>
        </>:null}
        {page==='learn'?<>
          <View><Txt variant="h2">Academia INVEST AI</Txt><Txt muted>Aprenda sem precisar entender termos técnicos de primeira.</Txt></View>
          {lesson===null? lessons.map((l,i)=><Pressable key={l.title} onPress={()=>setLesson(i)} accessibilityRole="button"><Panel style={{flexDirection:'row',alignItems:'center',gap:12}}><View style={[s.lessonNum,{backgroundColor:c.soft}]}><Txt color={c.primary} style={{fontWeight:'800'}}>{i+1}</Txt></View><View style={{flex:1,gap:5}}><Txt variant="h2">{l.title}</Txt><Txt muted variant="caption">{l.summary}</Txt></View><Txt color={c.primary} variant="h2">›</Txt></Panel></Pressable>):<Panel style={{gap:12}}><Primary label="← Todas as lições" onPress={()=>setLesson(null)} secondary small/><Txt variant="h1">{lessons[lesson].title}</Txt><Txt>{lessons[lesson].summary}</Txt><Txt>{lessons[lesson].simple}</Txt><Divider/><Txt muted>{lessons[lesson].terms}</Txt><Primary label="Não entendi — explicar termos" onPress={()=>{setSelectedTopic('Liquidez');setHelp(true)}} secondary/></Panel>}
        </>:null}
        {page==='simulator'?<Simulator/>:null}
        {page==='global'?<Panel style={{gap:12}}><StatusTag label="EM CONSTRUÇÃO"/><Txt variant="h2">INVEST AI Global Intelligence</Txt><Txt>O módulo de análise econômica mundial será conectado a fontes oficiais, notícias verificadas e avaliações de impacto.</Txt><Txt muted>Coleta automática, verificação de acontecimentos, mapa mundial, alertas push e o resumo “O que mudou desde ontem?” ainda não estão ativos. Não há feed artificial.</Txt><Divider/><Txt variant="h2">Dado macroeconômico conectado</Txt>{selic?<><Txt color={c.primary} variant="hero">{pct(selic.annual_rate_pct)}</Txt><Txt muted variant="caption">Meta Selic • BCB • {selic.reference_date}</Txt></>:<Txt muted>Aguardando dados reais do BCB.</Txt>}<Primary label="Atualizar consulta" onPress={marketData} secondary/></Panel>:null}
      </>:null}
      {tab==='portfolio'?<>
        <Panel style={{gap:7}}><Txt variant="micro" color={c.primary}>CUSTO DE AQUISIÇÃO REGISTRADO</Txt><Txt variant="hero">{brl(cost)}</Txt><Txt muted variant="caption">Não é patrimônio atual. Ainda não há marcação automática a mercado, rendimentos nem cálculos tributários completos.</Txt><Primary label="+ Adicionar compra ou venda" onPress={()=>setTxOpen(true)}/></Panel>
        {portfolio?.positions.length && cost>0?<Panel style={{gap:10}}><SectionHead title="Distribuição dos custos" subtitle="Proporção do valor histórico aplicado, não exposição atual de mercado."/><View style={{flexDirection:'row',borderRadius:10,overflow:'hidden',height:12}}>{portfolio.positions.filter(p=>Number(p.cost_basis_brl)>0).map((p,i)=><View key={p.asset_code} style={{width:`${100*Number(p.cost_basis_brl)/cost}%`,backgroundColor:['#10B981','#38BDF8','#FBBF24','#A78BFA','#F472B6'][i%5]}}/>)}</View>{portfolio.positions.filter(p=>Number(p.cost_basis_brl)>0).map((p,i)=><View key={p.asset_code} style={{flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}><Txt variant="caption">{coinName(p.asset_code)}</Txt><Txt color={c.primary} variant="caption">{pct(100*Number(p.cost_basis_brl)/cost)}</Txt></View>)}</Panel>:null}
        <View><SectionHead title="Minhas posições" subtitle="Quantidade e preço médio calculados a partir dos registros."/>{portfolio?.positions.length?portfolio.positions.map(pos=><Panel key={pos.asset_code} style={{gap:8,marginBottom:10}}><View style={{flexDirection:'row',justifyContent:'space-between'}}><Txt variant="h2">{coinName(pos.asset_code)}</Txt><StatusTag label="REGISTRADO"/></View><Txt muted>Quantidade: {pos.quantity}</Txt><Txt>Preço médio: {brl(Number(pos.average_price_brl))}</Txt><Txt>Custo histórico: {brl(Number(pos.cost_basis_brl))}</Txt><Txt muted variant="caption">Resultado realizado calculado: {brl(Number(pos.realized_result_brl))}, sem tributação.</Txt></Panel>):<Panel><Txt muted>Carteira vazia. Registre sua primeira compra para visualizar as posições.</Txt></Panel>}</View>
        <View style={{gap:10}}><SectionHead title="Histórico de movimentações"/>{portfolio?.transactions.length?portfolio.transactions.map(tx=><Panel key={tx.id} style={{gap:7}}><View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'center'}}><Txt variant="h2">{tx.type==='BUY'?'Compra':'Venda'} · {coinName(tx.asset_code)}</Txt><Primary label="Apagar" onPress={()=>removeTx(tx.id)} secondary small/></View><Txt muted>{dateTime(tx.traded_at)}</Txt><Txt>{tx.quantity} × {brl(Number(tx.unit_price_brl))}</Txt><Txt muted variant="caption">Taxas: {brl(Number(tx.fee_brl))}</Txt></Panel>):<Txt muted>Sem lançamentos registrados.</Txt>}</View>
      </>:null}
      {tab==='profile'?<>
        <Panel style={{gap:10}}><Txt variant="h2">Minha conta</Txt><Txt muted>{user.email}</Txt><Field label="Nome exibido" value={fullName} onChange={setFullName}/><Primary label="Salvar meu nome" secondary disabled={busy} onPress={async()=>{try{setBusy(true);const u=await api<User>('/me','PATCH',{full_name:fullName});setUser(u);Alert.alert('Pronto','Seu nome foi atualizado')}catch(e){track(e,setDataError)}finally{setBusy(false)}}}/></Panel>
        <Panel style={{gap:12}}><SectionHead title="Meu jeito de investir" subtitle="Você pode refazer seu perfil ou ajustar como vê o app."/><Txt muted>Experiência atual: {profile.experience==='beginner'?'Iniciante':profile.experience==='intermediate'?'Intermediária':'Experiente'}</Txt><Primary label="Refazer questionário" onPress={async()=>{try{await saveProfile({...profile,onboarding_completed:false})}catch(e){track(e,setDataError)}}} secondary/>
          <Txt variant="h2">Modo de leitura</Txt><View style={{flexDirection:'row',gap:8}}><SmallChip label="Iniciante" selected={prefs.level==='beginner'} onPress={()=>savePrefs({...prefs,level:'beginner'})}/><SmallChip label="Profissional" selected={prefs.level==='professional'} onPress={()=>savePrefs({...prefs,level:'professional'})}/></View>
          <Txt variant="h2">Aparência</Txt><View style={{flexDirection:'row',gap:8}}><SmallChip label="Escuro" selected={prefs.theme==='dark'} onPress={()=>savePrefs({...prefs,theme:'dark'})}/><SmallChip label="Claro" selected={prefs.theme==='light'} onPress={()=>savePrefs({...prefs,theme:'light'})}/></View></Panel>
        <Panel style={{gap:12}}><SectionHead title="Notificações" subtitle="A preferência será salva; envio de push ainda não está conectado."/><View style={{flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}><Txt>Quero receber notificações</Txt><Switch accessibilityLabel="Notificações" value={prefs.notifications_enabled} onValueChange={v=>savePrefs({...prefs,notifications_enabled:v})} trackColor={{true:c.primary}}/></View><Txt muted variant="caption">Esta configuração não ativa alertas de mercado automaticamente. O serviço de notificações será implementado em outra etapa.</Txt></Panel>
        <Panel style={{gap:10}}><SectionHead title="Privacidade e segurança"/><Primary label="Ver sessões ativas" onPress={loadSessions} secondary/>{sessions.map(x=><View key={x.id} style={{gap:7}}><Txt variant="caption">{x.user_agent || 'Dispositivo'}{x.current?' (esta sessão)':''}</Txt><Txt muted variant="caption">Iniciada em {dateTime(x.created_at)}</Txt><Primary label="Revogar sessão" onPress={()=>revoke(x.id)} secondary small/><Divider/></View>)}<Primary label="Exportar meus dados" onPress={exportData} secondary loading={busy}/><Primary label="Sair da conta" onPress={signout} secondary disabled={busy}/></Panel>
        <Panel style={{gap:10}}><SectionHead title="Excluir conta" subtitle="A exclusão apaga os dados da conta no servidor."/><Field label="Confirme sua senha" value={deletePass} onChange={setDeletePass} secure/><Primary label="Excluir minha conta" onPress={deleteAccount} danger disabled={busy}/></Panel>
      </>:null}
    </ScrollView>
    <View style={[s.nav,{borderColor:c.border,backgroundColor:c.panel}]}>{([{id:'home',icon:'⌂',label:'Início'},{id:'explore',icon:'◎',label:'Explorar'},{id:'portfolio',icon:'▤',label:'Carteira'},{id:'profile',icon:'☰',label:'Perfil'}] as const).map(item=><Pressable key={item.id} onPress={()=>{setTab(item.id);setLesson(null)}} accessibilityRole="tab" accessibilityState={{selected:tab===item.id}} style={{flex:1,alignItems:'center',gap:2,paddingVertical:7}}><Txt color={tab===item.id?c.primary:c.muted} style={{fontSize:23,fontWeight:'800'}}>{item.icon}</Txt><Txt variant="caption" color={tab===item.id?c.primary:c.muted} style={{fontWeight:tab===item.id?'800':'500'}}>{item.label}</Txt></Pressable>)}</View>
    <Modal visible={help} transparent animationType="slide" onRequestClose={()=>setHelp(false)}><View style={s.overlay}><View style={[s.sheet,{backgroundColor:c.panel}]}><View style={{flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}><Txt variant="h2">Entenda sem complicação</Txt><Primary label="Fechar" secondary small onPress={()=>setHelp(false)}/></View><Txt muted variant="caption">Explicações educativas. O chat com IA contextual está em desenvolvimento.</Txt><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{gap:7}}>{Object.keys(topics).map(k=><SmallChip key={k} label={k} selected={selectedTopic===k} onPress={()=>setSelectedTopic(k)}/>)}</ScrollView><Panel style={{gap:10}}><Txt variant="h2">{selectedTopic}</Txt><Txt>{topics[selectedTopic]}</Txt></Panel></View></View></Modal>
    <Modal visible={txOpen} animationType="slide" onRequestClose={()=>setTxOpen(false)}><SafeAreaView style={{flex:1,backgroundColor:c.bg}}><ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{padding:22,paddingBottom:50,gap:14}}><View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'center'}}><Txt variant="h1">Registrar movimentação</Txt><Primary label="Fechar" onPress={()=>setTxOpen(false)} secondary small/></View><Txt muted>Esses dados apenas organizam seu registro. Nenhuma ordem será enviada a corretoras.</Txt><View style={{flexDirection:'row',gap:8}}><SmallChip label="Compra" selected={txType==='BUY'} onPress={()=>setTxType('BUY')}/><SmallChip label="Venda" selected={txType==='SELL'} onPress={()=>setTxType('SELL')}/></View><Txt variant="h2">Ativo</Txt><View style={{flexDirection:'row',gap:7,flexWrap:'wrap'}}>{[...COINS,{code:'OTHER',name:'Outro'}].map(x=><SmallChip key={x.code} label={x.name} selected={txCoin===x.code} onPress={()=>setTxCoin(x.code as typeof txCoin)}/>)}</View><Field label="Quantidade" keyboard="decimal-pad" value={qty} onChange={setQty} placeholder="Ex.: 0,01"/><Field label="Preço por unidade em reais (R$)" keyboard="decimal-pad" value={price} onChange={setPrice} placeholder="Ex.: 500000"/><Field label="Taxas totais em reais (R$)" keyboard="decimal-pad" value={fee} onChange={setFee}/><Txt muted variant="caption">A data da movimentação será o momento em que você salvar. Cadastro retroativo por data específica ainda não está disponível no app.</Txt><Primary label="Salvar movimentação" onPress={addTx} loading={busy}/></ScrollView></SafeAreaView></Modal>
  </View>;
}
function Quick({label,icon,onPress}:{label:string;icon:string;onPress:()=>void}){const c=usePalette();return <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} style={({pressed})=>[s.quick,{backgroundColor:c.panel,borderColor:c.border,opacity:pressed?0.76:1}]}><Txt color={c.primary} style={{fontSize:27}}>{icon}</Txt><Txt style={{fontWeight:'800'}}>{label}</Txt><Txt muted variant="caption">Abrir →</Txt></Pressable>}
export default function App(){
  const[theme,setTheme]=useState<'dark'|'light'>('dark');
  // Preferência persistida via /api/me/preferences, sincronizada com o tema nativo.
  const palette=theme==='dark'?DARK:LIGHT;
  return <ThemeContext.Provider value={palette}><SafeAreaView style={{flex:1,backgroundColor:palette.bg,paddingTop:Platform.OS==='android'?StatusBar.currentHeight:0}}><ExpoStatusBar style={theme==='dark'?'light':'dark'}/><InvestAppWithTheme onTheme={setTheme}/></SafeAreaView></ThemeContext.Provider>;
}
function InvestAppWithTheme({onTheme}:{onTheme:(theme:'dark'|'light')=>void}){
  return apiConfigured() ? <InvestApp onTheme={onTheme}/> : <OfflineApp onTheme={onTheme}/>;
}
const s=StyleSheet.create({
  center:{flex:1,alignItems:'center',justifyContent:'center',gap:14},
  panel:{borderWidth:1,borderRadius:19,padding:16,gap:4},
  button:{justifyContent:'center',alignItems:'center',borderRadius:13,paddingVertical:9},
  chip:{borderWidth:1,borderRadius:22,paddingHorizontal:13,paddingVertical:9,alignItems:'center'},
  input:{borderWidth:1,borderRadius:12,paddingVertical:9,paddingHorizontal:13,fontSize:15},
  msg:{borderWidth:1,borderRadius:12,padding:11},
  option:{borderWidth:1,borderRadius:15,padding:17,flexDirection:'row',justifyContent:'space-between',alignItems:'center'},
  round:{height:38,width:38,borderRadius:13,alignItems:'center',justifyContent:'center'},
  head:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingHorizontal:19,paddingVertical:10,borderBottomWidth:1},
  nav:{flexDirection:'row',borderTopWidth:1,paddingBottom:Platform.OS==='ios'?10:3},
  quick:{borderWidth:1,borderRadius:17,padding:14,gap:8,minHeight:139,justifyContent:'center'},
  lessonNum:{height:42,width:42,borderRadius:13,alignItems:'center',justifyContent:'center'},
  overlay:{flex:1,justifyContent:'flex-end',backgroundColor:'rgba(0,0,0,0.6)'},
  sheet:{borderTopLeftRadius:25,borderTopRightRadius:25,padding:20,paddingBottom:36,gap:17,maxHeight:'80%'}
});
