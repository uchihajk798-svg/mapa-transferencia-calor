"""Testes de autenticação nativa: login, renovação, autorização, sessões e isolamento."""


def test_native_register_refresh_replay_and_logout(client):
    payload = {"email": "app@example.com", "full_name": "Invest Mobile", "password": "senha-super-segura-2026"}
    r = client.post("/api/mobile/auth/register", json=payload)
    assert r.status_code == 201, r.text
    first = r.json()
    assert first["user"]["email"] == payload["email"]
    assert first["access_expires_in"] == 900
    assert "refresh_token" not in r.headers.get("set-cookie", "")
    assert "access_token" not in r.headers.get("set-cookie", "")
    h = {"Authorization": "Bearer " + first["access_token"]}
    assert client.get("/api/me", headers=h).status_code == 200
    assert client.get("/api/me").status_code == 401  # Registro nativo não cria cookie
    assert client.get("/api/portfolio", headers=h).status_code == 200
    updated = client.post("/api/mobile/auth/refresh", json={"refresh_token": first["refresh_token"]})
    assert updated.status_code == 200, updated.text
    assert updated.json()["refresh_token"] != first["refresh_token"]
    replay = client.post("/api/mobile/auth/refresh", json={"refresh_token": first["refresh_token"]})
    assert replay.status_code == 401
    new_h = {"Authorization": "Bearer " + updated.json()["access_token"]}
    assert client.post("/api/mobile/auth/logout", headers=new_h).status_code == 200
    assert client.get("/api/me", headers=new_h).status_code == 401
    assert client.post("/api/mobile/auth/refresh", json={"refresh_token": updated.json()["refresh_token"]}).status_code == 401


def test_native_login_and_cross_account_isolation(client):
    for email in ("one@example.com", "two@example.com"):
        result = client.post("/api/mobile/auth/register", json={"email":email,"password":"uma-senha-segura-789","full_name":"Pessoa Mobile"})
        assert result.status_code == 201, result.text
    auth_one = client.post("/api/mobile/auth/login", json={"email":"one@example.com","password":"uma-senha-segura-789"})
    auth_two = client.post("/api/mobile/auth/login", json={"email":"two@example.com","password":"uma-senha-segura-789"})
    h1={"Authorization":"Bearer "+auth_one.json()["access_token"]}
    h2={"Authorization":"Bearer "+auth_two.json()["access_token"]}
    item = client.post("/api/watchlist", headers=h1, json={"asset_code":"bitcoin"})
    assert item.status_code == 201
    assert len(client.get("/api/watchlist", headers=h1).json()) == 1
    assert client.get("/api/watchlist", headers=h2).json() == []
    assert client.delete("/api/watchlist/"+item.json()["id"], headers=h2).status_code == 404
    assert client.get("/api/me",headers={"Authorization":"Basic wrong"}).status_code == 401
    assert client.post("/api/mobile/auth/login", json={"email":"one@example.com","password":"wrong"}).status_code == 401


def test_mobile_can_complete_profile_and_transaction(client):
    login = client.post("/api/mobile/auth/register",json={"email":"wallet@example.com","password":"senha-forte-que-vai","full_name":"Invest Test"})
    assert login.status_code == 201
    h = {"Authorization":"Bearer "+login.json()["access_token"]}
    profile = {"experience":"beginner", "goal":"learn", "horizon":"unsure", "liquidity":"unsure", "risk_tolerance":"unsure", "interests":["fixed"], "onboarding_completed": True}
    assert client.put("/api/me/investor-profile",json=profile,headers=h).status_code == 200
    tx={"asset_code":"bitcoin", "type":"BUY", "quantity":"0.01", "unit_price_brl":"500000", "fee_brl":"1", "traded_at":"2026-01-01T10:00:00-03:00"}
    assert client.post("/api/portfolio/transactions",json=tx,headers=h).status_code == 201
    data=client.get("/api/portfolio", headers=h).json()
    assert data["positions"][0]["quantity"] == "0.0100000000"
    assert float(data["positions"][0]["cost_basis_brl"]) == 5001.0
