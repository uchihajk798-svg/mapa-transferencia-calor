'use client';
import {FormEvent,useState} from 'react';
import {Cloud,CloudDownload,CloudUpload,LogOut,LockKeyhole,ShieldAlert} from 'lucide-react';
import {sanitizeBackup} from '@/lib/local-finance';
import type {LocalStore} from '@/lib/local-finance';

const ENDPOINT=process.env.NEXT_PUBLIC_API_URL || '';
type CloudSnapshot={revision:number;data:unknown|null;updated_at:string|null};
type LoginResponse={user:{id:string;email:string;full_name:string};access_token:string;access_expires_in:number};

async function remote<T>(path:string,method:'GET'|'POST'|'PUT',body?:unknown,token?:string):Promise<T>{
 if(!ENDPOINT.startsWith('https://'))throw new Error('A conexão HTTPS do servidor não está configurada.');
 let response:Response;
 try{response=await fetch(`${ENDPOINT}/api${path}`,{method,headers:{'Content-Type':'application/json',...(token?{Authorization:`Bearer ${token}`}:{})},...(body===undefined?{}:{body:JSON.stringify(body)})});}
 catch{throw new Error('Servidor temporariamente indisponível. Aguarde um pouco e tente novamente.');}
 if(!response.ok){const json=await response.json().catch(()=>({}));throw new Error(typeof json.detail==='string'?json.detail:`Erro de comunicação (${response.status})`)}
 return response.json() as Promise<T>;
}
export default function CloudAccount({store,onRestore,available,token,onToken}:{store:LocalStore;onRestore:(v:LocalStore)=>void;available:boolean;token:string;onToken:(v:string)=>void}){
 const[mode,setMode]=useState<'register'|'login'>('register');
 const[name,setName]=useState('');const[email,setEmail]=useState('');const[password,setPassword]=useState('');
 const[user,setUser]=useState('');const[busy,setBusy]=useState(false);const[status,setStatus]=useState('');const[error,setError]=useState('');
 const[snapshot,setSnapshot]=useState<CloudSnapshot|null>(null);
 const fetchSnapshot=async(auth:string)=>{const data=await remote<CloudSnapshot>('/me/cloud-backup','GET',undefined,auth);setSnapshot(data);return data};
 const authenticate=async(e:FormEvent)=>{
  e.preventDefault();setError('');setStatus('');setBusy(true);
  try{
   const result=await remote<LoginResponse>(`/mobile/auth/${mode}`,'POST',mode==='register'?{full_name:name,email,password}:{email,password});
   onToken(result.access_token);setUser(result.user.full_name);setPassword('');
   await fetchSnapshot(result.access_token);setStatus('Conta conectada. Confira o backup antes de enviar ou recuperar dados.');
  }catch(e){setError(e instanceof Error?e.message:'Não foi possível acessar a conta.')}finally{setBusy(false)}
 };
 const upload=async()=>{
  if(!token)return;
  if(!window.confirm('Salvar esta carteira na sua conta online? Isso substituirá o backup remoto somente se ele não tiver sido alterado.'))return;
  setBusy(true);setError('');setStatus('');
  try{
   const latest=await fetchSnapshot(token);
   if(latest.data&&!window.confirm('Já existe um backup nessa conta. Quer substituí-lo pela carteira deste navegador?'))return;
   const payload={version:1,...store};
   const result=await remote<{revision:number}>('/me/cloud-backup','PUT',{expected_revision:latest.revision,data:payload},token);
   setSnapshot({revision:result.revision,data:payload,updated_at:new Date().toISOString()});
   setStatus('Cópia salva na nuvem. Faça outro backup depois de novas movimentações.');
  }catch(e){setError(e instanceof Error?e.message:'Falha ao salvar backup.')}finally{setBusy(false)}
 };
 const download=async()=>{
  if(!token)return;
  setBusy(true);setError('');setStatus('');
  try{
   const latest=await fetchSnapshot(token);
   if(!latest.data)throw new Error('Sua conta ainda não tem backup.');
   const validated=sanitizeBackup(latest.data);
   if(!window.confirm('Restaurar o backup online? Isso substituirá toda a carteira e preferências locais deste navegador. Exporte um backup local antes de continuar.'))return;
   onRestore(validated);setStatus('Backup restaurado neste navegador.');
  }catch(e){setError(e instanceof Error?e.message:'Não foi possível restaurar.')}finally{setBusy(false)}
 };
 const exit=()=>{onToken('');setUser('');setSnapshot(null);setPassword('');setStatus('Sessão encerrada neste navegador. O login precisa ser feito novamente para acessar o backup.');};
 return <div className="gcard gcloud">
  <div className="gsection"><h2><Cloud size={20}/> Minha conta e backup online</h2><p>Gratuito durante os testes. Só use quando o PostgreSQL estiver conectado; os dados locais continuam independentes.</p></div>
  {!available?<div className="ginlineinfo"><ShieldAlert size={17}/> Cadastro indisponível enquanto o servidor e o banco não estiverem prontos. Você pode continuar usando o modo local normalmente.</div>:
   !token?<><div className="gcloudtabs"><button className={mode==='register'?'gprimary':'gsecondary'} type="button" onClick={()=>{setMode('register');setError('')}}>Criar conta</button><button className={mode==='login'?'gprimary':'gsecondary'} type="button" onClick={()=>{setMode('login');setError('')}}>Entrar</button></div>
    <form className="gform" onSubmit={authenticate}>{mode==='register'&&<label>Seu nome<input autoComplete="name" minLength={2} maxLength={100} required value={name} onChange={e=>setName(e.target.value)}/></label>}<label>E-mail<input type="email" autoComplete="email" required value={email} onChange={e=>setEmail(e.target.value)}/></label><label>Senha<input type="password" autoComplete={mode==='register'?'new-password':'current-password'} required minLength={mode==='register'?10:1} maxLength={128} value={password} onChange={e=>setPassword(e.target.value)}/></label><button className="gprimary" disabled={busy}>{busy?'Conectando…':mode==='register'?'Criar conta grátis':'Entrar na conta'} <LockKeyhole size={16}/></button></form>
   </>:<><div className="gcloudwho"><strong>Conectado: {user||'Sua conta'}</strong><button className="gsecondary" onClick={exit}><LogOut size={16}/> Sair</button></div><p className="gmuted">Backup na nuvem: {snapshot?.revision?`versão ${snapshot.revision}`:'nenhuma cópia salva'}.</p><div className="grow"><button className="gprimary" disabled={busy} onClick={()=>void upload()}><CloudUpload size={16}/> Salvar meus dados na nuvem</button><button className="gsecondary" disabled={busy||!snapshot?.data} onClick={()=>void download()}><CloudDownload size={16}/> Restaurar dados da nuvem</button></div><p className="gmuted gmini">Sincronização manual nesta versão. Entre novamente se a sessão expirar (15 min). Não inclui execução de investimentos.</p></>}
  {status&&<div className="ginlineinfo">{status}</div>}{error&&<div className="ginlinewarn">{error}</div>}
  <p className="gmuted gmini">A versão gratuita do banco Render expira após 30 dias. Mantenha sempre uma cópia JSON no seu aparelho. Recuperação de senha por e-mail depende de serviço de envio ainda não configurado.</p>
 </div>;
}
