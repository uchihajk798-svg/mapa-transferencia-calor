// Cenários matemáticos ilustrativos, sem dado de mercado nem premissa escondida.
export type Assumptions={initial:number;monthly:number;years:number;rate:number;inflation:number;tax:number};
export type Scenario={invested:number;gross:number;net:number;real:number};
export function calculateScenario(a:Assumptions,annualRate=a.rate):Scenario|null {
  const inputs=[a.initial,a.monthly,a.years,a.rate,a.inflation,a.tax,annualRate];
  const months=Math.round(a.years*12);
  if(inputs.some(x=>!Number.isFinite(x))||a.initial<0||a.monthly<0||months<1||months>600||
      annualRate<=-100||annualRate>100||a.rate<=-100||a.rate>100||a.inflation<=-100||a.inflation>100||a.tax<0||a.tax>100)return null;
  const monthlyRate=Math.pow(1+annualRate/100,1/12)-1;
  let gross=a.initial;
  for(let i=0;i<months;i++)gross=gross*(1+monthlyRate)+a.monthly;
  const invested=a.initial+a.monthly*months;
  const net=gross-Math.max(0,gross-invested)*a.tax/100;
  return {invested,gross,net,real:net/Math.pow(1+a.inflation/100,months/12)};
}
