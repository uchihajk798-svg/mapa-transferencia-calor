import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'INVEST AI | Entenda seu dinheiro', description: 'Plataforma de educação financeira e acompanhamento de investimentos. Sem promessas de rentabilidade.' };
export default function RootLayout({children}: Readonly<{children: React.ReactNode}>) { return <html lang="pt-BR"><body>{children}</body></html>; }
